// core/msx-binary/src/compiler.rs
//! Scene → binary MSX payload.
//!
//! Encoding order (matches docs/format-spec.md):
//!   Header (32 bytes)
//!   Payload (optionally MBFA-compressed):
//!     Background RGBA   4 bytes
//!     Viewbox           16 bytes  (if flags.bit0)
//!     String pool       variable
//!     Def section       variable
//!     Element stream    variable

use std::io;

use msx_ast::{
    Circle, Def, Element, Ellipse, GaussianSplat, Group, Image, Layer, Line, LoopMode,
    MediaSource, Path, Polyline, Rect, Scene, SdfNode, ShaderUniformValue, Style, Text, Use,
};

use crate::encoder::*;
use crate::effect_codec::write_effect;
use crate::header::{MsxHeader, COMPRESS_MBFA, COMPRESS_NONE};
use crate::path_codec::encode_commands;
use crate::sdf_codec::write_sdf_tree;
use crate::tags::*;

// ── Public API ───────────────────────────────────────────────────────────────

pub fn compile(scene: &Scene, compress: bool) -> io::Result<Vec<u8>> {
    let mut pool:    Vec<String> = Vec::new();
    let mut payload: Vec<u8>     = Vec::new();

    // Background
    payload.extend_from_slice(&scene.canvas.background.to_bytes());

    // Viewbox
    if let Some(ref vb) = scene.canvas.viewbox {
        payload.extend_from_slice(&vb.to_bytes());
    }

    // Placeholder string-pool count (2 bytes, patched below)
    let pool_len_offset = payload.len();
    payload.push(0);
    payload.push(0);

    // Defs
    let mut def_payload: Vec<u8> = Vec::new();
    for def in &scene.defs {
        encode_def(def, &mut def_payload, &mut pool);
    }

    // Elements
    let mut elem_payload: Vec<u8> = Vec::new();
    for elem in &scene.elements {
        encode_element(elem, &mut elem_payload, &mut pool);
    }
    write_u8(&mut elem_payload, TAG_END);

    // Animation section — gated on non-default state rather than
    // `Scene::is_animated()` (see `encode_animations`'s own comment).
    // Built here, before the pool is patched/appended below, so any
    // `target_id` interned by `encode_animations` still lands in the
    // same shared pool as everything else.
    let has_animations = !scene.animations.is_empty()
        || scene.duration != 0.0
        || scene.loop_mode != LoopMode::default();
    let mut anim_payload: Vec<u8> = Vec::new();
    if has_animations {
        encode_animations(scene, &mut anim_payload, &mut pool);
    }

    // Patch pool count
    let count_bytes = (pool.len() as u16).to_le_bytes();
    payload[pool_len_offset]     = count_bytes[0];
    payload[pool_len_offset + 1] = count_bytes[1];

    // Append pool entries
    for s in &pool {
        let bytes = s.as_bytes();
        write_u16(&mut payload, bytes.len() as u16);
        payload.extend_from_slice(bytes);
    }

    // Append defs + elements + animations
    payload.extend_from_slice(&def_payload);
    payload.extend_from_slice(&elem_payload);
    payload.extend_from_slice(&anim_payload);

    // Header
    let mut header = MsxHeader::new(scene.canvas.width as f32, scene.canvas.height as f32);
    header.elem_count   = scene.elements.len() as u32;
    header.str_pool_len = pool.iter().map(|s| 2 + s.len()).sum::<usize>() as u32 + 2;
    header.def_count    = scene.defs.len() as u32;
    header.compress     = if compress { COMPRESS_MBFA } else { COMPRESS_NONE };

    if scene.canvas.viewbox.is_some() { header.set_viewbox(true); }
    if !scene.defs.is_empty()         { header.set_defs(true); }
    if has_animations                 { header.set_animations(true); }

    // Optionally compress
    let final_payload = if compress {
        mbfa::compress(&payload, 8)
            .map_err(|e| io::Error::other(format!("MBFA compress: {}", e)))?
    } else {
        payload
    };

    let mut out = Vec::with_capacity(32 + final_payload.len());
    out.extend_from_slice(&header.serialize());
    out.extend_from_slice(&final_payload);
    Ok(out)
}

// ── Def encoding ─────────────────────────────────────────────────────────────

fn encode_def(def: &Def, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    match def {
        Def::LinearGradient(g) => {
            write_u8(out, TAG_LINEAR_GRADIENT);
            let id_idx = intern_string(pool, &g.id);
            write_u16(out, id_idx);
            write_f32(out, g.x1); write_f32(out, g.y1);
            write_f32(out, g.x2); write_f32(out, g.y2);
            write_u16(out, g.stops.len() as u16);
            for stop in &g.stops { out.extend_from_slice(&stop.to_bytes()); }
        }
        Def::RadialGradient(g) => {
            write_u8(out, TAG_RADIAL_GRADIENT);
            let id_idx = intern_string(pool, &g.id);
            write_u16(out, id_idx);
            write_f32(out, g.cx); write_f32(out, g.cy); write_f32(out, g.r);
            write_f32(out, g.fx); write_f32(out, g.fy);
            write_u16(out, g.stops.len() as u16);
            for stop in &g.stops { out.extend_from_slice(&stop.to_bytes()); }
        }
        Def::ConicGradient(g) => {
            write_u8(out, TAG_CONIC_GRADIENT);
            let id_idx = intern_string(pool, &g.id);
            write_u16(out, id_idx);
            write_f32(out, g.cx); write_f32(out, g.cy); write_f32(out, g.angle);
            write_u16(out, g.stops.len() as u16);
            for stop in &g.stops { out.extend_from_slice(&stop.to_bytes()); }
        }
        Def::Shader(s) => {
            write_u8(out, TAG_SHADER);
            let id_idx          = intern_string(pool, &s.id);
            let source_ref_idx  = intern_string(pool, &s.source_ref);
            let entry_point_idx = intern_string(pool, &s.entry_point);
            write_u16(out, id_idx);
            write_u16(out, source_ref_idx);
            write_u16(out, entry_point_idx);
            write_color(out, s.fallback_color);
            write_u16(out, s.uniforms.len() as u16);
            for u in &s.uniforms {
                let name_idx = intern_string(pool, &u.name);
                write_u16(out, name_idx);
                match u.value {
                    ShaderUniformValue::Float(x) => {
                        write_u8(out, 0);
                        write_f32(out, x as f64);
                    }
                    ShaderUniformValue::Vec2(x, y) => {
                        write_u8(out, 1);
                        write_f32(out, x as f64); write_f32(out, y as f64);
                    }
                    ShaderUniformValue::Vec3(x, y, z) => {
                        write_u8(out, 2);
                        write_f32(out, x as f64); write_f32(out, y as f64); write_f32(out, z as f64);
                    }
                    ShaderUniformValue::Vec4(x, y, z, w) => {
                        write_u8(out, 3);
                        write_f32(out, x as f64); write_f32(out, y as f64);
                        write_f32(out, z as f64); write_f32(out, w as f64);
                    }
                }
            }
        }
        Def::Audio(a) => {
            write_u8(out, TAG_AUDIO);
            let id_idx = intern_string(pool, &a.id);
            write_u16(out, id_idx);
            encode_media_source(&a.source, out, pool);
        }
    }
}

// ── Animation encoding ───────────────────────────────────────────────────────

/// `duration`/`loop_mode`/`animations[]` — appended after the element
/// stream (past its `TAG_END` sentinel), gated by
/// `MsxHeader::FLAG_HAS_ANIMATIONS`. A decoder built before this flag
/// existed never looks past the elements it already knows how to read,
/// so it degrades gracefully on a file that has this section (same
/// silent-drop as today, not a crash) — see `scene_decode::decode`'s own
/// comment on the sentinel byte for the read side of that.
///
/// Gated on non-default state (`compile`'s `has_animations`) rather than
/// `Scene::is_animated()` — `is_animated()` additionally requires
/// `effective_duration() > 0.0`, which is a *rendering* question ("does
/// this scene currently produce motion"), not a *roundtrip* one. An
/// explicitly-authored `duration`/`loop_mode` sitting alongside
/// zero-keyframe or otherwise inert tracks should still survive a
/// compile/decode cycle unchanged rather than silently reverting to
/// `Scene::new()`'s defaults.
///
/// `target_id` goes through the shared string pool (`intern_string`), not
/// inline like `Path::d_raw` — track target ids are short and often
/// repeat (several properties on the same element each get their own
/// track), so pool dedup is the right fit here, same reasoning as
/// `MediaSource::FileRef` paths in `encode_media_source`.
fn encode_animations(scene: &Scene, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_f32(out, scene.duration);
    write_u8(out, scene.loop_mode.to_byte());
    write_u16(out, scene.animations.len() as u16);
    for track in &scene.animations {
        let target_idx = intern_string(pool, &track.target_id);
        write_u16(out, target_idx);
        write_u8(out, track.property.to_byte());
        write_u16(out, track.keyframes.len() as u16);
        for kf in &track.keyframes {
            write_f32(out, kf.time);
            write_f32(out, kf.value);
            write_u8(out, kf.easing.to_byte());
        }
    }
}

// ── Element encoding ─────────────────────────────────────────────────────────

fn encode_element(elem: &Element, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    match elem {
        Element::Rect(e)     => encode_rect(e, out, pool),
        Element::Circle(e)   => encode_circle(e, out, pool),
        Element::Ellipse(e)  => encode_ellipse(e, out, pool),
        Element::Line(e)     => encode_line(e, out, pool),
        Element::Polyline(e) => encode_polyline(e, out, pool, TAG_POLYLINE),
        Element::Polygon(e)  => encode_polyline(e, out, pool, TAG_POLYGON),
        Element::Path(e)     => encode_path(e, out, pool),
        Element::Text(e)     => encode_text(e, out, pool),
        Element::Group(e)    => encode_group(e, out, pool),
        Element::Use(e)      => encode_use(e, out, pool),
        Element::Sdf(e)      => encode_sdf(e, out, pool),
        Element::Splat(e)    => encode_splat(e, out, pool),
        Element::Layer(e)    => encode_layer(e, out, pool),
        Element::Image(e)    => encode_image(e, out, pool),
    }
}

// ── MediaSource encoding ────────────────────────────────────────────────────

fn encode_media_source(source: &MediaSource, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    match source {
        MediaSource::Embedded(bytes) => {
            write_u8(out, 0);
            // u32 length prefix, deliberately NOT the shared string pool
            // (`write_string_pool` uses a u16 length prefix per entry —
            // the exact same class of silent-truncation bug this project
            // already found and fixed once for `Path::d_raw`, and an
            // embedded image blob is exactly the kind of payload
            // realistically big enough to hit it: a modest few-hundred-
            // pixel PNG routinely exceeds 65535 bytes on its own, before
            // base64 even inflates it further at the DixScript-source
            // boundary — see `media.rs`'s own module doc for the full
            // reasoning).
            write_u32(out, bytes.len() as u32);
            out.extend_from_slice(bytes);
        }
        MediaSource::FileRef(path) => {
            write_u8(out, 1);
            // A file path is short — the string pool's u16 cap isn't a
            // realistic concern here the way it is for embedded blob
            // bytes, so reusing it (and getting pool deduplication for
            // anything referencing the same path more than once) is the
            // right call, not a shortcut.
            let idx = intern_string(pool, path);
            write_u16(out, idx);
        }
    }
}

fn encode_image(e: &Image, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_IMAGE);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    encode_media_source(&e.source, out, pool);
    write_f32(out, e.x);
    write_f32(out, e.y);
    write_f32(out, e.width);
    write_f32(out, e.height);
    write_u8(out, e.anchor.to_byte());
    write_style(out, &e.style, pool);
}

fn encode_rect(e: &Rect, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_RECT);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    write_f32(out, e.x);
    write_f32(out, e.y);
    write_f32(out, e.width);
    write_f32(out, e.height);
    write_f32(out, e.rx.unwrap_or(0.0));
    // Always encode 0.0 when ry is None — never falls back to rx. Keeps
    // None → wire 0.0 → decode None a true roundtrip rather than aliasing
    // ry onto rx's value.
    write_f32(out, e.ry.unwrap_or(0.0));
    write_style(out, &e.style, pool);
}

fn encode_circle(e: &Circle, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_CIRCLE);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    write_f32(out, e.cx); write_f32(out, e.cy); write_f32(out, e.r);
    write_style(out, &e.style, pool);
}

fn encode_ellipse(e: &Ellipse, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_ELLIPSE);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    write_f32(out, e.cx); write_f32(out, e.cy);
    write_f32(out, e.rx); write_f32(out, e.ry);
    write_style(out, &e.style, pool);
}

fn encode_line(e: &Line, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_LINE);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    write_f32(out, e.x1); write_f32(out, e.y1);
    write_f32(out, e.x2); write_f32(out, e.y2);
    write_style(out, &e.style, pool);
}

fn encode_polyline(e: &Polyline, out: &mut Vec<u8>, pool: &mut Vec<String>, tag: u8) {
    write_u8(out, tag);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    write_u32(out, e.points.len() as u32);
    for p in &e.points { write_f32(out, p.x); write_f32(out, p.y); }
    write_style(out, &e.style, pool);
}

fn encode_path(e: &Path, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_PATH);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    let mut cmd_buf: Vec<u8> = Vec::new();
    encode_commands(&e.commands, &mut cmd_buf);
    write_u32(out, cmd_buf.len() as u32);
    out.extend_from_slice(&cmd_buf);
    // `d_raw` itself, verbatim — NOT the string pool (`write_string_pool`
    // uses a u16 length prefix per entry, so a big enough compound path —
    // a dense QR code, a complex icon, anything with hundreds of
    // subpaths — could exceed 65535 bytes and either panic or silently
    // corrupt; `cmd_buf` above already sidesteps this with its own u32
    // prefix, so `d_raw` gets the identical treatment here). This is the
    // fix for `Path::d_raw`'s own doc comment ("Cached original `d`
    // string for roundtrip fidelity") not actually holding before now:
    // this field was never written at all, and decode regenerated an
    // approximation via `commands_to_d` instead — which reformats every
    // token (`H126.829` becomes `H 126.829`, and `fmt_f64` strips
    // trailing zeros: `48.780` becomes `48.78`) that's geometrically
    // identical but byte-for-byte different from whatever the original
    // author actually wrote. Harmless for rendering (both strings parse
    // to the same commands), but a real, silent failure for anything
    // that round-trips through this binary format and then compares the
    // `d` string itself — which is exactly what "fidelity" in that doc
    // comment was promising and not delivering.
    let d_bytes = e.d_raw.as_bytes();
    write_u32(out, d_bytes.len() as u32);
    out.extend_from_slice(d_bytes);
    write_style(out, &e.style, pool);
}

fn encode_text(e: &Text, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_TEXT);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    let str_idx = intern_string(pool, &e.content);
    write_u16(out, str_idx);
    write_f32(out, e.x); write_f32(out, e.y);
    write_style(out, &e.style, pool);
}

fn encode_group(e: &Group, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_GROUP);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    write_u32(out, e.children.len() as u32);
    for child in &e.children { encode_element(child, out, pool); }
    let empty = Style::empty();
    write_style(out, e.style.as_ref().unwrap_or(&empty), pool);
}

fn encode_use(e: &Use, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_USE);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    let href_idx = intern_string(pool, &e.href);
    write_u16(out, href_idx);
    write_f32(out, e.x); write_f32(out, e.y);
}

fn encode_sdf(e: &SdfNode, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_SDF);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    write_sdf_tree(out, &e.tree);
    write_paint(out, &e.fill, pool);
    let has_stroke = e.stroke.is_some();
    write_u8(out, has_stroke as u8);
    if has_stroke {
        write_paint(out, e.stroke.as_ref().unwrap(), pool);
        write_f32(out, e.stroke_width.unwrap_or(1.0));
    }
}

fn encode_splat(e: &GaussianSplat, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_SPLAT);
    // GaussianSplat has no transform field, so it uses a simpler id-only
    // header rather than the shared write_id_flags two-bit scheme.
    let has_id = e.id.is_some();
    write_u8(out, has_id as u8);
    if let Some(id) = &e.id {
        let idx = intern_string(pool, id);
        write_u16(out, idx);
    }
    write_f32(out, e.x);
    write_f32(out, e.y);
    write_f32(out, e.sigma_x);
    write_f32(out, e.sigma_y);
    write_f32(out, e.rotation);
    write_color(out, e.color);
    write_f32(out, e.opacity);
    // `fill` is appended after every pre-existing field rather than
    // interleaved among them — deliberate: a reader that only knows the
    // pre-`fill` wire format would at least stop at a predictable point
    // instead of misreading a `fill` byte as something else mid-struct.
    // Not that any such reader exists to protect (no external consumers
    // of the binary format yet — this is genuinely a breaking wire-format
    // change, not a versioned/compatible extension), but "new field goes
    // at the end" costs nothing and is one less thing to think about.
    let has_fill = e.fill.is_some();
    write_u8(out, has_fill as u8);
    if let Some(fill) = &e.fill {
        write_paint(out, fill, pool);
    }
}

fn encode_layer(e: &Layer, out: &mut Vec<u8>, pool: &mut Vec<String>) {
    write_u8(out, TAG_LAYER);
    write_id_flags(out, e.id.as_deref(), e.transform.as_ref(), pool);
    write_u8(out, e.blend_mode.to_byte());
    write_f32(out, e.opacity);
    write_u8(out, e.clip as u8);
    write_u16(out, e.effects.len() as u16);
    for fx in &e.effects { write_effect(out, fx); }
    write_u32(out, e.children.len() as u32);
    for child in &e.children { encode_element(child, out, pool); }
    // z_index: added after every pre-existing field, same "new field
    // goes at the end" convention `fill` follows above for Sdf/Splat —
    // a breaking wire-format change either way (no external readers of
    // this format exist yet), but costs nothing to keep consistent.
    write_f32(out, e.z_index);
}

// ── Stats ──────────────────────────────────────────────────────────────────────

pub fn compile_stats(scene: &Scene) -> (usize, usize, usize) {
    match compile(scene, false) {
        Ok(data) => (data.len() - 32, scene.element_count(), scene.defs.len()),
        Err(_)   => (0, 0, 0),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use msx_ast::{Canvas, Color, LinearGradient, Paint, Stop};

    fn basic_scene() -> Scene {
        let mut style = Style::empty();
        style.fill         = Some(Paint::Color(Color::rgb(255, 0, 0)));
        style.stroke       = Some(Paint::None);
        style.stroke_width = Some(0.0);
        style.opacity      = Some(1.0);

        let mut scene = Scene::new(Canvas::new(200.0, 200.0, Color::WHITE));
        scene.elements.push(Element::Circle(Circle {
            cx: 100.0, cy: 100.0, r: 50.0,
            id: None, transform: None, style,
        }));
        scene
    }

    #[test]
    fn compile_produces_valid_header_magic() {
        let data = compile(&basic_scene(), false).unwrap();
        assert_eq!(&data[0..4], b"MSX\0");
    }

    #[test]
    fn compile_header_dimensions() {
        let data = compile(&basic_scene(), false).unwrap();
        let w = f32::from_le_bytes(data[8..12].try_into().unwrap());
        let h = f32::from_le_bytes(data[12..16].try_into().unwrap());
        assert!((w - 200.0f32).abs() < 1e-4);
        assert!((h - 200.0f32).abs() < 1e-4);
    }

    #[test]
    fn compile_uncompressed_no_compress_flag() {
        let data = compile(&basic_scene(), false).unwrap();
        assert_eq!(data[5], crate::header::COMPRESS_NONE);
    }

    #[test]
    fn compile_compressed_sets_flag() {
        let data = compile(&basic_scene(), true).unwrap();
        assert_eq!(data[5], crate::header::COMPRESS_MBFA);
    }

    #[test]
    fn compile_elem_count_in_header() {
        let data = compile(&basic_scene(), false).unwrap();
        let count = u32::from_le_bytes(data[16..20].try_into().unwrap());
        assert_eq!(count, 1);
    }

    #[test]
    fn rect_ry_none_does_not_inherit_rx() {
        use msx_ast::Rect as AstRect;
        let mut style = Style::empty();
        style.fill         = Some(Paint::Color(Color::rgb(0, 128, 255)));
        style.stroke       = Some(Paint::None);
        style.stroke_width = Some(0.0);
        style.opacity      = Some(1.0);

        let mut scene = Scene::new(Canvas::new(400.0, 300.0, Color::WHITE));
        scene.elements.push(Element::Rect(AstRect {
            x: 10.0, y: 10.0, width: 100.0, height: 50.0,
            rx: Some(12.0),
            ry: None, // explicitly None
            id: None, transform: None, style,
        }));

        let binary  = compile(&scene, false).unwrap();
        let decoded = crate::decode(&binary).unwrap();

        if let Element::Rect(r) = &decoded.elements[0] {
            assert_eq!(r.rx, Some(12.0), "rx must survive roundtrip");
            assert_eq!(r.ry, None,       "ry=None must NOT become Some(12) after roundtrip");
        } else {
            panic!("expected Rect");
        }
    }

    #[test]
    fn sdf_splat_layer_roundtrip() {
        use msx_ast::{BlendMode, Effect, SdfTree};

        let mut scene = Scene::new(Canvas::new(500.0, 500.0, Color::WHITE));

        let sdf = SdfNode::new(
            SdfTree::Circle { cx: 0.0, cy: 0.0, r: 50.0 }
                .smooth_subtract(SdfTree::Circle { cx: 20.0, cy: 0.0, r: 20.0 }, 0.25),
            Paint::Color(Color::rgb(200, 50, 50)),
        );
        scene.elements.push(Element::Sdf(sdf));

        scene.elements.push(Element::Splat(GaussianSplat::circle(
            250.0, 250.0, 40.0, Color::rgb(255, 255, 200), 0.5,
        )));

        let layer = Layer::new(vec![])
            .with_blend(BlendMode::Multiply)
            .with_opacity(0.75)
            .with_z_index(2.5)
            .with_effect(Effect::Blur { radius: 8.0 });
        scene.elements.push(Element::Layer(layer));

        let binary  = compile(&scene, true).unwrap();
        let decoded = crate::decode(&binary).unwrap();

        assert_eq!(decoded.elements.len(), 3);
        assert!(matches!(decoded.elements[0], Element::Sdf(_)));
        assert!(matches!(decoded.elements[1], Element::Splat(_)));
        if let Element::Layer(l) = &decoded.elements[2] {
            assert_eq!(l.blend_mode, BlendMode::Multiply);
            assert!((l.opacity - 0.75).abs() < 1e-3);
            assert!((l.z_index - 2.5).abs() < 1e-3);
            assert_eq!(l.effects.len(), 1);
        } else {
            panic!("expected Layer");
        }
    }

    /// Regression test for a real bug found in `examples/mid-qr-k.msx`:
    /// `Path::d_raw`'s own doc comment ("Cached original `d` string for
    /// roundtrip fidelity") was never actually true — `encode_path` never
    /// wrote it, and decode regenerated an approximation via
    /// `commands_to_d` instead. That regeneration is geometrically
    /// identical but byte-for-byte *different*: `to_svg_token` inserts a
    /// space after every command letter (`H126.829` → `H 126.829`, no
    /// exception for the compact, no-inner-space style real-world
    /// generators like mid-qr-code-lib actually emit), and `fmt_f64`
    /// strips trailing zeros (`48.780` → `48.78`). Uses the literal
    /// first-two-modules substring from that file's giant data-modules
    /// path, not a synthetic example, so this test fails exactly the way
    /// the real file did before the fix in `encode_path`/`TAG_PATH`
    /// decode (writing/reading `d_raw` directly, u32-length-prefixed —
    /// same pattern as `cmd_buf` right above it — rather than through
    /// the string pool, which uses a u16 length prefix per entry and
    /// would risk truncating a big enough compound path).
    #[test]
    fn path_d_raw_survives_roundtrip_byte_for_byte() {
        let original_d = "M117.073 39.024H126.829V48.780H117.073Z M195.122 39.024H204.878V48.780H195.122Z";
        let commands = msx_ast::path::parse_d(original_d).unwrap();

        let path = Path {
            commands,
            d_raw: original_d.to_string(),
            id: None,
            transform: None,
            style: Style { fill: Some(Paint::Color(Color::rgb(0, 0, 0))), ..Default::default() },
        };

        let mut scene = Scene::new(Canvas::new(400.0, 400.0, Color::WHITE));
        scene.elements.push(Element::Path(path));

        let binary  = compile(&scene, false).unwrap();
        let decoded = crate::decode(&binary).unwrap();

        let Element::Path(decoded_path) = &decoded.elements[0] else { panic!("expected Path") };
        assert_eq!(decoded_path.d_raw, original_d, "d_raw must survive byte-for-byte, not just geometrically");
    }

    /// `examples/mid-qr-k.msx` still fails `msx roundtrip` in CI even with
    /// the `d_raw` fix above live on `origin/main`. That's expected, not a
    /// sign the fix is incomplete: `msx-render-svg::render_path` never
    /// reads `d_raw` at all (see render/msx-render-svg/src/shapes.rs —
    /// it always rebuilds `d` from `commands` via `commands_to_d`), so
    /// `msx roundtrip`'s SVG-text comparison can't be affected by `d_raw`
    /// fidelity either way, for any file. A local sandbox repro (real
    /// msx-ast + real msx-binary + an identity-passthrough mbfa stub,
    /// since mbfa itself needs rustc 1.79+ and this sandbox is capped at
    /// 1.75) fed the actual 2,280-command giant path from mid-qr-k.msx
    /// through `compile()`/`decode()` and found `commands_to_d(before) ==
    /// commands_to_d(after)` held exactly — so parser, path_codec, string
    /// pool, and the f64→f32→f64 coordinate downcast are all clean for
    /// this file's real content. `compress = true` was the one variable
    /// that repro couldn't cover without real mbfa. This test covers it,
    /// here, where CI's real toolchain can build the real crate — a
    /// synthetic grid shaped like mid-qr-k's 456 near-identical rect
    /// subpaths (same MoveTo/HLineTo/VLineTo/HLineTo/ClosePath-per-rect
    /// pattern, same ~2,280-command scale), run through real MBFA
    /// compression this time. A failure here points squarely at mbfa's
    /// compress/decompress for this repetition shape; a pass means the
    /// synthetic grid isn't reproducing whatever real mbfa trips on and
    /// the next step is feeding it mid-qr-k's actual bytes instead.
    #[test]
    fn many_repeated_small_subpaths_survive_compressed_roundtrip() {
        use msx_ast::path::PathCommand;
        use msx_ast::Point;

        let mut commands = Vec::new();
        for i in 0..456 {
            let col = (i % 24) as f64;
            let row = (i / 24) as f64;
            let x  = ((10.0 + col * 9.756) * 1000.0).round() / 1000.0;
            let y  = ((10.0 + row * 9.756) * 1000.0).round() / 1000.0;
            let x2 = ((x + 9.756) * 1000.0).round() / 1000.0;
            let y2 = ((y + 9.756) * 1000.0).round() / 1000.0;
            commands.push(PathCommand::MoveTo(Point::new(x, y)));
            commands.push(PathCommand::HLineTo(x2));
            commands.push(PathCommand::VLineTo(y2));
            commands.push(PathCommand::HLineTo(x));
            commands.push(PathCommand::ClosePath);
        }

        let d_raw = msx_ast::path::commands_to_d(&commands);
        let path = Path {
            commands: commands.clone(),
            d_raw,
            id: None,
            transform: None,
            style: Style { fill: Some(Paint::Color(Color::rgb(0, 0, 0))), ..Default::default() },
        };

        let mut scene = Scene::new(Canvas::new(400.0, 400.0, Color::WHITE));
        scene.elements.push(Element::Path(path));

        // compress = true: real MBFA, unlike path_d_raw_survives_roundtrip_byte_for_byte above.
        let binary  = compile(&scene, true).unwrap();
        let decoded = crate::decode(&binary).unwrap();

        let Element::Path(decoded_path) = &decoded.elements[0] else { panic!("expected Path") };

        let before = msx_ast::path::commands_to_d(&commands);
        let after  = msx_ast::path::commands_to_d(&decoded_path.commands);
        assert_eq!(before, after,
            "commands_to_d output must survive a REAL-MBFA-compressed roundtrip — \
             this is what `msx roundtrip` actually compares, not d_raw or raw command equality");
    }

    /// Splat's `fill` field was added after `color`, appended at the end
    /// of its wire format (`[u8 has_fill][paint if present]`) rather than
    /// interleaved among the pre-existing fields — see `encode_splat`'s
    /// comment for why. This exercises both states: a real `Paint::Ref`
    /// (the actual point of the feature — a splat pointing at a gradient
    /// or shader def instead of a flat color) and plain `None` (every
    /// splat that existed before this field did, and every one that still
    /// just uses `color` today).
    #[test]
    fn splat_fill_roundtrips_both_present_and_absent() {
        let mut scene = Scene::new(Canvas::new(100.0, 100.0, Color::WHITE));
        scene.defs.push(Def::LinearGradient(LinearGradient::new(
            "glow".to_string(), 0.0, 0.0, 40.0, 0.0,
            vec![Stop::new(0.0, Color::rgb(255, 255, 255)), Stop::new(1.0, Color::rgb(0, 0, 0))],
        )));

        let mut with_fill = GaussianSplat::circle(20.0, 20.0, 8.0, Color::rgb(0, 255, 0), 0.8);
        with_fill.fill = Some(Paint::Ref("glow".to_string()));
        scene.elements.push(Element::Splat(with_fill));

        let without_fill = GaussianSplat::circle(50.0, 50.0, 8.0, Color::rgb(0, 0, 255), 1.0);
        scene.elements.push(Element::Splat(without_fill));

        let binary  = compile(&scene, true).unwrap();
        let decoded = crate::decode(&binary).unwrap();

        assert_eq!(decoded.elements.len(), 2);
        match &decoded.elements[0] {
            Element::Splat(s) => {
                assert_eq!(s.fill, Some(Paint::Ref("glow".to_string())), "the gradient reference must survive the roundtrip");
                assert_eq!(s.color, Color::rgb(0, 255, 0), "color is still encoded even when fill is set — a renderer with fill support absent should still have a sane color to fall back to");
            }
            other => panic!("expected a Splat, got {other:?}"),
        }
        match &decoded.elements[1] {
            Element::Splat(s) => assert_eq!(s.fill, None, "a splat with no fill set must decode back to None, not e.g. Some(Paint::None)"),
            other => panic!("expected a Splat, got {other:?}"),
        }
    }

    #[test]
    fn image_element_with_embedded_source_roundtrips() {
        use msx_ast::{Anchor, Image, MediaSource};

        // A real (tiny, 1x1) PNG signature-plus-body, not just the magic
        // bytes alone — exercises the u32-length-prefixed embedded-blob
        // path, not just the discriminant byte.
        let png_bytes: Vec<u8> = {
            let mut b = vec![0x89, b'P', b'N', b'G', 0x0D, 0x0A, 0x1A, 0x0A];
            b.extend_from_slice(&[0u8; 100]); // stand-in IHDR/IDAT/IEND body
            b
        };

        let mut scene = Scene::new(Canvas::new(300.0, 300.0, Color::WHITE));
        scene.elements.push(Element::Image(
            Image::new(MediaSource::Embedded(png_bytes.clone()), 50.0, 60.0, 120.0, 80.0)
                .with_anchor(Anchor::Center),
        ));

        let binary  = compile(&scene, true).unwrap();
        let decoded = crate::decode(&binary).unwrap();

        match &decoded.elements[0] {
            Element::Image(img) => {
                assert_eq!(img.source, MediaSource::Embedded(png_bytes), "embedded blob bytes must survive byte-for-byte");
                assert_eq!((img.x, img.y, img.width, img.height), (50.0, 60.0, 120.0, 80.0));
                assert_eq!(img.anchor, Anchor::Center);
            }
            other => panic!("expected an Image, got {other:?}"),
        }
    }

    #[test]
    fn image_element_with_file_ref_source_roundtrips() {
        use msx_ast::{Image, MediaSource};

        let mut scene = Scene::new(Canvas::new(300.0, 300.0, Color::WHITE));
        scene.elements.push(Element::Image(Image::new(
            MediaSource::FileRef("assets/logo.png".to_string()),
            10.0, 10.0, 64.0, 64.0,
        )));
        // A second image referencing the SAME path — checks that
        // FileRef paths go through the shared string pool's own
        // deduplication (encode_media_source's own comment), not just
        // that a single reference round-trips.
        scene.elements.push(Element::Image(Image::new(
            MediaSource::FileRef("assets/logo.png".to_string()),
            100.0, 10.0, 64.0, 64.0,
        )));

        let binary  = compile(&scene, true).unwrap();
        let decoded = crate::decode(&binary).unwrap();

        for el in &decoded.elements {
            match el {
                Element::Image(img) => assert_eq!(img.source, MediaSource::FileRef("assets/logo.png".to_string())),
                other => panic!("expected an Image, got {other:?}"),
            }
        }
    }

    /// The actual bug this section exists to fix: a scene with real
    /// keyframe tracks used to compile and decode "successfully" while
    /// silently dropping every track, `duration`, and `loop_mode` — no
    /// error, just an animated scene coming back static. Covers both
    /// `compress` states, since MBFA compression sees the animation
    /// section as opaque bytes but the header flag/gating logic doesn't
    /// know that in advance.
    #[test]
    fn animation_tracks_survive_roundtrip() {
        use msx_ast::{AnimatedProperty, AnimationTrack, Easing, Keyframe, LoopMode};

        for compress in [false, true] {
            let mut scene = basic_scene();
            scene.duration  = 2.5;
            scene.loop_mode = LoopMode::PingPong;
            scene.animations.push(AnimationTrack::new(
                "circle",
                AnimatedProperty::Opacity,
                vec![
                    Keyframe::linear(0.0, 0.0),
                    Keyframe::new(2.5, 1.0, Easing::EaseInOut),
                ],
            ));
            scene.animations.push(AnimationTrack::new(
                "circle",
                AnimatedProperty::TranslateX,
                vec![Keyframe::linear(0.0, 0.0), Keyframe::linear(2.5, 100.0)],
            ));

            let binary  = compile(&scene, compress).unwrap();
            let decoded = crate::decode(&binary).unwrap();

            assert!((decoded.duration - 2.5).abs() < 1e-4, "compress={compress}");
            assert_eq!(decoded.loop_mode, LoopMode::PingPong, "compress={compress}");
            assert_eq!(decoded.animations.len(), 2, "compress={compress}");

            let opacity = decoded.animations.iter()
                .find(|t| t.property == AnimatedProperty::Opacity)
                .expect("opacity track");
            assert_eq!(opacity.target_id, "circle");
            assert_eq!(opacity.keyframes.len(), 2);
            assert!((opacity.keyframes[0].value - 0.0).abs() < 1e-4);
            assert!((opacity.keyframes[1].value - 1.0).abs() < 1e-4);
            assert_eq!(opacity.keyframes[1].easing, Easing::EaseInOut);

            let translate = decoded.animations.iter()
                .find(|t| t.property == AnimatedProperty::TranslateX)
                .expect("translate_x track");
            assert_eq!(translate.target_id, "circle", "shared target_id across both tracks");

            assert!(decoded.is_animated(), "compress={compress}");
        }
    }

    /// A scene with no `animations::` block at all must decode exactly
    /// as it always has — the flag stays unset, the section is never
    /// written, and no unrelated behaviour changes. Regression guard
    /// against this fix accidentally touching the non-animated path.
    #[test]
    fn scene_without_animation_is_unaffected() {
        let binary  = compile(&basic_scene(), false).unwrap();
        let header  = crate::header::MsxHeader::parse(&binary).unwrap();
        let decoded = crate::decode(&binary).unwrap();

        assert!(!header.has_animations());
        assert_eq!(decoded.duration, 0.0);
        assert_eq!(decoded.loop_mode, msx_ast::LoopMode::Once);
        assert!(decoded.animations.is_empty());
        assert!(!decoded.is_animated());
    }

    /// `encode_animations` is gated on non-default state, not
    /// `Scene::is_animated()` — an explicit `duration`/`loop_mode` with
    /// zero tracks is a real authoring choice (e.g. a composition length
    /// declared ahead of adding any keyframes) and must still round-trip,
    /// even though `is_animated()` is false both before and after.
    #[test]
    fn explicit_duration_and_loop_mode_survive_with_no_tracks() {
        use msx_ast::LoopMode;

        let mut scene = basic_scene();
        scene.duration  = 4.0;
        scene.loop_mode = LoopMode::Loop;

        let binary  = compile(&scene, false).unwrap();
        let decoded = crate::decode(&binary).unwrap();

        assert!((decoded.duration - 4.0).abs() < 1e-4);
        assert_eq!(decoded.loop_mode, LoopMode::Loop);
        assert!(decoded.animations.is_empty());
        assert!(!decoded.is_animated(), "no tracks means not animated, regardless of duration/loop_mode");
    }

    #[test]
    fn audio_def_roundtrips() {
        use msx_ast::{AudioDef, MediaSource};

        let wav_bytes: Vec<u8> = {
            let mut b = b"RIFF".to_vec();
            b.extend_from_slice(&[0, 0, 0, 0]);
            b.extend_from_slice(b"WAVE");
            b.extend_from_slice(&[0u8; 40]);
            b
        };

        let mut scene = Scene::new(Canvas::new(100.0, 100.0, Color::WHITE));
        scene.defs.push(Def::Audio(AudioDef::new("chime", MediaSource::Embedded(wav_bytes.clone()))));

        let binary  = compile(&scene, true).unwrap();
        let decoded = crate::decode(&binary).unwrap();

        assert_eq!(decoded.defs.len(), 1);
        match &decoded.defs[0] {
            Def::Audio(a) => {
                assert_eq!(a.id, "chime");
                assert_eq!(a.source, MediaSource::Embedded(wav_bytes));
            }
            other => panic!("expected Def::Audio, got {other:?}"),
        }
    }
    }
