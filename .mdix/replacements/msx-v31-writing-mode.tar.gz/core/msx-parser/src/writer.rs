// core/msx-parser/src/writer.rs
//! Scene to `.msx` source text, the inverse of `parse_scene`.
//!
//! The output is plain DixScript that `parse_scene` reads back into the
//! same scene. Numbers print at full precision (the shortest text that
//! parses back to the same `f64`), so nothing is rounded on the way out.
//!
//! Supported: canvas and `viewbox`, linear, radial and conic gradients,
//! and the elements rect, circle, ellipse, line, polyline, polygon, path,
//! text, image, group, use and layer (without effects), plus the timeline:
//! `duration`, `loop_mode` and the animation tracks. Anything else returns
//! [`WriteError::Unsupported`] instead of writing a file that would lose
//! content: SDF nodes, splats, shader and audio defs and layer effects.

use std::fmt::{self, Write as _};

use msx_ast::{
    Anchor, AnimationTrack, BlendMode, Color, Def, Easing, Element, FontWeight, Group, ImageFormat, Layer, LoopMode, MediaSource, Paint,
    PathCommand, Point, Scene, Stop, Style, Transform,
};

/// Why a scene could not be written.
#[derive(Debug, Clone, PartialEq)]
pub enum WriteError {
    /// The scene holds something the writer cannot express yet.
    Unsupported(String),
}

impl fmt::Display for WriteError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            WriteError::Unsupported(what) => write!(f, "cannot write {what} to .msx source yet"),
        }
    }
}

impl std::error::Error for WriteError {}

/// Write `scene` as `.msx` source text.
pub fn scene_to_msx(scene: &Scene) -> Result<String, WriteError> {
    let mut out = String::new();
    out.push_str("@CONFIG( version -> \"1.0.0\" )\n@DATA(\n");

    let c = &scene.canvas;
    let _ = writeln!(
        out,
        "  scene = {{ width = {}, height = {}, background = {} }}",
        num(c.width),
        num(c.height),
        color_value(c.background)
    );
    if let Some(vb) = &c.viewbox {
        let _ = writeln!(
            out,
            "  viewbox = {{ min_x = {}, min_y = {}, width = {}, height = {} }}",
            num(vb.min_x),
            num(vb.min_y),
            num(vb.width),
            num(vb.height)
        );
    }

    if scene.duration != 0.0 {
        let _ = writeln!(out, "  duration = {}", float(scene.duration));
    }
    if scene.loop_mode != LoopMode::Once {
        let _ = writeln!(out, "  loop_mode = {}", quote(scene.loop_mode.to_dixscript_str()));
    }

    if !scene.defs.is_empty() {
        out.push_str("  defs::\n");
        for def in &scene.defs {
            let _ = writeln!(out, "    {}", def_object(def)?);
        }
    }

    if !scene.elements.is_empty() {
        out.push_str("  elements::\n");
        for el in &scene.elements {
            write_element(&mut out, el, 4, false)?;
            out.push('\n');
        }
    }

    if !scene.animations.is_empty() {
        out.push_str("  animations::\n");
        for track in &scene.animations {
            write_track(&mut out, track);
        }
    }

    out.push_str(")\n");
    Ok(out)
}

// ── Scalars ──────────────────────────────────────────────────────────────────

/// Shortest text that parses back to the same value. Whole numbers print
/// without a fraction. Non-finite values cannot appear in source, so they
/// print as 0.
fn num(v: f64) -> String {
    if !v.is_finite() || v == 0.0 {
        return "0".into();
    }
    if v == v.trunc() && v.abs() < 1e15 {
        return format!("{}", v as i64);
    }
    format!("{v}")
}

/// Same as [`num`], but always with a decimal point, so an array of
/// numbers is read as floats and never as a mix of integers and floats.
/// A filter graph as one inline object. See `parse_graph` in `layer.rs`.
fn graph_text(g: &msx_ast::FilterGraph) -> String {
    use msx_ast::{CompositeOp, FilterOp, TransferFn};

    let list = |vs: &[f64]| vs.iter().map(|v| float(*v)).collect::<Vec<_>>().join(", ");
    let input = |i: msx_ast::FilterInput| quote(&i.source_name());
    let nodes: Vec<String> = g
        .nodes
        .iter()
        .map(|n| {
            let mut f = vec![format!("op = {}", quote(n.op.source_name()))];
            match &n.op {
                FilterOp::Flood { color } => f.push(format!("color = {}", color_value(*color))),
                FilterOp::Composite { a, b, op } => {
                    f.push(format!("input = {}", input(*a)));
                    f.push(format!("input2 = {}", input(*b)));
                    f.push(format!("operator = {}", quote(op.source_name())));
                    if let CompositeOp::Arithmetic { k1, k2, k3, k4 } = op {
                        f.push(format!("k = [{}]", list(&[*k1, *k2, *k3, *k4])));
                    }
                }
                FilterOp::Merge { inputs } => {
                    f.push(format!("inputs = [{}]", inputs.iter().map(|i| input(*i)).collect::<Vec<_>>().join(", ")));
                }
                FilterOp::Blend { a, b, mode } => {
                    f.push(format!("input = {}", input(*a)));
                    f.push(format!("input2 = {}", input(*b)));
                    f.push(format!("mode = {}", quote(blend_mode_text(*mode))));
                }
                FilterOp::Offset { input: i, dx, dy } => {
                    f.push(format!("input = {}", input(*i)));
                    f.push(format!("dx = {}", float(*dx)));
                    f.push(format!("dy = {}", float(*dy)));
                }
                FilterOp::Blur { input: i, rx, ry } => {
                    f.push(format!("input = {}", input(*i)));
                    f.push(format!("rx = {}", float(*rx)));
                    f.push(format!("ry = {}", float(*ry)));
                }
                FilterOp::ColorMatrix { input: i, values } => {
                    f.push(format!("input = {}", input(*i)));
                    f.push(format!("values = [{}]", list(values)));
                }
                FilterOp::ComponentTransfer { input: i, funcs } => {
                    f.push(format!("input = {}", input(*i)));
                    for (func, channel) in funcs.iter().zip(["r", "g", "b", "a"]) {
                        if matches!(func, TransferFn::Identity) {
                            continue;
                        }
                        let body = match func {
                            TransferFn::Identity => unreachable!(),
                            TransferFn::Table(t) | TransferFn::Discrete(t) => format!("values = [{}]", list(t)),
                            TransferFn::Linear { slope, intercept } => format!("slope = {}, intercept = {}", float(*slope), float(*intercept)),
                            TransferFn::Gamma { amplitude, exponent, offset } => {
                                format!("amplitude = {}, exponent = {}, offset = {}", float(*amplitude), float(*exponent), float(*offset))
                            }
                        };
                        f.push(format!("{channel} = {{ kind = {}, {body} }}", quote(func.source_name())));
                    }
                }
            }
            if let Some(r) = n.region {
                f.push(format!("region = [{}]", list(&[r.x, r.y, r.width, r.height])));
            }
            if n.linear {
                f.push("linear = true".to_string());
            }
            format!("{{ {} }}", f.join(", "))
        })
        .collect();
    format!("type = \"graph\", nodes = [{}]", nodes.join(", "))
}

fn float(v: f64) -> String {
    let s = num(v);
    if s.contains('.') { s } else { format!("{s}.0") }
}

fn quote(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for ch in s.chars() {
        match ch {
            '\\' => out.push_str("\\\\"),
            '"' => out.push_str("\\\""),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            '\0' => out.push_str("\\0"),
            c => out.push(c),
        }
    }
    out.push('"');
    out
}

/// Opaque colors print as a bare hex literal, like the hand-written
/// examples. Colors with alpha print as a quoted 8-digit hex string.
fn color_value(c: Color) -> String {
    if c.a == 255 {
        format!("#{:02x}{:02x}{:02x}", c.r, c.g, c.b)
    } else {
        format!("\"#{:02x}{:02x}{:02x}{:02x}\"", c.r, c.g, c.b, c.a)
    }
}

fn paint_value(p: &Paint) -> String {
    match p {
        Paint::None => quote("none"),
        Paint::Color(c) => color_value(*c),
        Paint::Ref(r) => quote(r),
        Paint::CurrentColor => quote("currentColor"),
    }
}

fn transform_text(t: &Transform) -> Option<String> {
    Some(match t {
        Transform::None => return None,
        Transform::Translate { x, y } => format!("translate({} {})", num(*x), num(*y)),
        Transform::Scale { x, y } => format!("scale({} {})", num(*x), num(*y)),
        Transform::Rotate { angle, cx: Some(cx), cy: Some(cy) } => format!("rotate({} {} {})", num(*angle), num(*cx), num(*cy)),
        Transform::Rotate { angle, .. } => format!("rotate({})", num(*angle)),
        Transform::SkewX(a) => format!("skewX({})", num(*a)),
        Transform::SkewY(a) => format!("skewY({})", num(*a)),
        Transform::Matrix(m) => format!("matrix({} {} {} {} {} {})", num(m.a), num(m.b), num(m.c), num(m.d), num(m.e), num(m.f)),
        Transform::Multiple(list) => {
            let parts: Vec<String> = list.iter().filter_map(transform_text).collect();
            if parts.is_empty() {
                return None;
            }
            parts.join(" ")
        }
    })
}

// ── Style ────────────────────────────────────────────────────────────────────

/// Style fields at the parser's defaults are left out, because the parser
/// starts from those defaults anyway.
fn style_object(s: &Style) -> Option<String> {
    let default = Style::default();
    let mut f: Vec<String> = Vec::new();

    if let Some(p) = &s.fill {
        if Some(p) != default.fill.as_ref() {
            f.push(format!("fill = {}", paint_value(p)));
        }
    }
    if let Some(p) = &s.stroke {
        if Some(p) != default.stroke.as_ref() {
            f.push(format!("stroke = {}", paint_value(p)));
        }
    }
    if let Some(w) = s.stroke_width {
        if Some(w) != default.stroke_width {
            f.push(format!("stroke_width = {}", num(w)));
        }
    }
    if let Some(o) = s.opacity {
        if Some(o) != default.opacity {
            f.push(format!("opacity = {}", num(o)));
        }
    }
    if let Some(o) = s.fill_opacity {
        f.push(format!("fill_opacity = {}", num(o)));
    }
    if let Some(o) = s.stroke_opacity {
        f.push(format!("stroke_opacity = {}", num(o)));
    }
    if let Some(r) = s.fill_rule {
        f.push(format!("fill_rule = {}", quote(r.to_svg())));
    }
    if let Some(c) = s.stroke_linecap {
        f.push(format!("stroke_linecap = {}", quote(c.to_svg())));
    }
    if let Some(j) = s.stroke_linejoin {
        f.push(format!("stroke_linejoin = {}", quote(j.to_svg())));
    }
    if let Some(m) = s.stroke_miterlimit {
        f.push(format!("stroke_miterlimit = {}", num(m)));
    }
    if let Some(d) = &s.stroke_dasharray {
        let items: Vec<String> = d.iter().map(|v| float(*v)).collect();
        f.push(format!("stroke_dasharray = [{}]", items.join(", ")));
    }
    if let Some(o) = s.stroke_dashoffset {
        f.push(format!("stroke_dashoffset = {}", num(o)));
    }
    if let Some(v) = s.font_size {
        f.push(format!("font_size = {}", num(v)));
    }
    if let Some(v) = &s.font_family {
        f.push(format!("font_family = {}", quote(v)));
    }
    if let Some(w) = &s.font_weight {
        f.push(format!("font_weight = {}", quote(&font_weight_text(w))));
    }
    if let Some(a) = s.text_anchor {
        f.push(format!("text_anchor = {}", quote(a.to_svg())));
    }
    if let Some(b) = &s.dominant_baseline {
        f.push(format!("dominant_baseline = {}", quote(b)));
    }
    if let Some(v) = s.letter_spacing {
        f.push(format!("letter_spacing = {}", num(v)));
    }
    if let Some(d) = s.text_decoration {
        f.push(format!("text_decoration = {}", quote(&d.to_svg())));
    }
    if let Some(v) = s.font_style {
        f.push(format!("font_style = {}", quote(v.to_svg())));
    }
    if let Some(v) = s.writing_mode {
        f.push(format!("writing_mode = {}", quote(v.to_svg())));
    }
    if s.visibility_hidden {
        f.push("visibility = \"hidden\"".into());
    }
    if s.display_none {
        f.push("display = \"none\"".into());
    }

    if f.is_empty() { None } else { Some(format!("{{ {} }}", f.join(", "))) }
}

fn font_weight_text(w: &FontWeight) -> String {
    w.to_svg()
}

// ── Defs ─────────────────────────────────────────────────────────────────────

fn stops_array(stops: &[Stop]) -> String {
    let items: Vec<String> = stops
        .iter()
        .map(|s| {
            let opaque = Color::rgb(s.color.r, s.color.g, s.color.b);
            if s.color.a == 255 {
                format!("{{ offset = {}, color = {} }}", num(s.offset), color_value(opaque))
            } else {
                format!(
                    "{{ offset = {}, color = {}, opacity = {} }}",
                    num(s.offset),
                    color_value(opaque),
                    num(s.color.a as f64 / 255.0)
                )
            }
        })
        .collect();
    format!("[{}]", items.join(", "))
}

/// The `units`, `spread` and `transform` keys of a gradient, each only when it
/// is not the default. Starts with a comma when it is not empty.
fn gradient_space(units: msx_ast::GradientUnits, spread: msx_ast::SpreadMethod, transform: &Option<Transform>) -> String {
    let mut s = String::new();
    if units != msx_ast::GradientUnits::default() {
        let _ = write!(s, ", units = {}", quote(units.name()));
    }
    if spread != msx_ast::SpreadMethod::default() {
        let _ = write!(s, ", spread = {}", quote(spread.name()));
    }
    if let Some(t) = transform.as_ref().and_then(transform_text) {
        let _ = write!(s, ", transform = {}", quote(&t));
    }
    s
}

fn def_object(def: &Def) -> Result<String, WriteError> {
    Ok(match def {
        Def::LinearGradient(g) => format!(
            "{{ type = \"linear_gradient\", id = {}, x1 = {}, y1 = {}, x2 = {}, y2 = {}{}, stops = {} }}",
            quote(&g.id),
            num(g.x1),
            num(g.y1),
            num(g.x2),
            num(g.y2),
            gradient_space(g.units, g.spread, &g.transform),
            stops_array(&g.stops)
        ),
        Def::RadialGradient(g) => format!(
            "{{ type = \"radial_gradient\", id = {}, cx = {}, cy = {}, r = {}, fx = {}, fy = {}{}{}, stops = {} }}",
            quote(&g.id),
            num(g.cx),
            num(g.cy),
            num(g.r),
            num(g.fx),
            num(g.fy),
            if g.fr > 0.0 { format!(", fr = {}", num(g.fr)) } else { String::new() },
            gradient_space(g.units, g.spread, &g.transform),
            stops_array(&g.stops)
        ),
        Def::ConicGradient(g) => format!(
            "{{ type = \"conic_gradient\", id = {}, cx = {}, cy = {}, angle = {}, stops = {} }}",
            quote(&g.id),
            num(g.cx),
            num(g.cy),
            num(g.angle),
            stops_array(&g.stops)
        ),
        Def::Shader(_) => return Err(WriteError::Unsupported("shader defs".into())),
        Def::Audio(_) => return Err(WriteError::Unsupported("audio defs".into())),
    })
}

// ── Elements ─────────────────────────────────────────────────────────────────

fn blend_mode_text(b: BlendMode) -> &'static str {
    match b {
        BlendMode::Normal => "normal",
        BlendMode::Multiply => "multiply",
        BlendMode::Screen => "screen",
        BlendMode::Overlay => "overlay",
        BlendMode::Add => "add",
        BlendMode::SoftLight => "soft_light",
        BlendMode::HardLight => "hard_light",
        BlendMode::Difference => "difference",
        BlendMode::Exclusion => "exclusion",
        BlendMode::Darken => "darken",
        BlendMode::Lighten => "lighten",
        BlendMode::Subtract => "subtract",
        BlendMode::Divide => "divide",
        BlendMode::ColorDodge => "color_dodge",
        BlendMode::ColorBurn => "color_burn",
        BlendMode::Hue => "hue",
        BlendMode::Saturation => "saturation",
        BlendMode::Color => "color",
        BlendMode::Luminosity => "luminosity",
        BlendMode::PlusLighter => "plus_lighter",
    }
}

fn path_data(cmds: &[PathCommand]) -> String {
    let p = |pt: &Point| format!("{} {}", num(pt.x), num(pt.y));
    cmds.iter()
        .map(|c| match c {
            PathCommand::MoveTo(a) => format!("M {}", p(a)),
            PathCommand::LineTo(a) => format!("L {}", p(a)),
            PathCommand::HLineTo(x) => format!("H {}", num(*x)),
            PathCommand::VLineTo(y) => format!("V {}", num(*y)),
            PathCommand::CubicBezier { c1, c2, to } => format!("C {} {} {}", p(c1), p(c2), p(to)),
            PathCommand::SmoothCubic { c2, to } => format!("S {} {}", p(c2), p(to)),
            PathCommand::QuadBezier { c, to } => format!("Q {} {}", p(c), p(to)),
            PathCommand::SmoothQuad { to } => format!("T {}", p(to)),
            PathCommand::Arc { rx, ry, x_rotation, large_arc, sweep, to } => {
                format!("A {} {} {} {} {} {}", num(*rx), num(*ry), num(*x_rotation), *large_arc as u8, *sweep as u8, p(to))
            }
            PathCommand::RelMoveTo(a) => format!("m {}", p(a)),
            PathCommand::RelLineTo(a) => format!("l {}", p(a)),
            PathCommand::RelHLineTo(x) => format!("h {}", num(*x)),
            PathCommand::RelVLineTo(y) => format!("v {}", num(*y)),
            PathCommand::RelCubicBezier { c1, c2, to } => format!("c {} {} {}", p(c1), p(c2), p(to)),
            PathCommand::RelSmoothCubic { c2, to } => format!("s {} {}", p(c2), p(to)),
            PathCommand::RelQuadBezier { c, to } => format!("q {} {}", p(c), p(to)),
            PathCommand::RelSmoothQuad { to } => format!("t {}", p(to)),
            PathCommand::RelArc { rx, ry, x_rotation, large_arc, sweep, to } => {
                format!("a {} {} {} {} {} {}", num(*rx), num(*ry), num(*x_rotation), *large_arc as u8, *sweep as u8, p(to))
            }
            PathCommand::ClosePath => "Z".to_string(),
        })
        .collect::<Vec<_>>()
        .join(" ")
}

/// `id`, `transform` and `style` tails shared by every element.
fn common(id: &Option<String>, transform: &Option<Transform>, style: Option<&Style>) -> String {
    let mut s = String::new();
    if let Some(id) = id {
        let _ = write!(s, ", id = {}", quote(id));
    }
    if let Some(t) = transform.as_ref().and_then(transform_text) {
        let _ = write!(s, ", transform = {}", quote(&t));
    }
    if let Some(style) = style.and_then(style_object) {
        let _ = write!(s, ", style = {style}");
    }
    s
}

fn anchor_text(a: Anchor) -> &'static str {
    match a {
        Anchor::TopLeft => "top_left",
        Anchor::Top => "top",
        Anchor::TopRight => "top_right",
        Anchor::Left => "left",
        Anchor::Center => "center",
        Anchor::Right => "right",
        Anchor::BottomLeft => "bottom_left",
        Anchor::Bottom => "bottom",
        Anchor::BottomRight => "bottom_right",
    }
}

fn pad(n: usize) -> String {
    " ".repeat(n)
}

/// Write one element at `indent` spaces. `comma` adds a trailing comma, for
/// entries inside a `[...]` array.
fn write_element(out: &mut String, el: &Element, indent: usize, comma: bool) -> Result<(), WriteError> {
    let tail = if comma { "," } else { "" };
    match el {
        Element::Rect(e) => {
            let mut s = format!("{{ type = \"rect\", x = {}, y = {}, width = {}, height = {}", num(e.x), num(e.y), num(e.width), num(e.height));
            if let Some(rx) = e.rx {
                let _ = write!(s, ", rx = {}", num(rx));
            }
            if let Some(ry) = e.ry {
                let _ = write!(s, ", ry = {}", num(ry));
            }
            let _ = write!(out, "{}{}{} }}{tail}", pad(indent), s, common(&e.id, &e.transform, Some(&e.style)));
        }
        Element::Circle(e) => {
            let s = format!("{{ type = \"circle\", cx = {}, cy = {}, r = {}", num(e.cx), num(e.cy), num(e.r));
            let _ = write!(out, "{}{}{} }}{tail}", pad(indent), s, common(&e.id, &e.transform, Some(&e.style)));
        }
        Element::Ellipse(e) => {
            let s = format!("{{ type = \"ellipse\", cx = {}, cy = {}, rx = {}, ry = {}", num(e.cx), num(e.cy), num(e.rx), num(e.ry));
            let _ = write!(out, "{}{}{} }}{tail}", pad(indent), s, common(&e.id, &e.transform, Some(&e.style)));
        }
        Element::Line(e) => {
            let s = format!("{{ type = \"line\", x1 = {}, y1 = {}, x2 = {}, y2 = {}", num(e.x1), num(e.y1), num(e.x2), num(e.y2));
            let _ = write!(out, "{}{}{} }}{tail}", pad(indent), s, common(&e.id, &e.transform, Some(&e.style)));
        }
        Element::Polyline(e) | Element::Polygon(e) => {
            let kind = if e.closed { "polygon" } else { "polyline" };
            let pts: Vec<String> = e.points.iter().map(|p| format!("[{}, {}]", float(p.x), float(p.y))).collect();
            let s = format!("{{ type = \"{kind}\", points = [{}]", pts.join(", "));
            let _ = write!(out, "{}{}{} }}{tail}", pad(indent), s, common(&e.id, &e.transform, Some(&e.style)));
        }
        Element::Path(e) => {
            let d = if e.d_raw.is_empty() { path_data(&e.commands) } else { e.d_raw.clone() };
            let s = format!("{{ type = \"path\", d = {}", quote(&d));
            let _ = write!(out, "{}{}{} }}{tail}", pad(indent), s, common(&e.id, &e.transform, Some(&e.style)));
        }
        Element::Text(e) => {
            let s = format!("{{ type = \"text\", x = {}, y = {}, content = {}", num(e.x), num(e.y), quote(&e.content));
            let _ = write!(out, "{}{}{} }}{tail}", pad(indent), s, common(&e.id, &e.transform, Some(&e.style)));
        }
        Element::Use(e) => {
            let s = format!("{{ type = \"use\", href = {}, x = {}, y = {}", quote(&e.href), num(e.x), num(e.y));
            let _ = write!(out, "{}{}{} }}{tail}", pad(indent), s, common(&e.id, &e.transform, None));
        }
        Element::Group(g) => write_group(out, g, indent, tail)?,
        Element::Layer(l) => write_layer(out, l, indent, tail)?,
        Element::Sdf(_) => return Err(WriteError::Unsupported("sdf elements".into())),
        Element::Splat(_) => return Err(WriteError::Unsupported("splat elements".into())),
        Element::Image(e) => {
            let mut s = format!("{{ type = \"image\", x = {}, y = {}, width = {}, height = {}", num(e.x), num(e.y), num(e.width), num(e.height));
            if e.anchor != Anchor::TopLeft {
                let _ = write!(s, ", anchor = {}", quote(anchor_text(e.anchor)));
            }
            match &e.source {
                MediaSource::Embedded(bytes) => {
                    if ImageFormat::sniff(bytes).is_none() {
                        return Err(WriteError::Unsupported("image data that is not PNG or JPEG".into()));
                    }
                    use base64::{engine::general_purpose::STANDARD, Engine as _};
                    let _ = write!(s, ", data = {}", quote(&STANDARD.encode(bytes)));
                }
                MediaSource::FileRef(path) => {
                    let _ = write!(s, ", source_ref = {}", quote(path));
                }
            }
            let _ = write!(out, "{}{}{} }}{tail}", pad(indent), s, common(&e.id, &e.transform, Some(&e.style)));
        }
    }
    Ok(())
}

fn write_children(out: &mut String, children: &[Element], indent: usize) -> Result<(), WriteError> {
    write_element_list(out, "elements", children, indent)
}

fn write_element_list(out: &mut String, field: &str, children: &[Element], indent: usize) -> Result<(), WriteError> {
    out.push_str(&format!("{}{} = [\n", pad(indent), field));
    for (i, child) in children.iter().enumerate() {
        write_element(out, child, indent + 2, i + 1 < children.len())?;
        out.push('\n');
    }
    out.push_str(&format!("{}]", pad(indent)));
    Ok(())
}

fn write_group(out: &mut String, g: &Group, indent: usize, tail: &str) -> Result<(), WriteError> {
    let mut head = common(&g.id, &g.transform, g.style.as_ref());
    // A group style that is all defaults still has to be written, or the
    // parser reads the group back without one. Leaves never need this,
    // because the parser always builds a style for them.
    if g.style.as_ref().is_some_and(|s| style_object(s).is_none()) {
        head.push_str(", style = { }");
    }
    let _ = write!(out, "{}{{ type = \"group\"{}", pad(indent), head);
    out.push_str(",\n");
    write_children(out, &g.children, indent + 2)?;
    let _ = write!(out, " }}{tail}");
    Ok(())
}

/// One animation track, with a keyframe per line. Easing is written only when
/// it is not the linear default, which is also what the parser assumes.
fn write_track(out: &mut String, t: &AnimationTrack) {
    let _ = writeln!(out, "    {{ target_id = {}, property = {},", quote(&t.target_id), quote(t.property.to_dixscript_str()));
    out.push_str("      keyframes = [\n");
    for (i, k) in t.keyframes.iter().enumerate() {
        let easing = if k.easing == Easing::Linear { String::new() } else { format!(", easing = {}", quote(k.easing.to_dixscript_str())) };
        let comma = if i + 1 < t.keyframes.len() { "," } else { "" };
        let _ = writeln!(out, "        {{ time = {}, value = {}{easing} }}{comma}", float(k.time), float(k.value));
    }
    out.push_str("      ] }\n");
}

/// The `effects` list of a layer, one effect per line. The field names are the
/// ones `parse_effect` reads.
fn write_effects(out: &mut String, effects: &[msx_ast::Effect], indent: usize) {
    use msx_ast::Effect;
    let _ = writeln!(out, "{}effects = [", pad(indent));
    for (i, fx) in effects.iter().enumerate() {
        let body = match fx {
            Effect::Blur { radius } => format!("type = \"blur\", radius = {}", float(*radius)),
            Effect::DropShadow { offset_x, offset_y, blur_radius, color, opacity } => format!(
                "type = \"drop_shadow\", offset_x = {}, offset_y = {}, blur_radius = {}, color = {}, opacity = {}",
                float(*offset_x), float(*offset_y), float(*blur_radius), color_value(*color), float(*opacity)
            ),
            Effect::InnerShadow { offset_x, offset_y, blur_radius, color, opacity } => format!(
                "type = \"inner_shadow\", offset_x = {}, offset_y = {}, blur_radius = {}, color = {}, opacity = {}",
                float(*offset_x), float(*offset_y), float(*blur_radius), color_value(*color), float(*opacity)
            ),
            Effect::OuterGlow { color, blur_radius, spread, opacity } => format!(
                "type = \"outer_glow\", color = {}, blur_radius = {}, spread = {}, opacity = {}",
                color_value(*color), float(*blur_radius), float(*spread), float(*opacity)
            ),
            Effect::InnerGlow { color, blur_radius, opacity } => format!(
                "type = \"inner_glow\", color = {}, blur_radius = {}, opacity = {}",
                color_value(*color), float(*blur_radius), float(*opacity)
            ),
            Effect::BlurXY { rx, ry } => format!("type = \"blur_xy\", rx = {}, ry = {}", float(*rx), float(*ry)),
            Effect::ColorMatrix { values, linear } => format!(
                "type = \"color_matrix\", linear = {linear}, values = [{}]",
                values.iter().map(|v| float(*v)).collect::<Vec<_>>().join(", ")
            ),
            Effect::Graph(g) => graph_text(g),
        };
        let comma = if i + 1 < effects.len() { "," } else { "" };
        let _ = writeln!(out, "{}{{ {body} }}{comma}", pad(indent + 2));
    }
    let _ = writeln!(out, "{}],", pad(indent));
}

fn write_layer(out: &mut String, l: &Layer, indent: usize, tail: &str) -> Result<(), WriteError> {
    let mut head = format!("{}{{ type = \"layer\", blend_mode = {}, opacity = {}", pad(indent), quote(blend_mode_text(l.blend_mode)), num(l.opacity));
    if l.mask_type != msx_ast::MaskType::Luminance {
        head.push_str(&format!(", mask_type = {}", quote(l.mask_type.as_str())));
    }
    if l.z_index != 0.0 {
        let _ = write!(head, ", z_index = {}", num(l.z_index));
    }
    if l.clip {
        head.push_str(", clip = true");
    }
    out.push_str(&head);
    out.push_str(&common(&l.id, &l.transform, None));
    out.push_str(",\n");
    if let Some(shapes) = &l.clip_path {
        write_element_list(out, "clip_path", shapes, indent + 2)?;
        out.push_str(",\n");
    }
    if let Some(elements) = &l.mask {
        write_element_list(out, "mask", elements, indent + 2)?;
        out.push_str(",\n");
    }
    if !l.effects.is_empty() {
        write_effects(out, &l.effects, indent + 2);
    }
    write_children(out, &l.children, indent + 2)?;
    let _ = write!(out, " }}{tail}");
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::parse_scene;
    use msx_ast::{
        Canvas, Circle, ConicGradient, Ellipse, FillRule, Group, LineCap, LineJoin, LinearGradient, Matrix2D, Path, Polyline, RadialGradient,
        Rect, Text, TextAnchor, Use, ViewBox,
    };

    fn style() -> Style {
        Style::default()
    }

    fn scene_with(defs: Vec<Def>, elements: Vec<Element>) -> Scene {
        let mut s = Scene::new(Canvas::new(120.0, 80.0, Color::WHITE));
        s.defs = defs;
        s.elements = elements;
        s
    }

    /// Write, parse back, and require the parsed scene to equal the
    /// original. The AST has no `PartialEq`, so compare `Debug` output,
    /// which prints floats as the shortest text that round-trips.
    fn assert_roundtrip(scene: &Scene) {
        let text = scene_to_msx(scene).expect("scene should be writable");
        let back = parse_scene(&text).unwrap_or_else(|e| panic!("written source must parse: {e}\n{text}"));
        assert_eq!(format!("{:?}", scene.canvas), format!("{:?}", back.canvas), "canvas\n{text}");
        assert_eq!(format!("{:?}", scene.defs), format!("{:?}", back.defs), "defs\n{text}");
        assert_eq!(format!("{:?}", scene.elements), format!("{:?}", back.elements), "elements\n{text}");
    }

    fn rect(style: Style) -> Element {
        Element::Rect(Rect { x: 1.5, y: 2.0, width: 30.25, height: 40.0, rx: Some(3.0), ry: None, id: Some("r1".into()), transform: None, style })
    }

    #[test]
    fn every_shape_roundtrips() {
        let mut st = style();
        st.fill = Some(Paint::Color(Color::rgb(233, 69, 96)));
        st.stroke = Some(Paint::Color(Color::rgb(0, 0, 0)));
        st.stroke_width = Some(2.5);
        let elements = vec![
            rect(st.clone()),
            Element::Circle(Circle { cx: 10.0, cy: 20.0, r: 5.5, id: None, transform: None, style: st.clone() }),
            Element::Ellipse(Ellipse { cx: 1.0, cy: 2.0, rx: 3.0, ry: 4.0, id: None, transform: None, style: st.clone() }),
            Element::Line(msx_ast::Line { x1: 0.0, y1: 0.0, x2: 9.0, y2: -9.0, id: None, transform: None, style: st.clone() }),
            Element::Polyline(Polyline { points: vec![Point::new(0.0, 0.0), Point::new(5.0, 5.5), Point::new(9.0, 0.0)], closed: false, id: None, transform: None, style: st.clone() }),
            Element::Polygon(Polyline { points: vec![Point::new(0.0, 0.0), Point::new(5.0, 5.0), Point::new(9.0, 0.0)], closed: true, id: None, transform: None, style: st.clone() }),
        ];
        assert_roundtrip(&scene_with(vec![], elements));
    }

    #[test]
    fn path_text_and_use_roundtrip() {
        let d = "M 10 10 h 20 v -5 c 1 2 3 4 5 6 a 5 5 0 1 0 10 10 Z".to_string();
        let path = Element::Path(Path { commands: msx_ast::path::parse_d(&d).unwrap(), d_raw: d, id: Some("p".into()), transform: None, style: style() });
        let mut ts = style();
        ts.font_size = Some(18.0);
        ts.font_family = Some("DejaVu Sans, sans-serif".into());
        ts.font_weight = Some(FontWeight::Numeric(700));
        ts.text_anchor = Some(TextAnchor::Middle);
        ts.dominant_baseline = Some("middle".into());
        let text = Element::Text(Text { x: 60.0, y: 40.0, content: "Hello".into(), id: None, transform: None, style: ts });
        let u = Element::Use(Use { href: "#p".into(), x: 5.0, y: 6.0, id: None, transform: Some(Transform::Scale { x: 2.0, y: 2.0 }) });
        assert_roundtrip(&scene_with(vec![], vec![path, text, u]));
    }

    #[test]
    fn style_fields_roundtrip() {
        let mut st = style();
        st.fill = Some(Paint::Ref("url(#g)".into()));
        st.stroke = Some(Paint::CurrentColor);
        st.stroke_width = Some(0.0);
        st.opacity = Some(0.5);
        st.fill_opacity = Some(0.25);
        st.stroke_opacity = Some(0.75);
        st.fill_rule = Some(FillRule::EvenOdd);
        st.stroke_linecap = Some(LineCap::Round);
        st.stroke_linejoin = Some(LineJoin::Bevel);
        st.stroke_miterlimit = Some(7.5);
        st.stroke_dasharray = Some(vec![4.0, 2.0, 1.5]);
        st.stroke_dashoffset = Some(3.0);
        st.visibility_hidden = true;
        st.display_none = true;
        assert_roundtrip(&scene_with(vec![], vec![rect(st)]));
    }

    #[test]
    fn colors_with_alpha_roundtrip() {
        let mut st = style();
        st.fill = Some(Paint::Color(Color::rgba(10, 20, 30, 128)));
        st.stroke = Some(Paint::Color(Color::rgba(255, 255, 255, 1)));
        let mut s = scene_with(vec![], vec![rect(st)]);
        s.canvas.background = Color::rgba(1, 2, 3, 4);
        assert_roundtrip(&s);
    }

    #[test]
    fn gradients_roundtrip_including_stop_alpha() {
        let stops = vec![Stop::new(0.0, Color::rgb(255, 0, 0)), Stop::new(0.4, Color::rgba(0, 255, 0, 100)), Stop::new(1.0, Color::rgba(0, 0, 255, 0))];
        let defs = vec![
            Def::LinearGradient(LinearGradient::new("l".into(), 0.1, 0.2, 0.9, 0.8, stops.clone())),
            Def::RadialGradient(RadialGradient::new("r".into(), 0.5, 0.5, 0.4, 0.3, 0.35, stops.clone())),
            Def::ConicGradient(ConicGradient::new("c".into(), 0.5, 0.5, 45.0, stops)),
        ];
        assert_roundtrip(&scene_with(defs, vec![]));
    }

    #[test]
    fn gradient_units_spread_and_transform_roundtrip() {
        let stops = vec![Stop::new(0.0, Color::rgb(255, 0, 0)), Stop::new(1.0, Color::rgb(0, 0, 255))];
        let m = Transform::Matrix(Matrix2D { a: 0.001, b: 0.25, c: -0.25, d: 1.5, e: 12.5, f: -3.0 });
        let defs = vec![
            Def::LinearGradient(LinearGradient::new("l".into(), 10.0, 0.0, 90.0, 0.0, stops.clone()).with_units(msx_ast::GradientUnits::UserSpace).with_spread(msx_ast::SpreadMethod::Reflect).with_transform(m.clone())),
            Def::RadialGradient(RadialGradient::new("r".into(), 0.5, 0.5, 0.4, 0.3, 0.35, stops.clone()).with_spread(msx_ast::SpreadMethod::Repeat).with_fr(0.125)),
            Def::RadialGradient(RadialGradient::new("t".into(), 0.5, 0.5, 0.5, 0.5, 0.5, stops).with_transform(Transform::Rotate { angle: 30.0, cx: None, cy: None })),
        ];
        assert_roundtrip(&scene_with(defs, vec![]));
    }

    #[test]
    fn a_default_gradient_is_written_without_the_new_keys() {
        let stops = vec![Stop::new(0.0, Color::rgb(255, 0, 0)), Stop::new(1.0, Color::rgb(0, 0, 255))];
        let text = scene_to_msx(&scene_with(vec![Def::LinearGradient(LinearGradient::new("l".into(), 0.0, 0.0, 1.0, 0.0, stops))], vec![])).unwrap();
        assert!(!text.contains("units") && !text.contains("spread") && !text.contains("transform"), "{text}");
    }

    #[test]
    fn nested_groups_and_layers_roundtrip() {
        let inner = Element::Group(Group { children: vec![rect(style())], id: Some("inner".into()), transform: Some(Transform::Translate { x: 3.0, y: 4.0 }), style: None });
        let mut layer = Layer::new(vec![inner.clone(), rect(style())]);
        layer.opacity = 0.4;
        layer.blend_mode = BlendMode::Multiply;
        layer.z_index = 2.0;
        layer.clip = true;
        layer.id = Some("lay".into());
        let outer = Element::Group(Group { children: vec![inner, Element::Layer(layer)], id: None, transform: None, style: Some(style()) });
        assert_roundtrip(&scene_with(vec![], vec![outer]));
    }

    #[test]
    fn every_blend_mode_roundtrips_through_text() {
        let layers = BlendMode::ALL
            .iter()
            .map(|m| {
                let mut l = Layer::new(vec![rect(style())]);
                l.blend_mode = *m;
                Element::Layer(l)
            })
            .collect();
        assert_roundtrip(&scene_with(vec![], layers));
    }

    #[test]
    fn transforms_roundtrip_without_rounding() {
        let list = Transform::Multiple(vec![
            Transform::Translate { x: 10.123456789, y: -0.000123 },
            Transform::Rotate { angle: 33.3333333, cx: Some(5.0), cy: Some(6.0) },
            Transform::Scale { x: 1.5, y: 0.25 },
            Transform::SkewX(10.0),
            Transform::Matrix(Matrix2D { a: 0.9999999, b: 0.0001, c: -0.0001, d: 0.9999999, e: 100.5, f: -7.25 }),
        ]);
        let el = Element::Rect(Rect { x: 0.0, y: 0.0, width: 1.0, height: 1.0, rx: None, ry: None, id: None, transform: Some(list), style: style() });
        assert_roundtrip(&scene_with(vec![], vec![el]));
    }

    #[test]
    fn numbers_keep_full_precision() {
        let el = Element::Circle(Circle { cx: 0.123456789012, cy: 12345.6789, r: 1e-7, id: None, transform: None, style: style() });
        assert_roundtrip(&scene_with(vec![], vec![el]));
    }

    #[test]
    fn awkward_strings_roundtrip() {
        let nasty = "quote \" backslash \\ newline \n tab \t brace {x} slash // hash # dollar $ unicode é ñ 日本 emoji 🎉 end";
        let mut st = style();
        st.font_family = Some("Fira \"Code\", 'Mono'".into());
        let el = Element::Text(Text { x: 1.0, y: 2.0, content: nasty.into(), id: Some("id \"x\"".into()), transform: None, style: st });
        assert_roundtrip(&scene_with(vec![], vec![el]));
    }

    #[test]
    fn viewbox_roundtrips() {
        let mut s = scene_with(vec![], vec![rect(style())]);
        s.canvas.viewbox = Some(ViewBox::new(-5.0, 10.0, 24.0, 24.0));
        assert_roundtrip(&s);
    }

    #[test]
    fn layer_clip_paths_roundtrip_including_the_empty_one() {
        let mut even = style();
        even.fill_rule = Some(FillRule::EvenOdd);
        let shapes = vec![
            rect(style()),
            Element::Circle(Circle { cx: 5.0, cy: 6.0, r: 7.5, id: None, transform: Some(Transform::Translate { x: 1.0, y: 2.0 }), style: even }),
        ];
        let clipped = Layer::new(vec![rect(style())]).with_clip_path(shapes);
        let nothing = Layer::new(vec![rect(style())]).with_clip_path(vec![]);
        let plain = Layer::new(vec![rect(style())]);
        assert_roundtrip(&scene_with(vec![], vec![Element::Layer(clipped), Element::Layer(nothing), Element::Layer(plain)]));
    }

    #[test]
    fn images_roundtrip_embedded_and_by_path_with_anchor_and_style() {
        use msx_ast::{Anchor, Image, MediaSource};
        let png = vec![0x89, b'P', b'N', b'G', 0x0D, 0x0A, 0x1A, 0x0A, 1, 2, 3, 255, 0];
        let mut a = Image::new(MediaSource::Embedded(png), 1.5, 2.0, 30.0, 40.5);
        a.id = Some("pic".into());
        a.transform = Some(Transform::Translate { x: 3.0, y: 4.0 });
        a.anchor = Anchor::Center;
        a.style.opacity = Some(0.5);
        let b = Image::new(MediaSource::FileRef("assets/a b.png".into()), 0.0, 0.0, 5.0, 5.0);
        let jpeg = Image::new(MediaSource::Embedded(vec![0xFF, 0xD8, 0xFF, 0xE0, 0, 0x10]), 0.0, 0.0, 2.0, 2.0);
        assert_roundtrip(&scene_with(vec![], vec![Element::Image(a), Element::Image(b), Element::Image(jpeg)]));
    }

    #[test]
    fn image_bytes_that_are_not_png_or_jpeg_are_refused_not_written() {
        use msx_ast::{Image, MediaSource};
        let gif = Image::new(MediaSource::Embedded(b"GIF89a".to_vec()), 0.0, 0.0, 1.0, 1.0);
        let err = scene_to_msx(&scene_with(vec![], vec![Element::Image(gif)])).unwrap_err();
        assert!(matches!(err, WriteError::Unsupported(w) if w.contains("PNG or JPEG")));
    }

    #[test]
    fn layer_masks_roundtrip_with_their_type() {
        let content = vec![rect(style()), Element::Circle(Circle { cx: 1.0, cy: 2.0, r: 3.0, id: None, transform: None, style: style() })];
        let luminance = Layer::new(vec![rect(style())]).with_mask(content.clone(), msx_ast::MaskType::Luminance);
        let alpha = Layer::new(vec![rect(style())]).with_mask(content, msx_ast::MaskType::Alpha).with_clip_path(vec![rect(style())]);
        let nothing = Layer::new(vec![]).with_mask(vec![], msx_ast::MaskType::Luminance);
        assert_roundtrip(&scene_with(vec![], vec![Element::Layer(luminance), Element::Layer(alpha), Element::Layer(nothing)]));
    }

    #[test]
    fn an_empty_clip_path_stays_empty_and_no_clip_path_stays_none() {
        let s = scene_with(vec![], vec![Element::Layer(Layer::new(vec![]).with_clip_path(vec![])), Element::Layer(Layer::new(vec![]))]);
        let back = parse_scene(&scene_to_msx(&s).unwrap()).unwrap();
        let clips: Vec<Option<usize>> = back.elements.iter().map(|e| match e { Element::Layer(l) => l.clip_path.as_ref().map(Vec::len), _ => panic!("layer") }).collect();
        assert_eq!(clips, vec![Some(0), None]);
    }

    #[test]
    fn empty_scene_roundtrips() {
        assert_roundtrip(&scene_with(vec![], vec![]));
    }

    #[test]
    fn unsupported_content_is_refused_not_dropped() {
        let sdf = Element::Sdf(msx_ast::SdfNode::new(msx_ast::SdfTree::Circle { cx: 0.0, cy: 0.0, r: 1.0 }, Paint::None));
        let err = scene_to_msx(&scene_with(vec![], vec![sdf])).unwrap_err();
        assert_eq!(err, WriteError::Unsupported("sdf elements".into()));
    }

    #[test]
    fn layer_effects_roundtrip() {
        use msx_ast::Effect;
        let mut layer = Layer::new(vec![rect(style())]);
        layer.effects = vec![
            Effect::Blur { radius: 2.5 },
            Effect::DropShadow { offset_x: 3.0, offset_y: -2.0, blur_radius: 4.0, color: Color::rgb(10, 20, 30), opacity: 0.75 },
            Effect::InnerShadow { offset_x: 0.0, offset_y: 1.0, blur_radius: 2.0, color: Color::BLACK, opacity: 0.5 },
            Effect::OuterGlow { color: Color::WHITE, blur_radius: 8.0, spread: 1.0, opacity: 0.75 },
            Effect::InnerGlow { color: Color::rgb(255, 0, 0), blur_radius: 3.0, opacity: 1.0 },
            Effect::BlurXY { rx: 4.0, ry: 0.0 },
            Effect::ColorMatrix { values: [0.2126, 0.7152, 0.0722, 0.0, 0.0, 0.2126, 0.7152, 0.0722, 0.0, 0.0, 0.2126, 0.7152, 0.0722, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, -0.125], linear: true },
        ];
        assert_roundtrip(&scene_with(vec![], vec![Element::Layer(layer)]));
    }

    fn sample_graph() -> msx_ast::FilterGraph {
        use msx_ast::{BlendMode, CompositeOp, FilterGraph, FilterInput as In, FilterNode, FilterOp, FilterRegion, TransferFn};
        let mut flood = FilterNode::new(FilterOp::Flood { color: Color::rgba(10, 20, 30, 128) });
        flood.region = Some(FilterRegion { x: 1.5, y: 2.0, width: 30.0, height: 40.0 });
        let mut arithmetic = FilterNode::new(FilterOp::Composite { a: In::Node(0), b: In::SourceAlpha, op: CompositeOp::Arithmetic { k1: 0.0, k2: 1.0, k3: 0.5, k4: -0.25 } });
        arithmetic.linear = true;
        FilterGraph {
            nodes: vec![
                flood,
                arithmetic,
                FilterNode::new(FilterOp::Composite { a: In::SourceGraphic, b: In::Node(1), op: CompositeOp::Xor }),
                FilterNode::new(FilterOp::Merge { inputs: vec![In::Node(1), In::Node(2), In::SourceGraphic] }),
                FilterNode::new(FilterOp::Blend { a: In::Node(3), b: In::SourceGraphic, mode: BlendMode::Multiply }),
                FilterNode::new(FilterOp::Offset { input: In::Node(4), dx: 3.0, dy: -2.5 }),
                FilterNode::new(FilterOp::Blur { input: In::Node(5), rx: 2.0, ry: 0.0 }),
                FilterNode::new(FilterOp::ColorMatrix { input: In::Node(6), values: [0.5; 20] }),
                FilterNode::new(FilterOp::ComponentTransfer {
                    input: In::Node(7),
                    funcs: [TransferFn::Identity, TransferFn::Table(vec![0.0, 0.5, 1.0]), TransferFn::Discrete(vec![0.25, 0.75]), TransferFn::Linear { slope: 0.5, intercept: 0.25 }],
                }),
                FilterNode::new(FilterOp::ComponentTransfer {
                    input: In::SourceGraphic,
                    funcs: [TransferFn::Gamma { amplitude: 1.0, exponent: 2.0, offset: 0.0 }, TransferFn::Identity, TransferFn::Identity, TransferFn::Identity],
                }),
            ],
        }
    }

    #[test]
    fn a_filter_graph_roundtrips_through_source() {
        let mut layer = Layer::new(vec![rect(style())]);
        layer.effects = vec![msx_ast::Effect::Blur { radius: 1.0 }, msx_ast::Effect::Graph(sample_graph())];
        assert_roundtrip(&scene_with(vec![], vec![Element::Layer(layer)]));
    }

    #[test]
    fn a_filter_graph_in_source_reads_defaults_and_refuses_what_is_wrong() {
        let wrap = |nodes: &str| {
            format!(
                "@CONFIG( version -> \"1.0.0\" )\n@DATA(\n  scene = {{ width = 10, height = 10, background = #ffffff }}\n  elements::\n    {{ type = \"layer\", effects = [ {{ type = \"graph\", nodes = [{nodes}] }} ], elements = [ {{ type = \"rect\", x = 0, y = 0, width = 5, height = 5 }} ] }}\n)\n"
            )
        };
        let graph_of = |nodes: &str| -> Result<msx_ast::FilterGraph, String> {
            let scene = parse_scene(&wrap(nodes))?;
            match &scene.elements[0] {
                Element::Layer(l) => match &l.effects[0] {
                    msx_ast::Effect::Graph(g) => Ok(g.clone()),
                    other => panic!("{other:?}"),
                },
                other => panic!("{other:?}"),
            }
        };
        // No input reads the node before, and the first node reads the source.
        let g = graph_of(r#"{ op = "blur", rx = 2.0, ry = 2.0 }, { op = "offset", dx = 1.0, dy = 0.0 }"#).unwrap();
        assert!(matches!(g.nodes[0].op, msx_ast::FilterOp::Blur { input: msx_ast::FilterInput::SourceGraphic, .. }));
        assert!(matches!(g.nodes[1].op, msx_ast::FilterOp::Offset { input: msx_ast::FilterInput::Node(0), .. }));
        for (bad, needle) in [
            (r#"{ op = "qwe" }"#, "unknown filter op"),
            (r#"{ rx = 1.0 }"#, "needs `op`"),
            (r#"{ op = "offset", input = "7" }"#, "not before it"),
            (r#"{ op = "offset", input = "fill" }"#, "not source, alpha or a node index"),
            (r#"{ op = "color_matrix", values = [1.0, 2.0] }"#, "20 values"),
            (r#"{ op = "composite", operator = "nope" }"#, "unknown composite operator"),
            (r#"{ op = "flood", region = [1.0, 2.0] }"#, "expected [x, y, width, height]"),
            (r#"{ op = "flood", region = [0.0, 0.0, 0.0, 5.0] }"#, "region"),
        ] {
            let err = graph_of(bad).unwrap_err();
            assert!(err.contains(needle), "{bad}: {err}");
        }
    }

    #[test]
    fn layer_effects_sit_beside_clip_and_mask() {
        let mut layer = Layer::new(vec![rect(style())]);
        layer.effects = vec![msx_ast::Effect::Blur { radius: 4.0 }];
        layer.clip_path = Some(vec![rect(style())]);
        layer.mask = Some(vec![rect(style())]);
        assert_roundtrip(&scene_with(vec![], vec![Element::Layer(layer)]));
    }

    fn animated_scene() -> Scene {
        use msx_ast::{AnimatedProperty, Keyframe};
        let mut s = scene_with(vec![], vec![rect(style())]);
        s.duration = 2.5;
        s.loop_mode = LoopMode::PingPong;
        s.animations = vec![
            AnimationTrack::new("r1", AnimatedProperty::Rotate, vec![Keyframe::linear(0.0, 0.0), Keyframe::new(2.5, 360.0, Easing::EaseInOut)]),
            AnimationTrack::new("r1", AnimatedProperty::Opacity, vec![Keyframe::linear(0.0, 1.0), Keyframe::new(1.25, 0.125, Easing::EaseOut), Keyframe::linear(2.5, 1.0)]),
            AnimationTrack::new("a \"quoted\" id", AnimatedProperty::TranslateX, vec![Keyframe::linear(0.0, -3.5)]),
        ];
        s
    }

    #[test]
    fn animations_roundtrip() {
        let s = animated_scene();
        let text = scene_to_msx(&s).unwrap();
        let back = parse_scene(&text).unwrap_or_else(|e| panic!("written source must parse: {e}\n{text}"));
        assert_eq!(back.duration, 2.5);
        assert_eq!(back.loop_mode, LoopMode::PingPong);
        assert_eq!(format!("{:?}", s.animations), format!("{:?}", back.animations), "{text}");
        assert_eq!(format!("{:?}", s.elements), format!("{:?}", back.elements));
    }

    #[test]
    fn timeline_keys_are_left_out_when_default() {
        let text = scene_to_msx(&scene_with(vec![], vec![rect(style())])).unwrap();
        assert!(!text.contains("duration") && !text.contains("loop_mode") && !text.contains("animations"), "{text}");
        let mut s = scene_with(vec![], vec![]);
        s.duration = 2.0;
        let text = scene_to_msx(&s).unwrap();
        assert!(text.contains("duration = 2.0") && !text.contains("loop_mode"), "{text}");
        assert_eq!(parse_scene(&text).unwrap().duration, 2.0);
    }

    #[test]
    fn a_track_with_many_keyframes_roundtrips() {
        use msx_ast::{AnimatedProperty, Keyframe};
        let mut s = scene_with(vec![], vec![rect(style())]);
        let kfs: Vec<Keyframe> = (0..300).map(|i| Keyframe::linear(f64::from(i) * 0.01, (f64::from(i) * 0.37).sin())).collect();
        s.animations = vec![AnimationTrack::new("r1", AnimatedProperty::TranslateY, kfs)];
        let text = scene_to_msx(&s).unwrap();
        let back = parse_scene(&text).unwrap();
        assert_eq!(format!("{:?}", s.animations), format!("{:?}", back.animations));
    }
}
