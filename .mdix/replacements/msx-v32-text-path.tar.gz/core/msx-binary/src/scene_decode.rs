// core/msx-binary/src/scene_decode.rs
//! Binary → Scene decoding. The complement of `compiler::compile`.

use std::io;

use msx_ast::{
    AnimatedProperty, AnimationTrack, Canvas, Circle, ConicGradient, Def, Easing, Element,
    Ellipse, GaussianSplat, GradientUnits, Group, Image, Keyframe, Layer, Line, LinearGradient,
    LoopMode, MediaSource, Path, Point, Polyline, RadialGradient, Rect, SdfNode, Scene, ShaderDef,
    ShaderUniform, ShaderUniformValue, SpreadMethod, Stop, Text, TextPath, Transform, Use, ViewBox,
};

use crate::decoder::*;
use crate::effect_codec::read_effect;
use crate::header::{MsxHeader, COMPRESS_MBFA, HEADER_SIZE};
use crate::path_codec::decode_commands;
use crate::sdf_codec::read_sdf_tree;
use crate::tags::*;

/// Decode a binary MSX file (header + optionally MBFA-compressed payload)
/// back into a Scene.
pub fn decode(data: &[u8]) -> io::Result<Scene> {
    let header = MsxHeader::parse(data)?;

    // Decompress payload if needed.
    let payload_raw = &data[HEADER_SIZE..];
    let payload_owned: Vec<u8>;
    let payload: &[u8] = if header.compress == COMPRESS_MBFA {
        payload_owned = mbfa::decompress(payload_raw).map_err(|e| {
            io::Error::new(io::ErrorKind::InvalidData, format!("MBFA decompress: {}", e))
        })?;
        &payload_owned
    } else {
        payload_raw
    };

    let mut cursor = 0;

    // Background
    let bg = read_color(payload, &mut cursor)?;

    // Viewbox
    let viewbox = if header.has_viewbox() {
        if cursor + 16 > payload.len() {
            return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "viewbox truncated"));
        }
        let bytes: [u8; 16] = payload[cursor..cursor + 16].try_into().unwrap();
        cursor += 16;
        Some(ViewBox::from_bytes(&bytes))
    } else {
        None
    };

    // String pool
    let pool = read_string_pool(payload, &mut cursor)?;

    // Defs
    let mut defs: Vec<Def> = Vec::with_capacity(header.def_count as usize);
    for _ in 0..header.def_count {
        defs.push(decode_def(payload, &mut cursor, &pool)?);
    }

    // Elements
    let mut elements: Vec<Element> = Vec::with_capacity(header.elem_count as usize);
    for _ in 0..header.elem_count {
        elements.push(decode_element(payload, &mut cursor, &pool)?);
    }

    // The element stream always ends with a TAG_END sentinel (see
    // `compiler::compile`) — the fixed-count loop above never reads it,
    // so it's still sitting right here, unconsumed. A file compiled
    // before the animation section existed ends right after this byte,
    // which is exactly why every read below is gated on
    // `header.has_animations()`: an old file's cursor lands at EOF here
    // and this function returns, same as it always has.
    let tag_end = read_u8(payload, &mut cursor)?;
    if tag_end != TAG_END {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("expected element-stream sentinel 0x{:02x}, got 0x{:02x}", TAG_END, tag_end),
        ));
    }

    let (duration, loop_mode, animations) = if header.has_animations() {
        decode_animations(payload, &mut cursor, &pool)?
    } else {
        (0.0, LoopMode::default(), Vec::new())
    };

    let mut canvas = Canvas::new(header.width as f64, header.height as f64, bg);
    canvas.viewbox = viewbox;

    let mut scene = Scene::new(canvas);
    scene.defs       = defs;
    scene.elements   = elements;
    scene.duration   = duration;
    scene.loop_mode  = loop_mode;
    scene.animations = animations;
    Ok(scene)
}

// ── Animation decoding ──────────────────────────────────────────────────────

/// The complement of `compiler::encode_animations`. Only called when
/// `header.has_animations()` — see that function's own comment for why
/// the section (and this call) is skipped entirely for a file compiled
/// before it existed.
fn decode_animations(
    data: &[u8],
    cursor: &mut usize,
    pool: &[String],
) -> io::Result<(f64, LoopMode, Vec<AnimationTrack>)> {
    let duration   = read_f32(data, cursor)?;
    let loop_mode  = LoopMode::from_byte(read_u8(data, cursor)?);
    let track_count = read_u16(data, cursor)? as usize;

    let mut tracks = Vec::with_capacity(track_count);
    for _ in 0..track_count {
        let target_idx = read_u16(data, cursor)?;
        let target_id  = lookup_string(pool, target_idx)?.to_string();

        let property_byte = read_u8(data, cursor)?;
        let property = AnimatedProperty::from_byte(property_byte).ok_or_else(|| {
            io::Error::new(
                io::ErrorKind::InvalidData,
                format!("unknown animated property byte 0x{:02x}", property_byte),
            )
        })?;

        let kf_count = read_u16(data, cursor)? as usize;
        let mut keyframes = Vec::with_capacity(kf_count);
        for _ in 0..kf_count {
            let time   = read_f32(data, cursor)?;
            let value  = read_f32(data, cursor)?;
            let easing = Easing::from_byte(read_u8(data, cursor)?);
            keyframes.push(Keyframe::new(time, value, easing));
        }

        tracks.push(AnimationTrack::new(target_id, property, keyframes));
    }

    Ok((duration, loop_mode, tracks))
}

// ── Def decoding ─────────────────────────────────────────────────────────────

/// The flags byte of a version 3 gradient and the transform it announces.
fn read_gradient_space(data: &[u8], cursor: &mut usize, radial: bool) -> io::Result<(GradientUnits, SpreadMethod, Option<Transform>, f64)> {
    let flags = read_u8(data, cursor)?;
    let units = if flags & GRAD_FLAG_USER_SPACE != 0 { GradientUnits::UserSpace } else { GradientUnits::ObjectBoundingBox };
    let spread = SpreadMethod::from_byte((flags & GRAD_SPREAD_MASK) >> GRAD_SPREAD_SHIFT)
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "gradient: spread method is not pad, reflect or repeat"))?;
    let transform = if flags & GRAD_FLAG_TRANSFORM != 0 { Some(read_transform(data, cursor)?) } else { None };
    let fr = if flags & GRAD_FLAG_FR != 0 {
        if !radial {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "gradient: a linear gradient has no focal radius"));
        }
        read_f32(data, cursor)?
    } else {
        0.0
    };
    Ok((units, spread, transform, fr))
}

fn decode_def(data: &[u8], cursor: &mut usize, pool: &[String]) -> io::Result<Def> {
    let tag = read_u8(data, cursor)?;
    match tag {
        TAG_LINEAR_GRADIENT | TAG_LINEAR_GRADIENT_V3 => {
            let id_idx = read_u16(data, cursor)?;
            let id     = pool.get(id_idx as usize).cloned().unwrap_or_default();
            let x1 = read_f32(data, cursor)?;
            let y1 = read_f32(data, cursor)?;
            let x2 = read_f32(data, cursor)?;
            let y2 = read_f32(data, cursor)?;
            let stops = read_stops(data, cursor)?;
            let mut g = LinearGradient::new(id, x1, y1, x2, y2, stops);
            if tag == TAG_LINEAR_GRADIENT_V3 {
                let (units, spread, transform, _) = read_gradient_space(data, cursor, false)?;
                g.units = units;
                g.spread = spread;
                g.transform = transform;
            }
            Ok(Def::LinearGradient(g))
        }
        TAG_RADIAL_GRADIENT | TAG_RADIAL_GRADIENT_V3 => {
            let id_idx = read_u16(data, cursor)?;
            let id     = pool.get(id_idx as usize).cloned().unwrap_or_default();
            let cx = read_f32(data, cursor)?;
            let cy = read_f32(data, cursor)?;
            let r  = read_f32(data, cursor)?;
            let fx = read_f32(data, cursor)?;
            let fy = read_f32(data, cursor)?;
            let stops = read_stops(data, cursor)?;
            let mut g = RadialGradient::new(id, cx, cy, r, fx, fy, stops);
            if tag == TAG_RADIAL_GRADIENT_V3 {
                let (units, spread, transform, fr) = read_gradient_space(data, cursor, true)?;
                g.units = units;
                g.spread = spread;
                g.transform = transform;
                g = g.with_fr(fr);
            }
            Ok(Def::RadialGradient(g))
        }
        TAG_CONIC_GRADIENT => {
            let id_idx = read_u16(data, cursor)?;
            let id     = pool.get(id_idx as usize).cloned().unwrap_or_default();
            let cx    = read_f32(data, cursor)?;
            let cy    = read_f32(data, cursor)?;
            let angle = read_f32(data, cursor)?;
            let stops = read_stops(data, cursor)?;
            Ok(Def::ConicGradient(ConicGradient::new(id, cx, cy, angle, stops)))
        }
        TAG_SHADER => {
            let id_idx          = read_u16(data, cursor)?;
            let source_ref_idx  = read_u16(data, cursor)?;
            let entry_point_idx = read_u16(data, cursor)?;
            let id          = pool.get(id_idx as usize).cloned().unwrap_or_default();
            let source_ref  = pool.get(source_ref_idx as usize).cloned().unwrap_or_default();
            let entry_point = pool.get(entry_point_idx as usize).cloned().unwrap_or_default();
            let fallback_color = read_color(data, cursor)?;

            let uniform_count = read_u16(data, cursor)? as usize;
            let mut uniforms = Vec::with_capacity(uniform_count);
            for _ in 0..uniform_count {
                let name_idx = read_u16(data, cursor)?;
                let name = pool.get(name_idx as usize).cloned().unwrap_or_default();
                let kind = read_u8(data, cursor)?;
                let value = match kind {
                    0 => ShaderUniformValue::Float(read_f32(data, cursor)? as f32),
                    1 => ShaderUniformValue::Vec2(
                        read_f32(data, cursor)? as f32,
                        read_f32(data, cursor)? as f32,
                    ),
                    2 => ShaderUniformValue::Vec3(
                        read_f32(data, cursor)? as f32,
                        read_f32(data, cursor)? as f32,
                        read_f32(data, cursor)? as f32,
                    ),
                    3 => ShaderUniformValue::Vec4(
                        read_f32(data, cursor)? as f32,
                        read_f32(data, cursor)? as f32,
                        read_f32(data, cursor)? as f32,
                        read_f32(data, cursor)? as f32,
                    ),
                    other => return Err(io::Error::new(
                        io::ErrorKind::InvalidData,
                        format!("unknown shader uniform kind 0x{:02x}", other),
                    )),
                };
                uniforms.push(ShaderUniform { name, value });
            }

            let mut shader = ShaderDef::new(id, source_ref, fallback_color).with_entry_point(entry_point);
            shader.uniforms = uniforms;
            Ok(Def::Shader(shader))
        }
        TAG_AUDIO => {
            let id_idx = read_u16(data, cursor)?;
            let id     = pool.get(id_idx as usize).cloned().unwrap_or_default();
            let source = decode_media_source(data, cursor, pool)?;
            Ok(Def::Audio(msx_ast::AudioDef::new(id, source)))
        }
        other => Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("unknown def tag 0x{:02x}", other),
        )),
    }
}

fn read_stops(data: &[u8], cursor: &mut usize) -> io::Result<Vec<Stop>> {
    let count = read_u16(data, cursor)? as usize;
    let mut stops = Vec::with_capacity(count);
    for _ in 0..count {
        if *cursor + 8 > data.len() {
            return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "gradient stop truncated"));
        }
        let bytes: [u8; 8] = data[*cursor..*cursor + 8].try_into().unwrap();
        *cursor += 8;
        stops.push(Stop::from_bytes(&bytes));
    }
    Ok(stops)
}

// ── Element decoding ─────────────────────────────────────────────────────────

fn decode_element(data: &[u8], cursor: &mut usize, pool: &[String]) -> io::Result<Element> {
    let tag = read_u8(data, cursor)?;

    // Splat has no transform field; it gets its own simpler id header,
    // written before the shared id_flags read used by every other element.
    if tag == TAG_SPLAT {
        return decode_splat(data, cursor, pool);
    }

    let (id, transform) = read_id_flags(data, cursor, pool)?;

    match tag {
        TAG_RECT => {
            let x      = read_f32(data, cursor)?;
            let y      = read_f32(data, cursor)?;
            let width  = read_f32(data, cursor)?;
            let height = read_f32(data, cursor)?;
            let rx_v   = read_f32(data, cursor)?;
            let ry_v   = read_f32(data, cursor)?;
            let style  = read_style(data, cursor, pool)?;
            Ok(Element::Rect(Rect {
                x, y, width, height,
                rx: if rx_v == 0.0 { None } else { Some(rx_v) },
                ry: if ry_v == 0.0 { None } else { Some(ry_v) },
                id, transform, style,
            }))
        }
        TAG_CIRCLE => {
            let cx    = read_f32(data, cursor)?;
            let cy    = read_f32(data, cursor)?;
            let r     = read_f32(data, cursor)?;
            let style = read_style(data, cursor, pool)?;
            Ok(Element::Circle(Circle { cx, cy, r, id, transform, style }))
        }
        TAG_ELLIPSE => {
            let cx    = read_f32(data, cursor)?;
            let cy    = read_f32(data, cursor)?;
            let rx    = read_f32(data, cursor)?;
            let ry    = read_f32(data, cursor)?;
            let style = read_style(data, cursor, pool)?;
            Ok(Element::Ellipse(Ellipse { cx, cy, rx, ry, id, transform, style }))
        }
        TAG_LINE => {
            let x1    = read_f32(data, cursor)?;
            let y1    = read_f32(data, cursor)?;
            let x2    = read_f32(data, cursor)?;
            let y2    = read_f32(data, cursor)?;
            let style = read_style(data, cursor, pool)?;
            Ok(Element::Line(Line { x1, y1, x2, y2, id, transform, style }))
        }
        TAG_POLYLINE | TAG_POLYGON => {
            let count = read_u32(data, cursor)? as usize;
            let mut pts = Vec::with_capacity(count);
            for _ in 0..count {
                let (x, y) = read_point(data, cursor)?;
                pts.push(Point::new(x, y));
            }
            let style  = read_style(data, cursor, pool)?;
            let closed = tag == TAG_POLYGON;
            Ok(Element::Polyline(Polyline { points: pts, closed, id, transform, style }))
        }
        TAG_PATH => {
            let cmd_len = read_u32(data, cursor)? as usize;
            if *cursor + cmd_len > data.len() {
                return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "path commands truncated"));
            }
            let cmd_bytes = &data[*cursor..*cursor + cmd_len];
            *cursor += cmd_len;
            let commands = decode_commands(cmd_bytes)?;
            // Verbatim `d_raw`, not a `commands_to_d` regeneration — see
            // encode_path's own comment for why reconstructing it instead
            // of storing it silently broke the "roundtrip fidelity" this
            // field's doc comment always promised.
            let d_len = read_u32(data, cursor)? as usize;
            if *cursor + d_len > data.len() {
                return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "path d_raw truncated"));
            }
            let d_raw = std::str::from_utf8(&data[*cursor..*cursor + d_len])
                .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, format!("path d_raw invalid utf8: {e}")))?
                .to_string();
            *cursor += d_len;
            let style    = read_style(data, cursor, pool)?;
            Ok(Element::Path(Path { commands, d_raw, id, transform, style }))
        }
        TAG_TEXT => {
            let str_idx = read_u16(data, cursor)?;
            let content = pool.get(str_idx as usize).cloned().unwrap_or_default();
            let x       = read_f32(data, cursor)?;
            let y       = read_f32(data, cursor)?;
            let style   = read_style(data, cursor, pool)?;
            Ok(Element::Text(Text { x, y, content, id, transform, style, path: None }))
        }
        TAG_TEXT_PATH => {
            let str_idx = read_u16(data, cursor)?;
            let content = pool.get(str_idx as usize).cloned().unwrap_or_default();
            let x       = read_f32(data, cursor)?;
            let y       = read_f32(data, cursor)?;
            let cmd_len = read_u32(data, cursor)? as usize;
            if *cursor + cmd_len > data.len() {
                return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "text path commands truncated"));
            }
            let commands = decode_commands(&data[*cursor..*cursor + cmd_len])?;
            *cursor += cmd_len;
            let start_offset = read_f32(data, cursor)?;
            let style = read_style(data, cursor, pool)?;
            Ok(Element::Text(Text { x, y, content, id, transform, style, path: Some(TextPath { commands, start_offset }) }))
        }
        TAG_GROUP => {
            let child_count = read_u32(data, cursor)? as usize;
            let mut children = Vec::with_capacity(child_count);
            for _ in 0..child_count {
                children.push(decode_element(data, cursor, pool)?);
            }
            let style = read_style(data, cursor, pool)?;
            let group_style = if style == msx_ast::Style::empty() { None } else { Some(style) };
            Ok(Element::Group(Group { children, id, transform, style: group_style }))
        }
        TAG_USE => {
            let href_idx = read_u16(data, cursor)?;
            let href     = pool.get(href_idx as usize).cloned().unwrap_or_default();
            let x        = read_f32(data, cursor)?;
            let y        = read_f32(data, cursor)?;
            Ok(Element::Use(Use { href, x, y, id, transform }))
        }
        TAG_SDF => {
            let tree = read_sdf_tree(data, cursor)?;
            let fill = read_paint(data, cursor, pool)?;
            let has_stroke = read_u8(data, cursor)? != 0;
            let (stroke, stroke_width) = if has_stroke {
                let s = read_paint(data, cursor, pool)?;
                let w = read_f32(data, cursor)?;
                (Some(s), Some(w))
            } else {
                (None, None)
            };
            Ok(Element::Sdf(SdfNode { tree, fill, stroke, stroke_width, id, transform }))
        }
        TAG_LAYER => {
            let blend_mode = msx_ast::BlendMode::from_byte(read_u8(data, cursor)?);
            let opacity    = read_f32(data, cursor)?;
            let flags      = read_u8(data, cursor)?;
            let clip       = flags & 1 != 0;
            let has_clip_path = flags & 2 != 0;
            let has_mask = flags & 4 != 0;
            let mask_type = if flags & 8 != 0 { msx_ast::MaskType::Alpha } else { msx_ast::MaskType::Luminance };
            let effect_count = read_u16(data, cursor)? as usize;
            let mut effects = Vec::with_capacity(effect_count);
            for _ in 0..effect_count {
                effects.push(read_effect(data, cursor)?);
            }
            let child_count = read_u32(data, cursor)? as usize;
            let mut children = Vec::with_capacity(child_count);
            for _ in 0..child_count {
                children.push(decode_element(data, cursor, pool)?);
            }
            // z_index: see encode_layer's own comment — added after
            // every pre-existing field, same convention as `fill`.
            let z_index = read_f32(data, cursor)?;
            let clip_path = if has_clip_path {
                let count = read_u32(data, cursor)? as usize;
                let mut shapes = Vec::with_capacity(count.min(1024));
                for _ in 0..count {
                    shapes.push(decode_element(data, cursor, pool)?);
                }
                Some(shapes)
            } else {
                None
            };
            let mask = if has_mask {
                let count = read_u32(data, cursor)? as usize;
                let mut elements = Vec::with_capacity(count.min(1024));
                for _ in 0..count {
                    elements.push(decode_element(data, cursor, pool)?);
                }
                Some(elements)
            } else {
                None
            };
            Ok(Element::Layer(Layer { children, blend_mode, opacity, clip, clip_path, mask, mask_type, effects, id, transform, z_index }))
        }
        TAG_IMAGE => {
            let source = decode_media_source(data, cursor, pool)?;
            let x      = read_f32(data, cursor)?;
            let y      = read_f32(data, cursor)?;
            let width  = read_f32(data, cursor)?;
            let height = read_f32(data, cursor)?;
            let anchor = msx_ast::Anchor::from_byte(read_u8(data, cursor)?);
            let style  = read_style(data, cursor, pool)?;
            Ok(Element::Image(Image { source, x, y, width, height, anchor, id, transform, style }))
        }
        other => Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("unknown element tag 0x{:02x}", other),
        )),
    }
}

// ── MediaSource decoding ────────────────────────────────────────────────────

fn decode_media_source(data: &[u8], cursor: &mut usize, pool: &[String]) -> io::Result<MediaSource> {
    let kind = read_u8(data, cursor)?;
    match kind {
        0 => {
            // u32 length prefix, mirroring TAG_PATH's own d_raw read
            // above — see encode_media_source's comment for why this
            // deliberately isn't the string pool.
            let len = read_u32(data, cursor)? as usize;
            if *cursor + len > data.len() {
                return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "embedded media blob truncated"));
            }
            let bytes = data[*cursor..*cursor + len].to_vec();
            *cursor += len;
            Ok(MediaSource::Embedded(bytes))
        }
        1 => {
            let idx = read_u16(data, cursor)?;
            let path = pool.get(idx as usize).cloned().unwrap_or_default();
            Ok(MediaSource::FileRef(path))
        }
        other => Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("unknown MediaSource kind 0x{:02x}", other),
        )),
    }
}

fn decode_splat(data: &[u8], cursor: &mut usize, pool: &[String]) -> io::Result<Element> {
    let has_id = read_u8(data, cursor)? != 0;
    let id = if has_id {
        let idx = read_u16(data, cursor)?;
        Some(lookup_string(pool, idx)?.to_string())
    } else {
        None
    };
    let x        = read_f32(data, cursor)?;
    let y        = read_f32(data, cursor)?;
    let sigma_x  = read_f32(data, cursor)?;
    let sigma_y  = read_f32(data, cursor)?;
    let rotation = read_f32(data, cursor)?;
    let color    = read_color(data, cursor)?;
    let opacity  = read_f32(data, cursor)?;
    let has_fill = read_u8(data, cursor)? != 0;
    let fill = if has_fill {
        Some(read_paint(data, cursor, pool)?)
    } else {
        None
    };
    Ok(Element::Splat(GaussianSplat { x, y, sigma_x, sigma_y, rotation, color, fill, opacity, id }))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_gradient_flags_byte_is_read_field_by_field() {
        let (units, spread, transform, fr) = read_gradient_space(&[0b0000_0011], &mut 0, false).unwrap();
        assert_eq!((units, spread, fr), (GradientUnits::UserSpace, SpreadMethod::Reflect, 0.0));
        assert!(transform.is_none());
        let (units, spread, ..) = read_gradient_space(&[0b0000_0101], &mut 0, false).unwrap();
        assert_eq!((units, spread), (GradientUnits::UserSpace, SpreadMethod::Repeat));
        let (units, spread, ..) = read_gradient_space(&[0b0000_0100], &mut 0, true).unwrap();
        assert_eq!((units, spread), (GradientUnits::ObjectBoundingBox, SpreadMethod::Repeat));
    }

    #[test]
    fn a_focal_radius_follows_the_flags_of_a_radial_gradient() {
        let mut bytes = vec![GRAD_FLAG_FR];
        bytes.extend_from_slice(&0.25f32.to_le_bytes());
        let mut cursor = 0;
        let (.., fr) = read_gradient_space(&bytes, &mut cursor, true).unwrap();
        assert_eq!(fr, 0.25);
        assert_eq!(cursor, bytes.len());
    }

    #[test]
    fn a_linear_gradient_cannot_have_a_focal_radius() {
        let mut bytes = vec![GRAD_FLAG_FR];
        bytes.extend_from_slice(&0.25f32.to_le_bytes());
        assert!(read_gradient_space(&bytes, &mut 0, false).is_err());
    }

    #[test]
    fn a_cut_off_focal_radius_is_an_error() {
        assert!(read_gradient_space(&[GRAD_FLAG_FR, 0, 0], &mut 0, true).is_err());
    }

    #[test]
    fn a_spread_that_does_not_exist_is_an_error() {
        assert!(read_gradient_space(&[0b0000_0110], &mut 0, false).is_err());
    }

    #[test]
    fn a_missing_or_cut_off_flags_byte_or_transform_is_an_error() {
        assert!(read_gradient_space(&[], &mut 0, false).is_err());
        // The transform bit is set but nothing follows it.
        assert!(read_gradient_space(&[0b0000_1000], &mut 0, false).is_err());
    }
}
