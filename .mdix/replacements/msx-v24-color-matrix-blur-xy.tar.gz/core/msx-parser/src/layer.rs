// core/msx-parser/src/layer.rs
use dixscript::Runtime::{DixData, dix_path};
use msx_ast::{BlendMode, Color, Effect, Layer};

use crate::dix_helpers::{array_len, color_from, enum_discriminant, opt, raw, type_tag};
use crate::element::parse_elements;
use crate::transform::parse_transform;

/// `{ type = "layer", blend_mode<enum> = BlendMode.Multiply (or "multiply"),
///    opacity=0.75, z_index=1.0, clip=true, clip_path=[...shapes], mask=[...elements],
///    mask_type="alpha", effects=[...], elements=[...] }`
///
/// `clip_path` and `mask` are optional. Absent means none, present and empty
/// hides the whole layer. `mask_type` is `luminance` (default) or `alpha`.
pub fn parse_layer(data: &DixData, prefix: &str) -> Result<Layer, String> {
    let id = opt::<String>(data, prefix, "id")?;
    let transform = parse_transform(data, prefix)?;
    let children = parse_elements(data, prefix, "elements")?;

    let mut layer = Layer::new(children);
    layer.id = id;
    layer.transform = transform;
    layer.blend_mode = parse_blend_mode(data, prefix)?.unwrap_or_default();
    layer.opacity = opt::<f64>(data, prefix, "opacity")?.unwrap_or(1.0);
    layer.z_index = opt::<f64>(data, prefix, "z_index")?.unwrap_or(0.0);
    layer.clip = opt::<bool>(data, prefix, "clip")?.unwrap_or(false);
    if raw(data, prefix, "clip_path").is_some() {
        layer.clip_path = Some(parse_elements(data, prefix, "clip_path")?);
    }
    if raw(data, prefix, "mask").is_some() {
        layer.mask = Some(parse_elements(data, prefix, "mask")?);
    }
    if let Some(name) = opt::<String>(data, prefix, "mask_type")? {
        layer.mask_type = msx_ast::MaskType::from_name(&name);
    }
    layer.effects = parse_effects(data, prefix, "effects")?;

    Ok(layer)
}

fn parse_blend_mode(data: &DixData, prefix: &str) -> Result<Option<BlendMode>, String> {
    if let Some(v) = enum_discriminant(raw(data, prefix, "blend_mode")) {
        return Ok(Some(BlendMode::from_byte(v as u8)));
    }
    Ok(opt::<String>(data, prefix, "blend_mode")?.map(|s| blend_mode_from_str(&s)))
}

fn blend_mode_from_str(s: &str) -> BlendMode {
    match s {
        "multiply"   => BlendMode::Multiply,
        "screen"     => BlendMode::Screen,
        "overlay"    => BlendMode::Overlay,
        "add"        => BlendMode::Add,
        "soft_light" => BlendMode::SoftLight,
        "hard_light" => BlendMode::HardLight,
        "difference" => BlendMode::Difference,
        "exclusion"  => BlendMode::Exclusion,
        "darken"     => BlendMode::Darken,
        "lighten"    => BlendMode::Lighten,
        "subtract"   => BlendMode::Subtract,
        "divide"     => BlendMode::Divide,
        "color_dodge" => BlendMode::ColorDodge,
        "color_burn" => BlendMode::ColorBurn,
        "hue"        => BlendMode::Hue,
        "saturation" => BlendMode::Saturation,
        "color"      => BlendMode::Color,
        "luminosity" => BlendMode::Luminosity,
        "plus_lighter" => BlendMode::PlusLighter,
        _            => BlendMode::Normal,
    }
}

fn parse_effects(data: &DixData, parent_prefix: &str, field: &str) -> Result<Vec<Effect>, String> {
    let path = dix_path(parent_prefix, field);
    let count = array_len(data, parent_prefix, field)?;
    let mut out = Vec::with_capacity(count);
    for i in 0..count {
        out.push(parse_effect(data, &format!("{}[{}]", path, i))?);
    }
    Ok(out)
}

fn parse_effect(data: &DixData, prefix: &str) -> Result<Effect, String> {
    let kind = type_tag(data, prefix)?;
    match kind.as_str() {
        "blur" => Ok(Effect::Blur {
            radius: opt::<f64>(data, prefix, "radius")?.unwrap_or(4.0),
        }),
        "drop_shadow" => Ok(Effect::DropShadow {
            offset_x: opt::<f64>(data, prefix, "offset_x")?.unwrap_or(0.0),
            offset_y: opt::<f64>(data, prefix, "offset_y")?.unwrap_or(0.0),
            blur_radius: opt::<f64>(data, prefix, "blur_radius")?.unwrap_or(4.0),
            color: color_from(raw(data, prefix, "color")).unwrap_or(Color::BLACK),
            opacity: opt::<f64>(data, prefix, "opacity")?.unwrap_or(0.5),
        }),
        "inner_shadow" => Ok(Effect::InnerShadow {
            offset_x: opt::<f64>(data, prefix, "offset_x")?.unwrap_or(0.0),
            offset_y: opt::<f64>(data, prefix, "offset_y")?.unwrap_or(0.0),
            blur_radius: opt::<f64>(data, prefix, "blur_radius")?.unwrap_or(4.0),
            color: color_from(raw(data, prefix, "color")).unwrap_or(Color::BLACK),
            opacity: opt::<f64>(data, prefix, "opacity")?.unwrap_or(0.5),
        }),
        "outer_glow" => Ok(Effect::OuterGlow {
            color: color_from(raw(data, prefix, "color")).unwrap_or(Color::WHITE),
            blur_radius: opt::<f64>(data, prefix, "blur_radius")?.unwrap_or(8.0),
            spread: opt::<f64>(data, prefix, "spread")?.unwrap_or(0.0),
            opacity: opt::<f64>(data, prefix, "opacity")?.unwrap_or(0.75),
        }),
        "inner_glow" => Ok(Effect::InnerGlow {
            color: color_from(raw(data, prefix, "color")).unwrap_or(Color::WHITE),
            blur_radius: opt::<f64>(data, prefix, "blur_radius")?.unwrap_or(8.0),
            opacity: opt::<f64>(data, prefix, "opacity")?.unwrap_or(0.75),
        }),
        "blur_xy" => Ok(Effect::BlurXY {
            rx: opt::<f64>(data, prefix, "rx")?.unwrap_or(4.0),
            ry: opt::<f64>(data, prefix, "ry")?.unwrap_or(4.0),
        }),
        "color_matrix" => {
            let list = opt::<Vec<f64>>(data, prefix, "values")?.ok_or_else(|| format!("{prefix}: a color_matrix needs `values`, 20 numbers"))?;
            let count = list.len();
            let values: [f64; 20] = list.try_into().map_err(|_| format!("{prefix}: a color_matrix needs 20 values, found {count}"))?;
            Ok(Effect::ColorMatrix { values, linear: opt::<bool>(data, prefix, "linear")?.unwrap_or(false) })
        }
        other => Err(format!("{}: unknown effect type '{}'", prefix, other)),
    }
                 }
