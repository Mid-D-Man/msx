// render/msx-render-svg/src/layer.rs
use msx_ast::{fmt_f64, Def, Effect, Layer};

use crate::{render_element, write_attr, write_id, write_transform, Ctx};

/// `blend_mode` → CSS `mix-blend-mode` (`Subtract`/`Divide` have no CSS
/// equivalent and fall back to Normal here; `msx-render-cpu`/`-gpu`
/// implement the signed-buffer math those actually need). `effects` → a
/// generated `<filter>` chaining one SVG filter primitive per effect.
/// `mask` → a generated `<mask>` of the same elements, same way. `clip_path` →
/// a generated `<clipPath>` of the same shapes, referenced
/// from the layer's `<g>`. `clip` (the pixel footprint flag) has no cheap
/// SVG 1.1 fallback without a bbox computation, so it's left unenforced
/// here.
pub(crate) fn render_layer(ctx: &mut Ctx, layer: &Layer, defs: &[Def]) {
    ctx.push("<g");

    write_id(ctx, layer.id.as_deref());
    write_transform(ctx, layer.transform.as_ref());

    if (layer.opacity - 1.0).abs() > 1e-6 {
        write_attr(ctx, "opacity", fmt_f64(layer.opacity));
    }

    if let Some(css) = layer.blend_mode.to_css_blend_mode() {
        write_attr(ctx, "style", format!("mix-blend-mode:{}", css));
    }

    if !layer.effects.is_empty() {
        let filter_id = render_effects_filter(ctx, &layer.effects);
        write_attr(ctx, "filter", format!("url(#{})", filter_id));
    }

    if let Some(shapes) = &layer.clip_path {
        let clip_id = render_clip_path(ctx, shapes, defs);
        write_attr(ctx, "clip-path", format!("url(#{})", clip_id));
    }

    if let Some(elements) = &layer.mask {
        let mask_id = render_mask(ctx, elements, layer.mask_type, defs);
        write_attr(ctx, "mask", format!("url(#{})", mask_id));
    }

    ctx.push(">");
    for child in msx_ast::layer_reordered(&layer.children) {
        render_element(ctx, child, defs);
    }
    ctx.push("</g>");
}

/// Renders `shapes` into a `<clipPath>` in the synthesized defs and returns
/// its id. The shapes are drawn by the normal element renderer into a side
/// buffer, then `fill-rule` is renamed to `clip-rule`, the property SVG reads
/// inside a clip path. Fill, stroke and opacity attributes are ignored there.
/// An empty list gives an empty `<clipPath>`, which clips everything away.
fn render_clip_path(ctx: &mut Ctx, shapes: &[msx_ast::Element], defs: &[Def]) -> String {
    let id = ctx.fresh_id("layer-clip-");
    let outer = std::mem::take(&mut ctx.out);
    for shape in shapes {
        render_element(ctx, shape, defs);
    }
    let body = std::mem::replace(&mut ctx.out, outer).replace(" fill-rule=\"", " clip-rule=\"");
    ctx.extra_defs.push_str(&format!("<clipPath id=\"{id}\">{body}</clipPath>"));
    id
}

/// Renders `elements` into a `<mask>` in the synthesized defs and returns its
/// id. The region is far larger than any canvas, so the layer is never cut by
/// the default 120 percent box of a mask, since a mask that needs a region
/// carries it as a clip of its own content. `alpha` masks write
/// `mask-type: alpha`, and an empty list gives an empty `<mask>`, which hides
/// the whole layer.
fn render_mask(ctx: &mut Ctx, elements: &[msx_ast::Element], kind: msx_ast::MaskType, defs: &[Def]) -> String {
    let id = ctx.fresh_id("layer-mask-");
    let outer = std::mem::take(&mut ctx.out);
    for el in elements {
        render_element(ctx, el, defs);
    }
    let body = std::mem::replace(&mut ctx.out, outer);
    let kind_attr = if kind == msx_ast::MaskType::Alpha { " style=\"mask-type:alpha\"" } else { "" };
    ctx.extra_defs.push_str(&format!(
        "<mask id=\"{id}\" maskUnits=\"userSpaceOnUse\" x=\"-1000000\" y=\"-1000000\" width=\"2000000\" height=\"2000000\"{kind_attr}>{body}</mask>"
    ));
    id
}

fn render_effects_filter(ctx: &mut Ctx, effects: &[Effect]) -> String {
    let filter_id = ctx.fresh_id("layer-fx-");
    let mut body = String::new();
    let mut input = "SourceGraphic".to_string();

    for (i, effect) in effects.iter().enumerate() {
        let result = format!("fx{}-out", i);
        body.push_str(&effect_primitive(effect, &input, &result, i));
        input = result;
    }

    ctx.extra_defs.push_str(&format!(
        r#"<filter id="{id}" x="-50%" y="-50%" width="200%" height="200%">{body}</filter>"#,
        id = filter_id,
        body = body,
    ));
    filter_id
}

/// `idx` scopes each effect's intermediate `result=` names (`fx{idx}-...`)
/// so chained effects on the same layer never collide.
fn effect_primitive(effect: &Effect, input: &str, result: &str, idx: usize) -> String {
    let p = format!("fx{}-", idx);
    match effect {
        Effect::Blur { radius } => format!(
            r#"<feGaussianBlur in="{input}" stdDeviation="{r}" result="{result}"/>"#,
            input = input,
            r = fmt_f64(radius.max(0.0)),
            result = result,
        ),

        // Two numbers give a deviation per axis. A zero on one axis blurs only
        // the other.
        Effect::BlurXY { rx, ry } => format!(
            r#"<feGaussianBlur in="{input}" stdDeviation="{rx} {ry}" result="{result}"/>"#,
            input = input,
            rx = fmt_f64(rx.max(0.0)),
            ry = fmt_f64(ry.max(0.0)),
            result = result,
        ),

        // The color space is written on the primitive, because the filter
        // default (linearRGB) would otherwise apply to every matrix.
        Effect::ColorMatrix { values, linear } => format!(
            r#"<feColorMatrix in="{input}" type="matrix" values="{values}" color-interpolation-filters="{space}" result="{result}"/>"#,
            input = input,
            values = values.iter().map(|v| fmt_matrix_value(*v)).collect::<Vec<_>>().join(" "),
            space = if *linear { "linearRGB" } else { "sRGB" },
            result = result,
        ),

        Effect::DropShadow { offset_x, offset_y, blur_radius, color, opacity } => format!(
            r#"<feDropShadow in="{input}" dx="{dx}" dy="{dy}" stdDeviation="{blur}" flood-color="{color}" flood-opacity="{op}" result="{result}"/>"#,
            input = input,
            dx = fmt_f64(*offset_x),
            dy = fmt_f64(*offset_y),
            blur = fmt_f64(blur_radius.max(0.0)),
            color = color.to_svg_hex(),
            op = fmt_f64(opacity.clamp(0.0, 1.0)),
            result = result,
        ),

        // Classic blur-the-alpha / flood / composite-in / merge-on-top glow
        // recipe, with `feMorphology dilate` standing in for `spread`.
        Effect::OuterGlow { color, blur_radius, spread, opacity } => format!(
            r#"<feMorphology in="{input}" operator="dilate" radius="{spread}" result="{p}dilate"/><feGaussianBlur in="{p}dilate" stdDeviation="{blur}" result="{p}blur"/><feFlood flood-color="{color}" flood-opacity="{op}" result="{p}color"/><feComposite in="{p}color" in2="{p}blur" operator="in" result="{p}glow"/><feMerge result="{result}"><feMergeNode in="{p}glow"/><feMergeNode in="{input}"/></feMerge>"#,
            input = input,
            p = p,
            spread = fmt_f64(spread.max(0.0)),
            blur = fmt_f64(blur_radius.max(0.0)),
            color = color.to_svg_hex(),
            op = fmt_f64(opacity.clamp(0.0, 1.0)),
            result = result,
        ),

        // Invert alpha (feFuncA "1 0"), blur, flood, composite-in, clip back
        // to the original silhouette, merge under the source.
        Effect::InnerGlow { color, blur_radius, opacity } => format!(
            r#"<feComponentTransfer in="{input}" result="{p}inv"><feFuncA type="table" tableValues="1 0"/></feComponentTransfer><feGaussianBlur in="{p}inv" stdDeviation="{blur}" result="{p}blur"/><feFlood flood-color="{color}" flood-opacity="{op}" result="{p}color"/><feComposite in="{p}color" in2="{p}blur" operator="in" result="{p}tint"/><feComposite in="{p}tint" in2="{input}" operator="in" result="{p}clip"/><feMerge result="{result}"><feMergeNode in="{input}"/><feMergeNode in="{p}clip"/></feMerge>"#,
            input = input,
            p = p,
            blur = fmt_f64(blur_radius.max(0.0)),
            color = color.to_svg_hex(),
            op = fmt_f64(opacity.clamp(0.0, 1.0)),
            result = result,
        ),

        // Same as InnerGlow but the inverted-alpha mask is offset before
        // blurring, giving the shadow a direction instead of an even halo.
        Effect::InnerShadow { offset_x, offset_y, blur_radius, color, opacity } => format!(
            r#"<feComponentTransfer in="{input}" result="{p}inv"><feFuncA type="table" tableValues="1 0"/></feComponentTransfer><feOffset in="{p}inv" dx="{dx}" dy="{dy}" result="{p}off"/><feGaussianBlur in="{p}off" stdDeviation="{blur}" result="{p}blur"/><feFlood flood-color="{color}" flood-opacity="{op}" result="{p}color"/><feComposite in="{p}color" in2="{p}blur" operator="in" result="{p}tint"/><feComposite in="{p}tint" in2="{input}" operator="in" result="{p}clip"/><feMerge result="{result}"><feMergeNode in="{input}"/><feMergeNode in="{p}clip"/></feMerge>"#,
            input = input,
            p = p,
            dx = fmt_f64(*offset_x),
            dy = fmt_f64(*offset_y),
            blur = fmt_f64(blur_radius.max(0.0)),
            color = color.to_svg_hex(),
            op = fmt_f64(opacity.clamp(0.0, 1.0)),
            result = result,
        ),
    }
        }

/// A color matrix entry with six decimals, because `fmt_f64` keeps four and a
/// luminance weight such as 0.2126 needs more than that to match the
/// other renderers.
fn fmt_matrix_value(v: f64) -> String {
    let s = format!("{v:.6}");
    let s = s.trim_end_matches('0').trim_end_matches('.');
    if s.is_empty() || s == "-0" { "0".to_string() } else { s.to_string() }
}
