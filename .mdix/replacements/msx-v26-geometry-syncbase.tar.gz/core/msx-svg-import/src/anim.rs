// core/msx-svg-import/src/anim.rs
//! SMIL timing and keyframe baking for the SVG importer.
//!
//! NOTICE: see docs/guide/svg-import.md, section "Animation", for the model and the
//! limits. This file holds only pure functions on numbers, so it has no
//! dependency on the scene types.
//!
//! An MSX scene has one timeline (`duration` plus `loop_mode`) and tracks of
//! linear keyframes with four easings. SMIL has a timeline per animation, with
//! `begin`, `dur`, repeats, `fill`, `keyTimes`, `calcMode` and `keySplines`.
//! The two meet by baking: every animation is turned into dense points on the
//! scene timeline, and a track is one linear keyframe per point.

/// A jump between two values is written as a ramp this long, in seconds.
pub(crate) const EPS: f64 = 0.001;
/// Most keyframes one animation may need on the scene timeline.
pub(crate) const MAX_POINTS: usize = 20_000;
/// Longest scene loop the planner builds from the periods of repeating animations.
pub(crate) const MAX_LOOP_SECS: f64 = 60.0;
/// Pieces one `keySplines` segment is cut into.
const SPLINE_STEPS: usize = 12;

fn number(s: &str) -> Option<f64> {
    let v: f64 = s.trim().parse().ok()?;
    v.is_finite().then_some(v)
}

/// A SMIL clock value in seconds: `3s`, `500ms`, `1.5min`, `2h`, `1:30`,
/// `00:01:30.5` or a bare number of seconds.
pub(crate) fn parse_clock(s: &str) -> Option<f64> {
    let s = s.trim();
    if s.is_empty() {
        return None;
    }
    if s.contains(':') {
        let parts: Vec<&str> = s.split(':').collect();
        if parts.len() > 3 {
            return None;
        }
        let mut total = 0.0;
        for (i, p) in parts.iter().enumerate() {
            let v = if i + 1 == parts.len() { number(p)? } else { f64::from(p.trim().parse::<u32>().ok()?) };
            if v < 0.0 {
                return None;
            }
            total = total * 60.0 + v;
        }
        return Some(total);
    }
    let (digits, scale) = if let Some(r) = s.strip_suffix("ms") {
        (r, 0.001)
    } else if let Some(r) = s.strip_suffix("min") {
        (r, 60.0)
    } else if let Some(r) = s.strip_suffix('h') {
        (r, 3600.0)
    } else if let Some(r) = s.strip_suffix('s') {
        (r, 1.0)
    } else {
        (s, 1.0)
    };
    number(digits).map(|v| v * scale)
}

/// The start of an animation in seconds. A list takes its earliest offset.
/// A start that waits for an event, another animation or never comes is an
/// error, because the scene has no input to wait for.
pub(crate) fn parse_begin(attr: Option<&str>) -> Result<f64, String> {
    let Some(raw) = attr else { return Ok(0.0) };
    let mut best: Option<f64> = None;
    let mut other = false;
    for item in raw.split(';').map(str::trim).filter(|i| !i.is_empty()) {
        match parse_clock(item) {
            Some(v) => best = Some(best.map_or(v, |b| b.min(v))),
            None => other = true,
        }
    }
    match best {
        Some(v) => Ok(v),
        None if other => Err(format!("begin=\"{}\" waits for an event or another animation", raw.trim())),
        None => Ok(0.0),
    }
}

/// When an animation runs, from its timing attributes.
#[derive(Debug, Clone, Copy, PartialEq)]
pub(crate) struct Timing {
    /// Start in seconds. May be negative: the animation is already running at 0.
    pub begin: f64,
    /// Length of one iteration in seconds, above zero.
    pub dur: f64,
    /// Total active time in seconds, or `None` when it repeats forever.
    pub active: Option<f64>,
    /// `fill="freeze"`: hold the last value after the end instead of going back.
    pub freeze: bool,
    /// CSS `animation-fill-mode: backwards`: hold the first value during the
    /// delay instead of the value without the animation.
    pub fill_before: bool,
    /// Idle seconds after each iteration before the next one starts. It is 0
    /// except for an animation that starts again on a schedule, such as a
    /// `begin` that follows the end of another animation. In the gap the value
    /// is the last one for a `fill="freeze"` and the value without the
    /// animation otherwise.
    pub gap: f64,
}

/// Cuts the active time at `end`. An `end` that waits for an event is ignored.
fn clamp_to_end<'a>(get: &impl Fn(&str) -> Option<&'a str>, begin: f64, active: Option<f64>, notes: &mut Vec<String>) -> Result<Option<f64>, String> {
    let Some(raw) = get("end").map(str::trim).filter(|e| !e.is_empty() && *e != "indefinite") else { return Ok(active) };
    match parse_begin(Some(raw)) {
        Ok(end) if end <= begin => Err(format!("end=\"{raw}\" is not after its begin")),
        Ok(end) => Ok(Some(active.map_or(end - begin, |a| a.min(end - begin)))),
        Err(_) => {
            notes.push(format!("end=\"{raw}\" waits for an event or another animation and was ignored"));
            Ok(active)
        }
    }
}

impl Timing {
    /// Reads `begin`, `dur`, `repeatCount`, `repeatDur`, `end` and `fill`.
    /// Attributes that are read but cannot be honored add a line to `notes`.
    pub(crate) fn parse<'a>(get: impl Fn(&str) -> Option<&'a str>, notes: &mut Vec<String>) -> Result<Timing, String> {
        let begin = parse_begin(get("begin"))?;
        let dur = match get("dur").map(str::trim) {
            None | Some("indefinite") | Some("media") => return Err("it has no finite dur".into()),
            Some(v) => parse_clock(v).filter(|d| *d > 0.0).ok_or_else(|| format!("dur=\"{v}\" is not a positive time"))?,
        };
        // The timeline cannot hold a change faster than 4 ms, so a jump written as a
        // dur of 1 ms (spinners use it for the step back to the start) takes 4 ms.
        // Anything below half a millisecond is not a step anyone wrote.
        if dur < EPS * 0.5 {
            return Err(format!("dur=\"{dur}s\" is too short"));
        }
        let dur = dur.max(EPS * 4.0);
        // None: not given. Some(None): forever. Some(Some(x)): x seconds.
        let by_count = match get("repeatCount").map(str::trim) {
            None => None,
            Some("indefinite") => Some(None),
            Some(v) => Some(Some(number(v).filter(|c| *c > 0.0).ok_or_else(|| format!("repeatCount=\"{v}\" is not a positive number"))? * dur)),
        };
        let by_dur = match get("repeatDur").map(str::trim) {
            None => None,
            Some("indefinite") => Some(None),
            Some(v) => Some(Some(parse_clock(v).filter(|d| *d > 0.0).ok_or_else(|| format!("repeatDur=\"{v}\" is not a positive time"))?)),
        };
        let mut active = match (by_count, by_dur) {
            (None, None) => Some(dur),
            (Some(c), None) => c,
            (None, Some(d)) => d,
            (Some(c), Some(d)) => match (c, d) {
                (Some(a), Some(b)) => Some(a.min(b)),
                (Some(a), None) | (None, Some(a)) => Some(a),
                (None, None) => None,
            },
        };
        active = clamp_to_end(&get, begin, active, notes)?;
        Ok(Timing { begin, dur, active, freeze: get("fill").is_some_and(|f| f.trim() == "freeze"), fill_before: false, gap: 0.0 })
    }

    /// Reads the timing of a `set`. Without a `dur` the value holds from `begin`
    /// to the end of the scene, which is a hold of a few milliseconds that never
    /// goes back. A finite `dur`, `repeatCount` or `repeatDur` is one hold as
    /// long as the active time, because a constant does not change when it repeats.
    pub(crate) fn parse_set<'a>(get: impl Fn(&str) -> Option<&'a str>, notes: &mut Vec<String>) -> Result<Timing, String> {
        let begin = parse_begin(get("begin"))?;
        let dur = match get("dur").map(str::trim) {
            None | Some("indefinite") | Some("media") => None,
            Some(v) => Some(parse_clock(v).filter(|d| *d > 0.0).ok_or_else(|| format!("dur=\"{v}\" is not a positive time"))?),
        };
        // None: not given. Some(None): forever. Some(Some(x)): x seconds.
        let by_count = match (get("repeatCount").map(str::trim), dur) {
            (None, _) => None,
            (Some("indefinite"), _) | (_, None) => Some(None),
            (Some(v), Some(d)) => Some(Some(number(v).filter(|c| *c > 0.0).ok_or_else(|| format!("repeatCount=\"{v}\" is not a positive number"))? * d)),
        };
        let by_dur = match get("repeatDur").map(str::trim) {
            None => None,
            Some("indefinite") => Some(None),
            Some(v) => Some(Some(parse_clock(v).filter(|d| *d > 0.0).ok_or_else(|| format!("repeatDur=\"{v}\" is not a positive time"))?)),
        };
        let mut active = match (by_count, by_dur) {
            (None, None) => dur,
            (Some(c), None) => c,
            (None, Some(d)) => d,
            (Some(c), Some(d)) => match (c, d) {
                (Some(a), Some(b)) => Some(a.min(b)),
                (Some(a), None) | (None, Some(a)) => Some(a),
                (None, None) => None,
            },
        };
        active = clamp_to_end(&get, begin, active, notes)?;
        match active {
            Some(a) if a < EPS * 4.0 => Err(format!("its active time of {a}s is too short")),
            Some(a) => Ok(Timing { begin, dur: a, active: Some(a), freeze: get("fill").is_some_and(|f| f.trim() == "freeze"), fill_before: false, gap: 0.0 }),
            None => Ok(Timing { begin, dur: EPS * 4.0, active: Some(EPS * 4.0), freeze: true, fill_before: false, gap: 0.0 }),
        }
    }

    /// Where the animation stops on the scene timeline: infinite when it repeats forever.
    pub(crate) fn end(&self) -> f64 {
        self.active.map_or(f64::INFINITY, |a| self.begin + a)
    }

    /// Seconds from the start of one iteration to the start of the next.
    pub(crate) fn period(&self) -> f64 {
        self.dur + self.gap
    }
}

/// How the value moves between two key times.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Calc {
    Linear,
    Discrete,
    Paced,
    Spline,
}

/// Where a `steps()` easing puts its jumps.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Jump {
    Start,
    End,
    None,
    Both,
}

/// How the value moves across one interval of a curve with `Calc::Spline`.
#[derive(Debug, Clone, Copy, PartialEq)]
pub(crate) enum Ease {
    /// The control points of a CSS `cubic-bezier()` or a `keySplines` entry.
    Bezier([f64; 4]),
    /// CSS `steps()`: `count` equal pieces, each holding one value.
    Steps { count: u32, jump: Jump },
}

impl Ease {
    pub(crate) const LINEAR: Ease = Ease::Bezier([0.0, 0.0, 1.0, 1.0]);

    pub(crate) fn is_linear(&self) -> bool {
        *self == Ease::LINEAR
    }

    /// The easing of the same interval played backwards: `1 - f(1 - x)`.
    pub(crate) fn mirrored(self) -> Ease {
        match self {
            Ease::Bezier(e) => Ease::Bezier([1.0 - e[2], 1.0 - e[3], 1.0 - e[0], 1.0 - e[1]]),
            Ease::Steps { count, jump } => {
                let jump = match jump {
                    Jump::Start => Jump::End,
                    Jump::End => Jump::Start,
                    other => other,
                };
                Ease::Steps { count, jump }
            }
        }
    }
}

/// How far a `steps()` easing has gone, from 0 to 1, while the input is in
/// piece `piece` (counted from 0).
fn step_level(count: u32, jump: Jump, piece: usize) -> f64 {
    let shift = usize::from(matches!(jump, Jump::Start | Jump::Both));
    let jumps = match jump {
        Jump::Start | Jump::End => count,
        Jump::None => count.saturating_sub(1).max(1),
        Jump::Both => count + 1,
    };
    ((piece + shift) as f64 / f64::from(jumps)).min(1.0)
}

/// The values of one animation over one iteration, with their key times.
#[derive(Debug, Clone)]
pub(crate) struct Curve {
    times: Vec<f64>,
    values: Vec<Vec<f64>>,
    calc: Calc,
    eases: Vec<Ease>,
}

fn lerp(a: &[f64], b: &[f64], t: f64) -> Vec<f64> {
    a.iter().zip(b).map(|(x, y)| x + (y - x) * t).collect()
}

fn list(s: &str) -> impl Iterator<Item = &str> {
    s.split(';').map(str::trim).filter(|p| !p.is_empty())
}

/// Solves the cubic Bezier of `keySplines` for the progress that goes with the time fraction `x`.
fn bezier(c: [f64; 4], x: f64) -> f64 {
    let at = |s: f64, p1: f64, p2: f64| 3.0 * (1.0 - s).powi(2) * s * p1 + 3.0 * (1.0 - s) * s * s * p2 + s.powi(3);
    let (mut lo, mut hi) = (0.0, 1.0);
    for _ in 0..40 {
        let mid = (lo + hi) / 2.0;
        if at(mid, c[0], c[2]) < x {
            lo = mid;
        } else {
            hi = mid;
        }
    }
    at((lo + hi) / 2.0, c[1], c[3])
}

impl Curve {
    /// Builds the curve from the already parsed `values` (each entry has the
    /// same number of components) and the raw `keyTimes`, `calcMode` and
    /// `keySplines` attributes.
    pub(crate) fn new(values: Vec<Vec<f64>>, key_times: Option<&str>, calc: Option<&str>, key_splines: Option<&str>) -> Result<Curve, String> {
        let n = values.len();
        if n == 0 {
            return Err("it has no values".into());
        }
        let width = values[0].len();
        if width == 0 || values.iter().any(|v| v.len() != width) {
            return Err("its values do not all have the same number of components".into());
        }
        let calc = match calc.map(str::trim) {
            None | Some("") | Some("linear") => Calc::Linear,
            Some("discrete") => Calc::Discrete,
            Some("paced") => Calc::Paced,
            Some("spline") => Calc::Spline,
            Some(other) => return Err(format!("calcMode=\"{other}\" is not known")),
        };
        let given = match key_times.map(str::trim).filter(|s| !s.is_empty()) {
            None => None,
            Some(s) => Some(list(s).map(number).collect::<Option<Vec<f64>>>().ok_or("keyTimes is not a list of numbers")?),
        };
        if let (Some(g), true) = (&given, n > 1 && calc != Calc::Paced) {
            if g.len() != n {
                return Err(format!("keyTimes has {} entries for {n} values", g.len()));
            }
            if g[0] != 0.0 || (calc != Calc::Discrete && g[n - 1] != 1.0) || g.windows(2).any(|w| w[1] < w[0]) || g.iter().any(|t| !(0.0..=1.0).contains(t)) {
                return Err("keyTimes must rise from 0 to 1".into());
            }
        }
        let times = if n == 1 {
            vec![0.0]
        } else {
            match (calc, given) {
                (Calc::Paced, _) => {
                    let steps: Vec<f64> = values.windows(2).map(|w| w[0].iter().zip(&w[1]).map(|(a, b)| (b - a).powi(2)).sum::<f64>().sqrt()).collect();
                    let total: f64 = steps.iter().sum();
                    if total <= 0.0 {
                        (0..n).map(|i| i as f64 / (n - 1) as f64).collect()
                    } else {
                        let mut acc = 0.0;
                        let mut t = vec![0.0];
                        for s in &steps {
                            acc += s;
                            t.push(acc / total);
                        }
                        t[n - 1] = 1.0;
                        t
                    }
                }
                (_, Some(g)) => g,
                (Calc::Discrete, None) => (0..n).map(|i| i as f64 / n as f64).collect(),
                (_, None) => (0..n).map(|i| i as f64 / (n - 1) as f64).collect(),
            }
        };
        let mut splines: Vec<Ease> = Vec::new();
        if calc == Calc::Spline && n > 1 {
            let raw = key_splines.map(str::trim).filter(|s| !s.is_empty()).ok_or("calcMode=\"spline\" needs keySplines")?;
            for item in list(raw) {
                let nums: Vec<f64> = item.split(|c: char| c.is_whitespace() || c == ',').filter(|p| !p.is_empty()).filter_map(number).collect();
                if nums.len() != 4 || !(0.0..=1.0).contains(&nums[0]) || !(0.0..=1.0).contains(&nums[2]) {
                    return Err(format!("keySplines entry \"{item}\" is not four numbers with x values in 0 to 1"));
                }
                splines.push(Ease::Bezier([nums[0], nums[1], nums[2], nums[3]]));
            }
            if splines.len() != n - 1 {
                return Err(format!("keySplines has {} entries for {n} values", splines.len()));
            }
        }
        Ok(Curve { times, values, calc, eases: splines })
    }

    /// A curve through explicit `(time, value)` points with straight lines
    /// between them. Points with the same time are pulled `EPS` apart, so a jump
    /// is a short ramp. `dur` is the length of the iteration in seconds.
    pub(crate) fn from_points(mut times: Vec<f64>, values: Vec<Vec<f64>>, dur: f64) -> Result<Curve, String> {
        let width = values.first().map_or(0, Vec::len);
        if times.len() != values.len() || times.len() < 2 || width == 0 || values.iter().any(|v| v.len() != width) {
            return Err("its points are not usable".into());
        }
        let gap = EPS / dur;
        for i in 1..times.len() {
            if times[i] < times[i - 1] + gap {
                times[i] = times[i - 1] + gap;
            }
        }
        let last = times[times.len() - 1];
        if last > 1.0 {
            times.iter_mut().for_each(|t| *t /= last);
        }
        Ok(Curve { times, values, calc: Calc::Linear, eases: Vec::new() })
    }

    /// A curve with a key time and a value for each point and an easing for
    /// each interval between them.
    pub(crate) fn eased(values: Vec<Vec<f64>>, times: Vec<f64>, eases: Vec<Ease>) -> Result<Curve, String> {
        let n = values.len();
        let width = values.first().map_or(0, Vec::len);
        if n == 0 || times.len() != n || eases.len() + 1 != n || width == 0 || values.iter().any(|v| v.len() != width) {
            return Err("its keyframes are not usable".into());
        }
        if times[0] != 0.0 || times[n - 1] != 1.0 || times.windows(2).any(|w| w[1] < w[0]) {
            return Err("keyTimes must rise from 0 to 1".into());
        }
        let calc = if eases.iter().all(Ease::is_linear) { Calc::Linear } else { Calc::Spline };
        Ok(Curve { times, values, calc, eases })
    }

    #[cfg(test)]
    pub(crate) fn polyline_for_test(&self, dur: f64) -> Vec<(f64, Vec<f64>)> {
        self.polyline(dur)
    }

    /// One iteration as a polyline: progress `0..=1` and the value there.
    /// Linear between the points reproduces the animation.
    fn polyline(&self, dur: f64) -> Vec<(f64, Vec<f64>)> {
        let n = self.values.len();
        let mut out = Vec::new();
        if n == 1 {
            out.push((0.0, self.values[0].clone()));
            out.push((1.0, self.values[0].clone()));
            return out;
        }
        match self.calc {
            Calc::Linear | Calc::Paced => {
                for i in 0..n {
                    out.push((self.times[i], self.values[i].clone()));
                }
            }
            Calc::Spline => {
                for i in 0..n - 1 {
                    let (t0, t1) = (self.times[i], self.times[i + 1]);
                    match self.eases[i] {
                        Ease::Bezier(c) => {
                            for s in 0..SPLINE_STEPS {
                                let f = s as f64 / SPLINE_STEPS as f64;
                                out.push((t0 + (t1 - t0) * f, lerp(&self.values[i], &self.values[i + 1], bezier(c, f))));
                            }
                        }
                        Ease::Steps { count, jump } => {
                            // Each piece holds one value and the next one is reached in a ramp
                            // of EPS that ends where the piece does.
                            let pieces = count as usize;
                            let ramp = EPS / dur;
                            for j in 0..pieces {
                                let start = t0 + (t1 - t0) * j as f64 / pieces as f64;
                                let stop = t0 + (t1 - t0) * (j + 1) as f64 / pieces as f64;
                                let v = lerp(&self.values[i], &self.values[i + 1], step_level(count, jump, j));
                                out.push((start, v.clone()));
                                let hold = (stop - ramp).max(start);
                                if hold > start {
                                    out.push((hold, v));
                                }
                            }
                        }
                    }
                }
                out.push((1.0, self.values[n - 1].clone()));
            }
            Calc::Discrete => {
                let eps = EPS / dur;
                for i in 0..n {
                    let start = self.times[i];
                    let stop = if i + 1 < n { self.times[i + 1] } else { 1.0 };
                    out.push((start, self.values[i].clone()));
                    let end = (stop - eps).max(start);
                    if end > start {
                        out.push((end, self.values[i].clone()));
                    }
                }
                if out.last().is_some_and(|p| p.0 < 1.0) {
                    out.push((1.0, self.values[n - 1].clone()));
                }
            }
        }
        out
    }
}

fn eval(poly: &[(f64, Vec<f64>)], u: f64) -> Vec<f64> {
    if u <= poly[0].0 {
        return poly[0].1.clone();
    }
    for w in poly.windows(2) {
        if u <= w[1].0 {
            let span = w[1].0 - w[0].0;
            return if span <= 0.0 { w[1].1.clone() } else { lerp(&w[0].1, &w[1].1, (u - w[0].0) / span) };
        }
    }
    poly[poly.len() - 1].1.clone()
}

/// Points on the scene timeline `0..=total` that, joined by straight lines and
/// held beyond the ends, give the value of the animation at every moment.
///
/// `base` is the value without the animation (before it begins, and after it
/// ends unless it freezes). An animation that repeats forever has no start
/// that matters on a looping scene, so its `begin` only shifts the phase, and
/// the loop closes without a seam.
pub(crate) fn bake(curve: &Curve, timing: &Timing, base: &[f64], total: f64) -> Result<Vec<(f64, Vec<f64>)>, String> {
    let dur = timing.dur;
    let period = timing.period();
    let contiguous = timing.gap <= 1e-12;
    let poly = curve.polyline(dur);
    let periodic = timing.active.is_none();
    let first = if periodic { timing.begin.rem_euclid(period) - period } else { timing.begin };
    let stop = timing.end().min(total);

    let iterations = ((stop - first.max(0.0)) / period).ceil().max(0.0);
    if iterations * poly.len() as f64 > MAX_POINTS as f64 {
        return Err(format!("it needs more than {MAX_POINTS} keyframes on a {total}s timeline"));
    }

    // The value in the idle time after an iteration: the last one when it
    // freezes, the value without the animation otherwise.
    let end_value = eval(&poly, 1.0);
    let held = if timing.freeze { end_value } else { base.to_vec() };

    let mut pts: Vec<(f64, Vec<f64>)> = Vec::new();
    if !periodic && first > EPS {
        let before = if timing.fill_before { poly[0].1.clone() } else { base.to_vec() };
        pts.push((0.0, before.clone()));
        pts.push((first - EPS, before));
    }
    let mut a = first;
    while a < stop - 1e-12 {
        let b = a + dur;
        let next = a + period;
        let (lo, hi) = (a.max(0.0), b.min(stop));
        if hi > lo + 1e-12 {
            // The first iteration starts after 0: the time before it is idle too.
            if !contiguous && pts.is_empty() && lo > EPS {
                pts.push((0.0, held.clone()));
                pts.push((lo - EPS, held.clone()));
            }
            let (ulo, uhi) = ((lo - a) / dur, (hi - a) / dur);
            // Another iteration follows right away: end this one a hair early so
            // the next starts at exactly `b` and the jump back is a short ramp.
            let continues = contiguous && b < stop - 1e-9;
            // The early end carries the value the animation has at that moment, so
            // the stretch stays on its line.
            let uend = if continues { uhi - EPS / dur } else { uhi };
            pts.push((lo, eval(&poly, ulo)));
            for (u, v) in &poly {
                if *u > ulo + 1e-12 && *u < uend - 1e-12 {
                    pts.push((a + u * dur, v.clone()));
                }
            }
            pts.push((if continues { hi - EPS } else { hi }, eval(&poly, uend)));
            // The idle time up to the next iteration, or up to the end of the timeline.
            if !contiguous && b < stop - 1e-9 {
                let until = next.min(stop);
                if !timing.freeze {
                    pts.push((b + EPS, held.clone()));
                }
                let hold_to = if until >= stop - 1e-9 { stop } else { until - EPS };
                if hold_to > b + 2.0 * EPS {
                    pts.push((hold_to, held.clone()));
                }
            }
        } else if !contiguous && b <= 0.0 && next > 2.0 * EPS && next < stop && pts.is_empty() {
            // The whole iteration lies before 0 and the idle time runs into the scene.
            pts.push((0.0, held.clone()));
            pts.push((next - EPS, held.clone()));
        }
        a = next;
    }
    if !periodic && !timing.freeze && timing.end() + EPS <= total + 1e-9 && !pts.is_empty() {
        pts.push((timing.end() + EPS, base.to_vec()));
    }

    let mut out: Vec<(f64, Vec<f64>)> = Vec::with_capacity(pts.len());
    for p in pts {
        if out.last().is_none_or(|l| p.0 > l.0 + 1e-12) {
            out.push(p);
        }
    }
    Ok(out)
}

/// What the planner needs to know about one animation.
#[derive(Debug, Clone, Copy)]
pub(crate) struct Span {
    pub period: f64,
    pub indefinite: bool,
    /// For a finite animation, where it stops.
    pub end: f64,
    /// A finite animation that goes back to the value without it after its
    /// end. The scene has to last a moment longer for the last frame to show that.
    pub removes: bool,
}

/// The scene timeline that holds every animation.
#[derive(Debug, Clone, PartialEq)]
pub(crate) struct Plan {
    pub duration: f64,
    pub looping: bool,
    pub notes: Vec<String>,
}

fn gcd(a: u64, b: u64) -> u64 {
    if b == 0 {
        a
    } else {
        gcd(b, a % b)
    }
}

/// Picks `duration` and the loop mode. Without a repeating animation the scene
/// plays once and lasts until the last one ends. With one, the scene loops at
/// the least common multiple of the periods (to the millisecond), and finite
/// animations play again on every loop.
pub(crate) fn plan(spans: &[Span]) -> Plan {
    let mut notes = Vec::new();
    if spans.is_empty() {
        return Plan { duration: 0.0, looping: false, notes };
    }
    // A play-once scene lasts a moment longer for the return to the base value.
    // A looping one is back at the start anyway.
    let finite_end = |room: bool| spans.iter().filter(|s| !s.indefinite).map(|s| if room && s.removes { s.end + EPS } else { s.end }).fold(0.0, f64::max);
    let periods: Vec<u64> = spans.iter().filter(|s| s.indefinite).map(|s| ((s.period * 1000.0).round() as u64).max(1)).collect();
    if periods.is_empty() {
        return Plan { duration: finite_end(true), looping: false, notes };
    }
    let cap = (MAX_LOOP_SECS * 1000.0) as u64;
    let mut lcm: u64 = 1;
    let mut over = false;
    for p in &periods {
        lcm = lcm / gcd(lcm, *p) * p;
        if lcm > cap {
            over = true;
            break;
        }
    }
    let mut ms = if over {
        let longest = periods.iter().copied().max().unwrap_or(1);
        notes.push(format!("the repeating animations do not share a loop shorter than {MAX_LOOP_SECS}s; the scene loops at {}s and the others drift", longest as f64 / 1000.0));
        longest
    } else {
        lcm
    };
    let finite_end = finite_end(false);
    let need = (finite_end * 1000.0).ceil() as u64;
    if need > ms {
        let rounded = need.div_ceil(ms) * ms;
        if rounded <= cap {
            ms = rounded;
        } else {
            notes.push(format!("an animation that runs until {finite_end}s is longer than the loop and is cut at {}s", ms as f64 / 1000.0));
        }
    }
    Plan { duration: ms as f64 / 1000.0, looping: true, notes }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn close(a: f64, b: f64) -> bool {
        (a - b).abs() < 1e-9
    }

    fn timing(pairs: &[(&str, &str)]) -> Result<Timing, String> {
        let mut notes = Vec::new();
        Timing::parse(|k| pairs.iter().find(|(n, _)| *n == k).map(|(_, v)| *v), &mut notes)
    }

    fn lin(vals: &[f64]) -> Curve {
        Curve::new(vals.iter().map(|v| vec![*v]).collect(), None, None, None).unwrap()
    }

    #[test]
    fn clock_values() {
        assert_eq!(parse_clock("3s"), Some(3.0));
        assert_eq!(parse_clock(" 500ms "), Some(0.5));
        assert_eq!(parse_clock("1.5min"), Some(90.0));
        assert_eq!(parse_clock("2h"), Some(7200.0));
        assert_eq!(parse_clock("2"), Some(2.0));
        assert_eq!(parse_clock(".25s"), Some(0.25));
        assert_eq!(parse_clock("1:30"), Some(90.0));
        assert_eq!(parse_clock("01:01:30.5"), Some(3690.5));
        assert_eq!(parse_clock("-1s"), Some(-1.0));
        assert_eq!(parse_clock("click"), None);
        assert_eq!(parse_clock("indefinite"), None);
        assert_eq!(parse_clock("inf"), None);
        assert_eq!(parse_clock("1:2:3:4"), None);
        assert_eq!(parse_clock(""), None);
    }

    #[test]
    fn begin_lists() {
        assert_eq!(parse_begin(None), Ok(0.0));
        assert_eq!(parse_begin(Some("0.5s")), Ok(0.5));
        assert_eq!(parse_begin(Some("2s; 1s")), Ok(1.0));
        assert_eq!(parse_begin(Some("1s;click")), Ok(1.0));
        assert!(parse_begin(Some("click")).is_err());
        assert!(parse_begin(Some("a.end+1s")).is_err());
        assert!(parse_begin(Some("indefinite")).is_err());
        assert_eq!(parse_begin(Some("-2s")), Ok(-2.0));
    }

    #[test]
    fn timing_defaults_and_repeats() {
        let t = timing(&[("dur", "2s")]).unwrap();
        assert_eq!((t.begin, t.dur, t.active, t.freeze), (0.0, 2.0, Some(2.0), false));
        let t = timing(&[("dur", "2s"), ("repeatCount", "3")]).unwrap();
        assert_eq!(t.active, Some(6.0));
        let t = timing(&[("dur", "2s"), ("repeatCount", "indefinite")]).unwrap();
        assert_eq!(t.active, None);
        let t = timing(&[("dur", "2s"), ("repeatDur", "5s")]).unwrap();
        assert_eq!(t.active, Some(5.0));
        let t = timing(&[("dur", "2s"), ("repeatCount", "10"), ("repeatDur", "5s")]).unwrap();
        assert_eq!(t.active, Some(5.0));
        let t = timing(&[("dur", "2s"), ("repeatCount", "indefinite"), ("repeatDur", "5s")]).unwrap();
        assert_eq!(t.active, Some(5.0));
        let t = timing(&[("dur", "2s"), ("repeatDur", "indefinite")]).unwrap();
        assert_eq!(t.active, None);
        let t = timing(&[("dur", "2s"), ("repeatCount", "indefinite"), ("end", "7s"), ("begin", "1s")]).unwrap();
        assert_eq!(t.active, Some(6.0));
        let t = timing(&[("dur", "1s"), ("fill", "freeze")]).unwrap();
        assert!(t.freeze);
    }

    #[test]
    fn timing_errors() {
        assert!(timing(&[]).is_err());
        assert!(timing(&[("dur", "indefinite")]).is_err());
        assert!(timing(&[("dur", "0s")]).is_err());
        assert!(timing(&[("dur", "0.4ms")]).is_err());
        assert!(timing(&[("dur", "1s"), ("repeatCount", "0")]).is_err());
        assert!(timing(&[("dur", "1s"), ("begin", "click")]).is_err());
        assert!(timing(&[("dur", "1s"), ("begin", "2s"), ("end", "1s")]).is_err());
    }

    /// The value of a baked track at `t`, by linear interpolation between its points.
    fn baked_at(pts: &[(f64, Vec<f64>)], t: f64) -> f64 {
        if t <= pts[0].0 {
            return pts[0].1[0];
        }
        for w in pts.windows(2) {
            if t <= w[1].0 {
                let k = (t - w[0].0) / (w[1].0 - w[0].0);
                return w[0].1[0] + (w[1].1[0] - w[0].1[0]) * k;
            }
        }
        pts[pts.len() - 1].1[0]
    }

    fn gapped(begin: f64, freeze: bool) -> Timing {
        Timing { begin, dur: 1.0, active: None, freeze, fill_before: false, gap: 1.0 }
    }

    #[test]
    fn an_animation_that_starts_again_on_a_schedule_reverts_in_the_gap() {
        let pts = bake(&lin(&[0.0, 10.0]), &gapped(0.0, false), &[0.0], 6.0).unwrap();
        assert!(close(baked_at(&pts, 0.5), 5.0) && close(baked_at(&pts, 1.0), 10.0), "the run");
        assert!(close(baked_at(&pts, 1.5), 0.0), "the gap shows the value without the animation: {}", baked_at(&pts, 1.5));
        assert!(close(baked_at(&pts, 2.5), 5.0), "the next run starts at the period: {}", baked_at(&pts, 2.5));
        assert!(close(baked_at(&pts, 3.5), 0.0));
        assert!(close(baked_at(&pts, 4.5), 5.0));
        assert!(close(baked_at(&pts, 5.5), 0.0), "and the gap at the end of the timeline too");
    }

    #[test]
    fn a_frozen_animation_holds_its_last_value_in_the_gap() {
        let pts = bake(&lin(&[0.0, 10.0]), &gapped(0.0, true), &[0.0], 6.0).unwrap();
        for t in [1.2, 1.5, 1.9, 3.5, 5.5] {
            assert!(close(baked_at(&pts, t), 10.0), "t={t}: {}", baked_at(&pts, t));
        }
        assert!(close(baked_at(&pts, 2.5), 5.0), "and a new run starts over");
    }

    #[test]
    fn a_gap_with_a_start_after_zero_idles_before_the_first_run() {
        // Starts at 0.5 of a 2 s period: the first half second is idle, as the end of the last run.
        let rest = bake(&lin(&[0.0, 10.0]), &gapped(0.5, false), &[0.0], 4.0).unwrap();
        assert!(close(baked_at(&rest, 0.25), 0.0), "{}", baked_at(&rest, 0.25));
        assert!(close(baked_at(&rest, 1.0), 5.0) && close(baked_at(&rest, 1.5), 10.0));
        assert!(close(baked_at(&rest, 2.0), 0.0), "{}", baked_at(&rest, 2.0));
        let frozen = bake(&lin(&[0.0, 10.0]), &gapped(0.5, true), &[0.0], 4.0).unwrap();
        assert!(close(baked_at(&frozen, 0.25), 10.0), "frozen, the idle time before the first run holds the end of the last: {}", baked_at(&frozen, 0.25));
    }

    #[test]
    fn no_gap_bakes_exactly_as_before() {
        let t = Timing { begin: 0.0, dur: 1.0, active: None, freeze: false, fill_before: false, gap: 0.0 };
        let pts = bake(&lin(&[0.0, 10.0]), &t, &[0.0], 3.0).unwrap();
        assert!(close(baked_at(&pts, 0.5), 5.0) && close(baked_at(&pts, 1.5), 5.0) && close(baked_at(&pts, 2.5), 5.0));
        assert_eq!(t.period(), 1.0);
        assert_eq!(gapped(0.0, false).period(), 2.0);
    }

    #[test]
    fn a_dur_below_four_milliseconds_is_held_to_four() {
        // Spinners write the jump back to the start as a dur of 1 ms.
        let t = timing(&[("dur", "0.001s"), ("fill", "freeze")]).unwrap();
        assert!((t.dur - 0.004).abs() < 1e-12 && t.freeze);
        assert!((timing(&[("dur", "3ms")]).unwrap().dur - 0.004).abs() < 1e-12);
        assert!((timing(&[("dur", "5ms")]).unwrap().dur - 0.005).abs() < 1e-12, "longer ones are kept");
    }

    #[test]
    fn unresolvable_end_is_noted_not_fatal() {
        let mut notes = Vec::new();
        let pairs = [("dur", "1s"), ("end", "other.end")];
        let t = Timing::parse(|k| pairs.iter().find(|(n, _)| *n == k).map(|(_, v)| *v), &mut notes).unwrap();
        assert_eq!(t.active, Some(1.0));
        assert_eq!(notes.len(), 1);
    }

    #[test]
    fn curve_validation() {
        let v = vec![vec![0.0], vec![1.0], vec![2.0]];
        assert!(Curve::new(v.clone(), Some("0;0.5;1"), None, None).is_ok());
        assert!(Curve::new(v.clone(), Some("0;0.5;1;"), None, None).is_ok());
        assert!(Curve::new(v.clone(), Some("0;1"), None, None).is_err());
        assert!(Curve::new(v.clone(), Some("0.1;0.5;1"), None, None).is_err());
        assert!(Curve::new(v.clone(), Some("0;0.5;0.9"), None, None).is_err());
        assert!(Curve::new(v.clone(), Some("0;0.7;0.5"), None, None).is_err());
        assert!(Curve::new(v.clone(), Some("0;0.5;0.9"), Some("discrete"), None).is_ok());
        assert!(Curve::new(v.clone(), None, Some("bogus"), None).is_err());
        assert!(Curve::new(v.clone(), None, Some("spline"), None).is_err());
        assert!(Curve::new(v.clone(), None, Some("spline"), Some("0.5 0 0.5 1")).is_err());
        assert!(Curve::new(v.clone(), None, Some("spline"), Some("0.5 0 0.5 1; 0.5 0 0.5 1")).is_ok());
        assert!(Curve::new(v.clone(), None, Some("spline"), Some("1.5 0 0.5 1; 0.5 0 0.5 1")).is_err());
        assert!(Curve::new(vec![vec![0.0], vec![1.0, 2.0]], None, None, None).is_err());
        assert!(Curve::new(vec![], None, None, None).is_err());
    }

    #[test]
    fn paced_times_follow_distance() {
        let c = Curve::new(vec![vec![0.0], vec![1.0], vec![4.0]], None, Some("paced"), None).unwrap();
        assert!(close(c.times[1], 0.25) && close(c.times[2], 1.0));
        let flat = Curve::new(vec![vec![2.0], vec![2.0], vec![2.0]], None, Some("paced"), None).unwrap();
        assert!(close(flat.times[1], 0.5));
    }

    #[test]
    fn bezier_endpoints_and_linear_case() {
        for x in [0.0, 0.25, 0.5, 0.75, 1.0] {
            assert!((bezier([0.0, 0.0, 1.0, 1.0], x) - x).abs() < 1e-6);
        }
        let ease = [0.42, 0.0, 0.58, 1.0];
        assert!(bezier(ease, 0.0).abs() < 1e-6 && (bezier(ease, 1.0) - 1.0).abs() < 1e-6);
        assert!((bezier(ease, 0.5) - 0.5).abs() < 1e-6);
        assert!(bezier(ease, 0.2) < 0.2);
    }

    #[test]
    fn spinner_one_iteration_is_two_points() {
        let t = timing(&[("dur", "2s"), ("repeatCount", "indefinite")]).unwrap();
        let pts = bake(&lin(&[0.0, 360.0]), &t, &[0.0], 2.0).unwrap();
        assert_eq!(pts.len(), 2);
        assert!(close(pts[0].0, 0.0) && close(pts[0].1[0], 0.0));
        assert!(close(pts[1].0, 2.0) && close(pts[1].1[0], 360.0));
    }

    #[test]
    fn repeats_unroll_with_a_short_ramp_at_the_seam() {
        let t = timing(&[("dur", "1s"), ("repeatCount", "2")]).unwrap();
        let pts = bake(&lin(&[0.0, 360.0]), &t, &[0.0], 2.0).unwrap();
        let times: Vec<f64> = pts.iter().map(|p| p.0).collect();
        assert_eq!(pts.len(), 4);
        assert!(close(times[1], 1.0 - EPS) && close(times[2], 1.0) && close(times[3], 2.0));
        assert!(close(pts[1].1[0], 360.0 * (1.0 - EPS)) && close(pts[2].1[0], 0.0));
    }

    #[test]
    fn delayed_finite_animation_holds_the_base_first_and_goes_back_after() {
        let t = timing(&[("dur", "2s"), ("begin", "1s")]).unwrap();
        let pts = bake(&lin(&[10.0, 20.0]), &t, &[5.0], 5.0).unwrap();
        let want = [(0.0, 5.0), (1.0 - EPS, 5.0), (1.0, 10.0), (3.0, 20.0), (3.0 + EPS, 5.0)];
        assert_eq!(pts.len(), want.len());
        for (p, w) in pts.iter().zip(want) {
            assert!(close(p.0, w.0) && close(p.1[0], w.1), "{p:?} vs {w:?}");
        }
    }

    #[test]
    fn a_backwards_fill_holds_the_first_value_during_the_delay() {
        let mut t = timing(&[("dur", "2s"), ("begin", "1s")]).unwrap();
        t.fill_before = true;
        let pts = bake(&lin(&[10.0, 20.0]), &t, &[5.0], 5.0).unwrap();
        assert!(close(pts[0].1[0], 10.0) && close(pts[1].1[0], 10.0), "{pts:?}");
        t.fill_before = false;
        let pts = bake(&lin(&[10.0, 20.0]), &t, &[5.0], 5.0).unwrap();
        assert!(close(pts[0].1[0], 5.0));
    }

    #[test]
    fn freeze_keeps_the_last_value() {
        let t = timing(&[("dur", "2s"), ("fill", "freeze")]).unwrap();
        let pts = bake(&lin(&[10.0, 20.0]), &t, &[5.0], 5.0).unwrap();
        assert_eq!(pts.len(), 2);
        assert!(close(pts[1].1[0], 20.0));
    }

    #[test]
    fn repeating_animation_with_a_delay_becomes_a_phase_shift() {
        let t = timing(&[("dur", "2s"), ("begin", "0.5s"), ("repeatCount", "indefinite")]).unwrap();
        let pts = bake(&lin(&[0.0, 360.0]), &t, &[0.0], 2.0).unwrap();
        // At 0 the animation is 1.5s into its cycle (270), reaches 360 at 0.5s,
        // starts again at 0 and is back at 270 when the loop closes.
        assert!(close(pts[0].0, 0.0) && close(pts[0].1[0], 270.0));
        let last = pts.last().unwrap();
        assert!(close(last.0, 2.0) && close(last.1[0], 270.0));
        assert!(pts.iter().any(|p| close(p.0, 0.5) && close(p.1[0], 0.0)));
        assert!(pts.iter().any(|p| close(p.0, 0.5 - EPS) && close(p.1[0], 360.0 * (1.0 - EPS / 2.0))));
    }

    #[test]
    fn negative_begin_starts_part_way_in() {
        let t = timing(&[("dur", "4s"), ("begin", "-1s")]).unwrap();
        let pts = bake(&lin(&[0.0, 8.0]), &t, &[0.0], 3.0).unwrap();
        assert!(close(pts[0].0, 0.0) && close(pts[0].1[0], 2.0));
        let last = pts.last().unwrap();
        assert!(close(last.0, 3.0) && close(last.1[0], 8.0));
    }

    #[test]
    fn discrete_makes_steps() {
        let c = Curve::new(vec![vec![1.0], vec![2.0], vec![3.0]], None, Some("discrete"), None).unwrap();
        let t = timing(&[("dur", "3s"), ("fill", "freeze")]).unwrap();
        let pts = bake(&c, &t, &[0.0], 3.0).unwrap();
        let at = |time: f64| {
            let poly: Vec<(f64, Vec<f64>)> = pts.clone();
            eval(&poly, time)[0]
        };
        assert!(close(at(0.5), 1.0) && close(at(1.5), 2.0) && close(at(2.5), 3.0));
        assert!(close(at(0.9985), 1.0));
        assert!(close(at(1.002), 2.0));
    }

    #[test]
    fn spline_follows_the_ease_curve() {
        let c = Curve::new(vec![vec![0.0], vec![100.0]], None, Some("spline"), Some("0.42 0 0.58 1")).unwrap();
        let t = timing(&[("dur", "1s"), ("fill", "freeze")]).unwrap();
        let pts = bake(&c, &t, &[0.0], 1.0).unwrap();
        assert_eq!(pts.len(), SPLINE_STEPS + 1);
        let mid = eval(&pts, 0.5)[0];
        assert!((mid - 50.0).abs() < 0.5);
        assert!(eval(&pts, 0.1)[0] < 10.0);
        assert!(eval(&pts, 0.9)[0] > 90.0);
        assert!(pts.windows(2).all(|w| w[1].1[0] >= w[0].1[0]));
    }

    #[test]
    fn components_move_together() {
        let c = Curve::new(vec![vec![0.0, 10.0], vec![100.0, 20.0]], None, None, None).unwrap();
        let t = timing(&[("dur", "1s"), ("fill", "freeze")]).unwrap();
        let pts = bake(&c, &t, &[0.0, 0.0], 1.0).unwrap();
        assert_eq!(pts[1].1, vec![100.0, 20.0]);
    }

    #[test]
    fn too_many_keyframes_is_an_error() {
        let t = timing(&[("dur", "0.01s"), ("repeatCount", "indefinite")]).unwrap();
        assert!(bake(&lin(&[0.0, 1.0, 0.0, 1.0]), &t, &[0.0], 60.0).is_err());
    }

    #[test]
    fn times_strictly_rise() {
        let t = timing(&[("dur", "0.5s"), ("repeatCount", "indefinite")]).unwrap();
        let pts = bake(&lin(&[0.0, 1.0, 0.0]), &t, &[0.0], 3.0).unwrap();
        assert!(pts.windows(2).all(|w| w[1].0 > w[0].0));
    }

    #[test]
    fn plan_without_repeats_plays_once() {
        let p = plan(&[Span { period: 1.0, indefinite: false, end: 3.0, removes: false }, Span { period: 1.0, indefinite: false, end: 2.0, removes: false }]);
        assert_eq!(p, Plan { duration: 3.0, looping: false, notes: vec![] });
        assert_eq!(plan(&[]).duration, 0.0);
    }

    #[test]
    fn plan_leaves_a_moment_for_the_return_to_the_base_value() {
        let p = plan(&[Span { period: 1.0, indefinite: false, end: 3.0, removes: true }, Span { period: 1.0, indefinite: false, end: 2.0, removes: false }]);
        assert!(close(p.duration, 3.0 + EPS) && !p.looping);
        let frozen = plan(&[Span { period: 1.0, indefinite: false, end: 3.0, removes: false }]);
        assert!(close(frozen.duration, 3.0));
    }

    #[test]
    fn a_finite_animation_without_fill_ends_on_the_base_value_on_the_last_frame() {
        let t = timing(&[("dur", "2s"), ("begin", "1s")]).unwrap();
        let total = plan(&[Span { period: 2.0, indefinite: false, end: t.end(), removes: true }]).duration;
        let pts = bake(&lin(&[10.0, 20.0]), &t, &[5.0], total).unwrap();
        let last = pts.last().unwrap();
        assert!(close(last.0, 3.0 + EPS) && close(last.1[0], 5.0), "{last:?}");
    }

    #[test]
    fn plan_loops_at_the_common_period() {
        let p = plan(&[Span { period: 1.0, indefinite: true, end: f64::INFINITY, removes: false }, Span { period: 1.5, indefinite: true, end: f64::INFINITY, removes: false }]);
        assert!(p.looping && close(p.duration, 3.0) && p.notes.is_empty());
        let one = plan(&[Span { period: 1.2, indefinite: true, end: f64::INFINITY, removes: false }]);
        assert!(close(one.duration, 1.2));
    }

    #[test]
    fn a_looping_scene_does_not_grow_for_the_return_to_the_base_value() {
        let p = plan(&[Span { period: 2.0, indefinite: true, end: f64::INFINITY, removes: false }, Span { period: 2.0, indefinite: false, end: 2.0, removes: true }]);
        assert!(p.looping && close(p.duration, 2.0), "{p:?}");
    }

    #[test]
    fn plan_stretches_the_loop_over_a_long_finite_animation() {
        let p = plan(&[Span { period: 2.0, indefinite: true, end: f64::INFINITY, removes: false }, Span { period: 5.0, indefinite: false, end: 5.0, removes: false }]);
        assert!(p.looping && close(p.duration, 6.0));
    }

    #[test]
    fn plan_caps_unrelated_periods() {
        let p = plan(&[Span { period: 1.013, indefinite: true, end: f64::INFINITY, removes: false }, Span { period: 1.017, indefinite: true, end: f64::INFINITY, removes: false }, Span { period: 1.019, indefinite: true, end: f64::INFINITY, removes: false }]);
        assert!(p.looping && close(p.duration, 1.019));
        assert_eq!(p.notes.len(), 1);
    }
    fn set_timing(pairs: &[(&str, &str)]) -> Result<Timing, String> {
        let mut notes = Vec::new();
        Timing::parse_set(|k| pairs.iter().find(|(n, _)| *n == k).map(|(_, v)| *v), &mut notes)
    }

    #[test]
    fn a_set_without_dur_holds_for_good() {
        let t = set_timing(&[("begin", "2s")]).unwrap();
        assert!(close(t.begin, 2.0) && t.freeze && t.active == Some(EPS * 4.0));
        assert!(close(t.end(), 2.0 + EPS * 4.0), "the scene needs to last only a moment after the switch");
        assert_eq!(set_timing(&[("dur", "indefinite")]).unwrap(), set_timing(&[]).unwrap());
        assert!(set_timing(&[("repeatCount", "indefinite"), ("dur", "1s")]).unwrap().freeze, "a constant that repeats forever holds forever");
    }

    #[test]
    fn a_set_with_a_dur_lasts_that_long() {
        let t = set_timing(&[("begin", "1s"), ("dur", "2s")]).unwrap();
        assert!(close(t.dur, 2.0) && t.active == Some(2.0) && !t.freeze);
        assert!(set_timing(&[("dur", "2s"), ("fill", "freeze")]).unwrap().freeze);
        let rep = set_timing(&[("dur", "2s"), ("repeatCount", "2.5")]).unwrap();
        assert!(close(rep.dur, 5.0) && rep.active == Some(5.0), "one hold of the whole active time");
        let cut = set_timing(&[("dur", "2s"), ("repeatDur", "3s")]).unwrap();
        assert_eq!(cut.active, Some(3.0));
        let ended = set_timing(&[("begin", "1s"), ("end", "4s")]).unwrap();
        assert!(close(ended.dur, 3.0) && ended.active == Some(3.0) && !ended.freeze);
    }

    #[test]
    fn a_set_with_bad_timing_is_an_error() {
        assert!(set_timing(&[("dur", "-1s")]).is_err());
        assert!(set_timing(&[("dur", "2s"), ("repeatCount", "0")]).is_err());
        assert!(set_timing(&[("begin", "click")]).is_err());
        assert!(set_timing(&[("begin", "3s"), ("end", "2s")]).is_err());
        assert!(set_timing(&[("dur", "0.001s")]).is_err());
    }

    fn eased(values: &[f64], ease: Ease) -> Curve {
        Curve::eased(values.iter().map(|v| vec![*v]).collect(), (0..values.len()).map(|i| i as f64 / (values.len() - 1) as f64).collect(), vec![ease; values.len() - 1]).unwrap()
    }

    fn value_at(c: &Curve, dur: f64, u: f64) -> f64 {
        eval(&c.polyline_for_test(dur), u)[0]
    }

    #[test]
    fn steps_become_a_staircase_with_millisecond_ramps() {
        let c = eased(&[0.0, 8.0], Ease::Steps { count: 4, jump: Jump::End });
        for (u, want) in [(0.0, 0.0), (0.2, 0.0), (0.3, 2.0), (0.6, 4.0), (0.9, 6.0), (1.0, 8.0)] {
            assert!(close(value_at(&c, 1.0, u), want), "u={u}: {}", value_at(&c, 1.0, u));
        }
        // The step is a ramp of EPS that ends at the piece boundary.
        let ramp = value_at(&c, 1.0, 0.25 - EPS / 2.0);
        assert!(ramp > 0.0 && ramp < 2.0, "{ramp}");
        assert!(close(value_at(&c, 1.0, 0.25 - EPS * 2.0), 0.0));
    }

    #[test]
    fn jump_terms_choose_the_levels() {
        let level = |jump: Jump, count: u32, u: f64| value_at(&eased(&[0.0, 1.0], Ease::Steps { count, jump }), 1.0, u);
        assert!(close(level(Jump::Start, 4, 0.1), 0.25) && close(level(Jump::Start, 4, 0.9), 1.0));
        assert!(close(level(Jump::End, 4, 0.1), 0.0) && close(level(Jump::End, 4, 0.9), 0.75));
        assert!(close(level(Jump::None, 3, 0.1), 0.0) && close(level(Jump::None, 3, 0.9), 1.0) && close(level(Jump::None, 3, 0.5), 0.5));
        assert!(close(level(Jump::Both, 3, 0.1), 0.25) && close(level(Jump::Both, 3, 0.9), 0.75));
    }

    #[test]
    fn steps_between_several_keyframes_stay_in_their_interval() {
        let c = Curve::eased(vec![vec![0.0], vec![10.0], vec![0.0]], vec![0.0, 0.5, 1.0], vec![Ease::Steps { count: 2, jump: Jump::End }, Ease::LINEAR]).unwrap();
        assert!(close(value_at(&c, 4.0, 0.1), 0.0) && close(value_at(&c, 4.0, 0.3), 5.0));
        assert!(close(value_at(&c, 4.0, 0.75), 5.0) && close(value_at(&c, 4.0, 1.0), 0.0));
    }

    #[test]
    fn mirroring_swaps_the_jump_of_steps() {
        let mirrored = |jump: Jump| Ease::Steps { count: 3, jump }.mirrored();
        assert_eq!(mirrored(Jump::End), Ease::Steps { count: 3, jump: Jump::Start });
        assert_eq!(mirrored(Jump::Start), Ease::Steps { count: 3, jump: Jump::End });
        assert_eq!(mirrored(Jump::Both), Ease::Steps { count: 3, jump: Jump::Both });
        assert_eq!(mirrored(Jump::None), Ease::Steps { count: 3, jump: Jump::None });
        let Ease::Bezier(m) = Ease::Bezier([0.42, 0.0, 1.0, 1.0]).mirrored() else { panic!("a Bezier mirrors to a Bezier") };
        assert!(m.iter().zip([0.0, 0.0, 0.58, 1.0]).all(|(a, b)| (a - b).abs() < 1e-12), "{m:?}");
    }

    #[test]
    fn eased_curves_are_checked() {
        assert!(Curve::eased(vec![vec![0.0], vec![1.0]], vec![0.0, 0.5], vec![Ease::LINEAR]).is_err(), "key times must end at 1");
        assert!(Curve::eased(vec![vec![0.0], vec![1.0]], vec![0.0, 1.0], vec![]).is_err(), "an easing for each interval");
        assert!(Curve::eased(vec![vec![0.0], vec![1.0, 2.0]], vec![0.0, 1.0], vec![Ease::LINEAR]).is_err(), "equal widths");
    }

    #[test]
    fn from_points_pulls_equal_times_apart() {
        let c = Curve::from_points(vec![0.0, 0.5, 0.5, 1.0], vec![vec![0.0], vec![1.0], vec![5.0], vec![6.0]], 2.0).unwrap();
        let poly = c.polyline_for_test(2.0);
        assert_eq!(poly.len(), 4);
        assert!(close(poly[2].0 - poly[1].0, EPS / 2.0), "{poly:?}");
        assert!(Curve::from_points(vec![0.0], vec![vec![0.0]], 1.0).is_err());
        assert!(Curve::from_points(vec![0.0, 1.0], vec![vec![0.0], vec![1.0, 2.0]], 1.0).is_err());
    }
}
