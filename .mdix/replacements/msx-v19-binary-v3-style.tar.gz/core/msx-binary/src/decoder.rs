// core/msx-binary/src/decoder.rs
//! Low-level binary read helpers. All read_ functions advance a &mut usize cursor.

use std::io;
use crate::encoder::{EXT_DOMINANT_BASELINE, EXT_FILL_OPACITY, EXT_STROKE_OPACITY, UNSET_BYTE, UNSET_U16};
use msx_ast::{Color, FillRule, FontWeight, LineCap, LineJoin, Paint, Style, TextAnchor, Transform};
use msx_ast::transform::{
    Matrix2D, TRANSFORM_MATRIX, TRANSFORM_MULTIPLE, TRANSFORM_NONE, TRANSFORM_ROTATE,
    TRANSFORM_SCALE, TRANSFORM_SKEW_X, TRANSFORM_SKEW_Y, TRANSFORM_TRANSLATE,
};

fn eof(msg: &str) -> io::Error { io::Error::new(io::ErrorKind::UnexpectedEof, msg.to_string()) }
fn bad(msg: &str) -> io::Error { io::Error::new(io::ErrorKind::InvalidData, msg.to_string()) }

// ── Primitives ───────────────────────────────────────────────────────────────

pub fn read_u8(data: &[u8], cursor: &mut usize) -> io::Result<u8> {
    if *cursor >= data.len() { return Err(eof("read_u8: unexpected eof")); }
    let v = data[*cursor];
    *cursor += 1;
    Ok(v)
}

pub fn read_u16(data: &[u8], cursor: &mut usize) -> io::Result<u16> {
    if *cursor + 2 > data.len() { return Err(eof("read_u16: unexpected eof")); }
    let v = u16::from_le_bytes(data[*cursor..*cursor + 2].try_into().unwrap());
    *cursor += 2;
    Ok(v)
}

pub fn read_u32(data: &[u8], cursor: &mut usize) -> io::Result<u32> {
    if *cursor + 4 > data.len() { return Err(eof("read_u32: unexpected eof")); }
    let v = u32::from_le_bytes(data[*cursor..*cursor + 4].try_into().unwrap());
    *cursor += 4;
    Ok(v)
}

pub fn read_f32(data: &[u8], cursor: &mut usize) -> io::Result<f64> {
    if *cursor + 4 > data.len() { return Err(eof("read_f32: unexpected eof")); }
    let v = f32::from_le_bytes(data[*cursor..*cursor + 4].try_into().unwrap()) as f64;
    *cursor += 4;
    Ok(v)
}

pub fn read_point(data: &[u8], cursor: &mut usize) -> io::Result<(f64, f64)> {
    let x = read_f32(data, cursor)?;
    let y = read_f32(data, cursor)?;
    Ok((x, y))
}

// ── String pool ───────────────────────────────────────────────────────────────

pub fn read_string_pool(data: &[u8], cursor: &mut usize) -> io::Result<Vec<String>> {
    let count = read_u16(data, cursor)? as usize;
    let mut pool = Vec::with_capacity(count);
    for i in 0..count {
        let len = read_u16(data, cursor)? as usize;
        if *cursor + len > data.len() {
            return Err(eof(&format!("string pool entry {} truncated", i)));
        }
        let s = std::str::from_utf8(&data[*cursor..*cursor + len])
            .map_err(|e| bad(&format!("string pool entry {} invalid utf8: {}", i, e)))?
            .to_string();
        *cursor += len;
        pool.push(s);
    }
    Ok(pool)
}

// BUGFIX: was `pub fn lookup_string<'a>(pool: &'a [String], idx: u16) -> io::Result<&'a str>`
// — clippy::needless_lifetimes, single input+output lifetime elides per Rust rules.
pub fn lookup_string(pool: &[String], idx: u16) -> io::Result<&str> {
    pool.get(idx as usize)
        .map(|s| s.as_str())
        .ok_or_else(|| bad(&format!("string pool index {} out of range (pool len={})", idx, pool.len())))
}

// ── Color / Paint ────────────────────────────────────────────────────────────

pub fn read_color(data: &[u8], cursor: &mut usize) -> io::Result<Color> {
    if *cursor + 4 > data.len() { return Err(eof("read_color: unexpected eof")); }
    let bytes: [u8; 4] = data[*cursor..*cursor + 4].try_into().unwrap();
    *cursor += 4;
    Ok(Color::from_bytes(bytes))
}

pub fn read_paint(data: &[u8], cursor: &mut usize, pool: &[String]) -> io::Result<Paint> {
    let tag = read_u8(data, cursor)?;
    match tag {
        t if t == Paint::TAG_NONE         => Ok(Paint::None),
        t if t == Paint::TAG_COLOR        => {
            let c = read_color(data, cursor)?;
            Ok(Paint::Color(c))
        }
        t if t == Paint::TAG_GRADIENT_REF || t == Paint::TAG_PATTERN_REF => {
            let idx = read_u16(data, cursor)?;
            let s   = lookup_string(pool, idx)?.to_string();
            if s == "currentColor" { Ok(Paint::CurrentColor) } else { Ok(Paint::Ref(s)) }
        }
        other => Err(bad(&format!("unknown paint tag 0x{:02x}", other))),
    }
}

// ── Transform ────────────────────────────────────────────────────────────────

pub fn read_transform(data: &[u8], cursor: &mut usize) -> io::Result<Transform> {
    let tag = read_u8(data, cursor)?;
    match tag {
        TRANSFORM_NONE      => Ok(Transform::None),
        TRANSFORM_MATRIX    => {
            if *cursor + 24 > data.len() { return Err(eof("matrix truncated")); }
            let bytes: [u8; 24] = data[*cursor..*cursor + 24].try_into().unwrap();
            *cursor += 24;
            Ok(Transform::Matrix(Matrix2D::from_bytes(&bytes)))
        }
        TRANSFORM_TRANSLATE => {
            let x = read_f32(data, cursor)?;
            let y = read_f32(data, cursor)?;
            Ok(Transform::Translate { x, y })
        }
        TRANSFORM_SCALE     => {
            let x = read_f32(data, cursor)?;
            let y = read_f32(data, cursor)?;
            Ok(Transform::Scale { x, y })
        }
        TRANSFORM_ROTATE    => {
            let angle      = read_f32(data, cursor)?;
            let has_center = read_u8(data, cursor)? != 0;
            let (cx, cy)   = if has_center {
                (Some(read_f32(data, cursor)?), Some(read_f32(data, cursor)?))
            } else {
                (None, None)
            };
            Ok(Transform::Rotate { angle, cx, cy })
        }
        TRANSFORM_SKEW_X    => Ok(Transform::SkewX(read_f32(data, cursor)?)),
        TRANSFORM_SKEW_Y    => Ok(Transform::SkewY(read_f32(data, cursor)?)),
        TRANSFORM_MULTIPLE  => {
            let count = read_u8(data, cursor)? as usize;
            let mut v = Vec::with_capacity(count);
            for _ in 0..count { v.push(read_transform(data, cursor)?); }
            Ok(Transform::Multiple(v))
        }
        other => Err(bad(&format!("unknown transform tag 0x{:02x}", other))),
    }
}

pub fn read_optional_transform(data: &[u8], cursor: &mut usize) -> io::Result<Option<Transform>> {
    let t = read_transform(data, cursor)?;
    Ok(if t.is_none() { None } else { Some(t) })
}

// ── id_flags ─────────────────────────────────────────────────────────────────

pub fn read_id_flags(
    data:   &[u8],
    cursor: &mut usize,
    pool:   &[String],
) -> io::Result<(Option<String>, Option<Transform>)> {
    let flags         = read_u8(data, cursor)?;
    let has_id        = flags & 1 != 0;
    let has_transform = flags & 2 != 0;
    let id = if has_id {
        let idx = read_u16(data, cursor)?;
        Some(lookup_string(pool, idx)?.to_string())
    } else { None };
    let transform = if has_transform { Some(read_transform(data, cursor)?) } else { None };
    Ok((id, transform))
}

// ── Style ────────────────────────────────────────────────────────────────────

pub fn read_style(data: &[u8], cursor: &mut usize, pool: &[String]) -> io::Result<Style> {
    let flags = read_u8(data, cursor)?;
    let mut s = Style::empty();
    if flags & (1 << 0) != 0 { s.fill         = Some(read_paint(data, cursor, pool)?); }
    if flags & (1 << 1) != 0 { s.stroke       = Some(read_paint(data, cursor, pool)?); }
    if flags & (1 << 2) != 0 { s.opacity      = Some(read_f32(data, cursor)?); }
    if flags & (1 << 3) != 0 { s.stroke_width = Some(read_f32(data, cursor)?); }
    if flags & (1 << 4) != 0 {
        s.fill_rule         = Some(read_u8(data, cursor)?).filter(|&b| b != UNSET_BYTE).map(FillRule::from_byte);
        s.stroke_linecap    = Some(read_u8(data, cursor)?).filter(|&b| b != UNSET_BYTE).map(LineCap::from_byte);
        s.stroke_linejoin   = Some(read_u8(data, cursor)?).filter(|&b| b != UNSET_BYTE).map(LineJoin::from_byte);
        s.stroke_miterlimit = Some(read_f32(data, cursor)?).filter(|v| !v.is_nan());
    }
    if flags & (1 << 5) != 0 {
        let fs_x100   = read_u16(data, cursor)?;
        s.font_size   = if fs_x100 == UNSET_U16 { None } else { Some(fs_x100 as f64 / 100.0) };
        let ff_idx    = read_u16(data, cursor)?;
        let ff        = lookup_string(pool, ff_idx)?.to_string();
        s.font_family = if ff.is_empty() { None } else { Some(ff) };
        let fw_byte   = read_u8(data, cursor)?;
        s.font_weight = if fw_byte == 0 { None } else { Some(FontWeight::from_byte(fw_byte - 1)) };
        let ta_byte   = read_u8(data, cursor)?;
        s.text_anchor = if ta_byte == 0 { None } else { Some(TextAnchor::from_byte(ta_byte - 1)) };
    }
    if flags & (1 << 6) != 0 {
        let count = read_u16(data, cursor)? as usize;
        let mut da = Vec::with_capacity(count);
        for _ in 0..count { da.push(read_f32(data, cursor)?); }
        s.stroke_dasharray  = if da.is_empty() { None } else { Some(da) };
        s.stroke_dashoffset = Some(read_f32(data, cursor)?).filter(|v| !v.is_nan());
    }
    if flags & (1 << 7) != 0 {
        let vd              = read_u8(data, cursor)?;
        s.visibility_hidden = vd & 1 != 0;
        s.display_none      = vd & 2 != 0;
        if vd & 4 != 0 {
            let present = read_u8(data, cursor)?;
            if present & EXT_FILL_OPACITY      != 0 { s.fill_opacity      = Some(read_f32(data, cursor)?); }
            if present & EXT_STROKE_OPACITY    != 0 { s.stroke_opacity    = Some(read_f32(data, cursor)?); }
            if present & EXT_DOMINANT_BASELINE != 0 {
                let idx = read_u16(data, cursor)?;
                s.dominant_baseline = Some(lookup_string(pool, idx)?.to_string());
            }
        }
    }
    Ok(s)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::encoder::{write_paint, write_string_pool, write_style, write_transform, intern_string};
    use msx_ast::Color;

    fn roundtrip_paint(paint: Paint) {
        let mut buf  = Vec::new();
        let mut pool = Vec::new();
        write_paint(&mut buf, &paint, &mut pool);
        let mut cursor = 0;
        let back = read_paint(&buf, &mut cursor, &pool).unwrap();
        assert_eq!(back, paint);
        assert_eq!(cursor, buf.len());
    }

    #[test] fn paint_none_roundtrip()  { roundtrip_paint(Paint::None); }
    #[test] fn paint_color_roundtrip() { roundtrip_paint(Paint::Color(Color::rgba(10, 20, 30, 200))); }
    #[test] fn paint_ref_roundtrip()   { roundtrip_paint(Paint::Ref("url(#sunset)".to_string())); }
    #[test] fn paint_currentcolor_rt() { roundtrip_paint(Paint::CurrentColor); }

    #[test]
    fn transform_translate_roundtrip() {
        let t = Transform::Translate { x: 10.5, y: -20.0 };
        let mut buf = Vec::new();
        write_transform(&mut buf, &t);
        let mut cursor = 0;
        let back = read_transform(&buf, &mut cursor).unwrap();
        assert_eq!(cursor, buf.len());
        if let Transform::Translate { x, y } = back {
            assert!((x - 10.5).abs() < 1e-4);
            assert!((y + 20.0).abs() < 1e-4);
        } else { panic!("expected Translate"); }
    }

    #[test]
    fn transform_rotate_with_center_roundtrip() {
        let t = Transform::Rotate { angle: 45.0, cx: Some(100.0), cy: Some(200.0) };
        let mut buf = Vec::new();
        write_transform(&mut buf, &t);
        let mut cursor = 0;
        let back = read_transform(&buf, &mut cursor).unwrap();
        if let Transform::Rotate { angle, cx, cy } = back {
            assert!((angle - 45.0).abs() < 1e-4);
            assert!((cx.unwrap() - 100.0).abs() < 1e-4);
            assert!((cy.unwrap() - 200.0).abs() < 1e-4);
        } else { panic!("expected Rotate"); }
    }

    #[test]
    fn style_roundtrip() {
        let mut style = Style::empty();
        style.fill         = Some(Paint::Color(Color::rgb(255, 128, 0)));
        style.stroke       = Some(Paint::None);
        style.stroke_width = Some(2.5);
        style.opacity      = Some(0.8);
        let mut buf  = Vec::new();
        let mut pool = Vec::new();
        write_style(&mut buf, &style, &mut pool);
        let mut cursor = 0;
        let back = read_style(&buf, &mut cursor, &pool).unwrap();
        assert_eq!(cursor, buf.len());
        assert_eq!(back.fill, style.fill);
        assert_eq!(back.stroke, style.stroke);
        assert!((back.stroke_width.unwrap() - 2.5).abs() < 1e-3);
        assert!((back.opacity.unwrap() - 0.8).abs() < 1e-3);
    }

    #[test]
    fn style_extension_roundtrip() {
        let mut style = Style::empty();
        style.fill_opacity      = Some(0.5);
        style.stroke_opacity    = Some(0.25);
        style.dominant_baseline = Some("central".to_string());
        style.display_none      = true;
        let mut buf  = Vec::new();
        let mut pool = Vec::new();
        write_style(&mut buf, &style, &mut pool);
        let mut cursor = 0;
        let back = read_style(&buf, &mut cursor, &pool).unwrap();
        assert_eq!(cursor, buf.len());
        assert_eq!(back.fill_opacity, Some(0.5));
        assert_eq!(back.stroke_opacity, Some(0.25));
        assert_eq!(back.dominant_baseline.as_deref(), Some("central"));
        assert!(back.display_none && !back.visibility_hidden);
    }

    #[test]
    fn style_without_the_extension_is_byte_for_byte_what_version_2_wrote() {
        let mut style = Style::empty();
        style.visibility_hidden = true;
        let mut buf  = Vec::new();
        write_style(&mut buf, &style, &mut Vec::new());
        // present flags (bit 7 only), then the one visibility byte with no extension bit.
        assert_eq!(buf, vec![0x80, 0x01]);
    }

    #[test]
    fn a_cut_off_extension_is_an_error_not_a_panic() {
        let mut style = Style::empty();
        style.fill_opacity   = Some(0.5);
        style.stroke_opacity = Some(0.5);
        let mut buf  = Vec::new();
        write_style(&mut buf, &style, &mut Vec::new());
        for cut in 0..buf.len() {
            let mut cursor = 0;
            assert!(read_style(&buf[..cut], &mut cursor, &[]).is_err(), "cut at {cut}");
        }
    }

    #[test]
    fn string_pool_roundtrip() {
        let mut pool = Vec::new();
        intern_string(&mut pool, "hello");
        intern_string(&mut pool, "world");
        let mut buf = Vec::new();
        write_string_pool(&mut buf, &pool);
        let mut cursor = 0;
        let back = read_string_pool(&buf, &mut cursor).unwrap();
        assert_eq!(back, pool);
        assert_eq!(cursor, buf.len());
    }

    #[test]
    fn font_weight_none_roundtrips_as_none() {
        let mut style = Style::empty();
        style.font_size   = Some(18.0);
        style.text_anchor = Some(TextAnchor::Middle);
        let mut buf  = Vec::new();
        let mut pool = Vec::new();
        write_style(&mut buf, &style, &mut pool);
        let mut cursor = 0;
        let back = read_style(&buf, &mut cursor, &pool).unwrap();
        assert_eq!(back.font_weight, None);
        assert_eq!(back.text_anchor, Some(TextAnchor::Middle));
        assert!((back.font_size.unwrap() - 18.0).abs() < 0.01);
    }

    #[test]
    fn text_anchor_none_roundtrips_as_none() {
        let mut style = Style::empty();
        style.font_size   = Some(12.0);
        style.font_weight = Some(FontWeight::Bold);
        let mut buf  = Vec::new();
        let mut pool = Vec::new();
        write_style(&mut buf, &style, &mut pool);
        let mut cursor = 0;
        let back = read_style(&buf, &mut cursor, &pool).unwrap();
        assert_eq!(back.text_anchor, None);
        assert_eq!(back.font_weight, Some(FontWeight::Bold));
    }

    fn style_through_codec(style: &Style) -> Style {
        let mut buf  = Vec::new();
        let mut pool = Vec::new();
        write_style(&mut buf, style, &mut pool);
        let mut cursor = 0;
        let back = read_style(&buf, &mut cursor, &pool).unwrap();
        assert_eq!(cursor, buf.len());
        back
    }

    #[test]
    fn fill_rule_alone_leaves_the_other_stroke_detail_fields_unset() {
        let mut style = Style::empty();
        style.fill_rule = Some(FillRule::EvenOdd);
        let back = style_through_codec(&style);
        assert_eq!(back.fill_rule, Some(FillRule::EvenOdd));
        assert_eq!(back.stroke_linecap, None);
        assert_eq!(back.stroke_linejoin, None);
        assert_eq!(back.stroke_miterlimit, None);
    }

    #[test]
    fn explicit_defaults_in_the_stroke_detail_group_stay_explicit() {
        let mut style = Style::empty();
        style.fill_rule         = Some(FillRule::NonZero);
        style.stroke_linecap    = Some(LineCap::Butt);
        style.stroke_linejoin   = Some(LineJoin::Miter);
        style.stroke_miterlimit = Some(4.0);
        let back = style_through_codec(&style);
        assert_eq!(back.fill_rule, Some(FillRule::NonZero));
        assert_eq!(back.stroke_linecap, Some(LineCap::Butt));
        assert_eq!(back.stroke_linejoin, Some(LineJoin::Miter));
        assert_eq!(back.stroke_miterlimit, Some(4.0));
    }

    #[test]
    fn miterlimit_alone_is_stored() {
        let mut style = Style::empty();
        style.stroke_miterlimit = Some(2.5);
        let back = style_through_codec(&style);
        assert_eq!(back.stroke_miterlimit, Some(2.5));
        assert_eq!(back.fill_rule, None);
        assert_eq!(back.stroke_linecap, None);
    }

    #[test]
    fn font_size_unset_roundtrips_as_none() {
        let mut style = Style::empty();
        style.text_anchor = Some(TextAnchor::End);
        let back = style_through_codec(&style);
        assert_eq!(back.font_size, None);
        assert_eq!(back.text_anchor, Some(TextAnchor::End));
    }

    #[test]
    fn dash_array_and_dash_offset_are_stored_independently() {
        let mut only_array = Style::empty();
        only_array.stroke_dasharray = Some(vec![4.0, 2.0]);
        let back = style_through_codec(&only_array);
        assert_eq!(back.stroke_dasharray, Some(vec![4.0, 2.0]));
        assert_eq!(back.stroke_dashoffset, None);

        let mut only_offset = Style::empty();
        only_offset.stroke_dashoffset = Some(3.0);
        let back = style_through_codec(&only_offset);
        assert_eq!(back.stroke_dasharray, None);
        assert_eq!(back.stroke_dashoffset, Some(3.0));
    }

    /// Bytes an older encoder wrote for an unset grouped field are plain
    /// defaults, which must still decode to explicit values as before.
    #[test]
    fn style_blocks_written_with_default_bytes_still_decode() {
        let buf = [1u8 << 4, 0, 0, 0, 0x00, 0x00, 0x80, 0x40]; // fill_rule 0, cap 0, join 0, miterlimit 4.0f32
        let mut cursor = 0;
        let back = read_style(&buf, &mut cursor, &[]).unwrap();
        assert_eq!(cursor, buf.len());
        assert_eq!(back.fill_rule, Some(FillRule::NonZero));
        assert_eq!(back.stroke_linecap, Some(LineCap::Butt));
        assert_eq!(back.stroke_linejoin, Some(LineJoin::Miter));
        assert_eq!(back.stroke_miterlimit, Some(4.0));
    }
                                    }
